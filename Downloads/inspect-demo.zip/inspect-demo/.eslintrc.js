module.exports = {
  root: true,
  extends: ['@react-native-community', 'plugin:import/recommended'],
  settings: {
    'import/ignore': ['react-native'],
    'import/resolver': {
      alias: {
        map: [['@', './src']],
      },
    },
  },
  rules: {
    'arrow-body-style': 'error',
    'import/order': [
      'error',
      {
        alphabetize: {order: 'asc'},
        'newlines-between': 'never',
      },
    ],
    'react/jsx-curly-brace-presence': ['error', 'never'],
    'react/jsx-boolean-value': ['error', 'never'],
    'react/react-in-jsx-scope': 'off',
  },
};
