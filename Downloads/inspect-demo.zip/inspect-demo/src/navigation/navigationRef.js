import {
  CommonActions,
  createNavigationContainerRef,
  StackActions,
} from '@react-navigation/native';

export const navigationRef = createNavigationContainerRef();

export const navigate = (name, params) => {
  if (!navigationRef.isReady()) {
    return;
  }
  navigationRef.current.dispatch(CommonActions.navigate({name, params}));
};

export const reset = (index, name, params) => {
  if (!navigationRef.isReady()) {
    return;
  }
  navigationRef.current.dispatch(
    CommonActions.reset({
      index,
      routes: [{name, params}],
    }),
  );
};

export const replace = (name, params) => {
  if (!navigationRef.isReady()) {
    return;
  }
  navigationRef.current.dispatch(StackActions.replace(name, params));
};

export const goBack = () => {
  if (!navigationRef.isReady()) {
    return;
  }
  navigationRef.current.dispatch(CommonActions.goBack());
};
