const MAIN_NAV = {
  CAR_EDITOR: 'CarEditor',
  INSPECTION_EDITOR: 'InspectionEditor',
  INSPECTION_HOME: 'InspectionHome',
  INSPECTION_RESUME: 'InspectionResume',
  INSPECTION_SYNC: 'InspectionSync',
  LOGIN: 'Login',
  MY_INSPECTIONS: 'MyInspections',
  SUBSECTION_EDITOR: 'SubsectionEditor',
};

export default MAIN_NAV;
