import {NavigationContainer} from '@react-navigation/native';
import {Fragment, useEffect} from 'react';
import {Platform} from 'react-native';
import SplashScreen from 'react-native-splash-screen';
import {connect} from 'react-redux';
import {cardStyleInterpolator, Stack, transitionSpec} from './config';
import {navigationRef} from './navigationRef';
import Routes from './routes';
import {Snackbar} from '@/components';
import {initialize} from '@/state/reducer/staticData';
import {selectToken} from '@/state/selector/session';
import CarEditor from '@/views/CarEditor';
import InspectionEditor from '@/views/InspectionEditor';
import InspectionHome from '@/views/InspectionHome';
import InspectionResume from '@/views/InspectionResume';
import InspectionSync from '@/views/InspectionSync';
import Login from '@/views/Login';
import MyInspections from '@/views/MyInspections';
import SubsectionEditor from '@/views/SubsectionEditor';

const options = {
  cardStyleInterpolator,
  transitionSpec,
  headerShown: false,
};

const AppNavigation = ({token, onMount}) => {
  useEffect(() => {
    if (token) {
      onMount();
    }
    Platform.select({
      android: () => SplashScreen.hide(),
      default: () => {},
    })();
  }, [onMount, token]);
  return (
    <Fragment>
      <Snackbar />
      <NavigationContainer ref={navigationRef}>
        <Stack.Navigator
          initialRouteName={token ? Routes.MY_INSPECTIONS : Routes.LOGIN}>
          <Stack.Screen
            name={Routes.LOGIN}
            component={Login}
            options={options}
          />
          <Stack.Screen
            name={Routes.CAR_EDITOR}
            component={CarEditor}
            options={options}
          />
          <Stack.Screen
            name={Routes.INSPECTION_HOME}
            component={InspectionHome}
            options={options}
          />
          <Stack.Screen
            name={Routes.MY_INSPECTIONS}
            component={MyInspections}
            options={options}
          />
          <Stack.Screen
            name={Routes.SUBSECTION_EDITOR}
            component={SubsectionEditor}
            options={options}
          />
          <Stack.Screen
            name={Routes.INSPECTION_EDITOR}
            component={InspectionEditor}
            options={options}
          />
          <Stack.Screen
            name={Routes.INSPECTION_RESUME}
            component={InspectionResume}
            options={options}
          />
          <Stack.Screen
            name={Routes.INSPECTION_SYNC}
            component={InspectionSync}
            options={options}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </Fragment>
  );
};

export default connect(state => ({token: selectToken(state)}), {
  onMount: initialize,
})(AppNavigation);
