import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {
  TransitionSpecs,
  createStackNavigator,
  CardStyleInterpolators,
} from '@react-navigation/stack';

export const transitionSpec = {
  open: TransitionSpecs.TransitionIOSSpec,
  close: TransitionSpecs.TransitionIOSSpec,
};

export const cardStyleInterpolator = CardStyleInterpolators.forHorizontalIOS;
export const Stack = createStackNavigator();
export const Tab = createBottomTabNavigator();
