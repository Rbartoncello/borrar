import car from './car.json';
import inspection from './inspection.json';
import login from './login.json';
import translation from './translation.json';

export default {car, inspection, login, translation};
