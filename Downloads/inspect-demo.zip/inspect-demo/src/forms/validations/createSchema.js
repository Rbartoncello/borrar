import createArraySchema from './createArraySchema';
import createBooleanSchema from './createBooleanSchema';
import createDateSchema from './createDateSchema';
import createDocumentSchema from './createDocumentSchema';
import createEmailSchema from './createEmailSchema';
import createEnumSchema from './createEnumSchema';
import createListSchema from './createListSchema';
import createNumberSchema from './createNumberSchema';
import createPhotoSchema from './createPhotoSchema';
import createPhotosSchema from './createPhotosSchema';
import createStringSchema from './createStringSchema';
import createTelephoneSchema from './createTelephoneSchema';

const createSchema = field => {
  const validationType = field.validationType || field.type;
  switch (validationType) {
    case 'bool':
    case 'checkbox':
      return createBooleanSchema(field);
    case 'chip':
    case 'checkboxList':
      return createListSchema(field);
    case 'date':
      return createDateSchema(field);
    case 'document':
      return createDocumentSchema(field);
    case 'documents':
      return createArraySchema(field);
    case 'email':
      return createEmailSchema(field);
    case 'number':
      return createNumberSchema(field);
    case 'photo':
      return createPhotoSchema(field);
    case 'photos':
      return createPhotosSchema(field);
    case 'radio':
    case 'select':
      return createEnumSchema(field);
    case 'tel':
      return createTelephoneSchema(field);
    case 'text':
    case 'textArea':
      return createStringSchema(field);
    case 'actionLink':
    case 'camera':
    case 'subsections':
      return undefined;
    default:
      throw new Error(
        `createSchema: ${validationType} validation schema not implemented for field ${field.name}.`,
      );
  }
};

export default createSchema;
