import {array, object, lazy, mixed, string} from 'yup';

const createArraySchema = ({name, validations = []}) => {
  let schema = array().of(
    lazy(value => {
      switch (typeof value) {
        case 'object':
          return object();
        case 'string':
          return string();
        default:
          return mixed();
      }
    }),
  );
  validations.forEach(({type, value, message}) => {
    switch (type) {
      case 'required':
        schema = schema.required(message);
        break;
      case 'min':
        schema = schema.min(value, message);
        break;
      case 'max':
        schema = schema.max(value, message);
        break;
      default:
        throw new Error(
          `EnumSchema: validation type ${type} not implemented for field ${name}.`,
        );
    }
  });
  return schema;
};

export default createArraySchema;
