import {date} from 'yup';

export function parseDate(value, originalValue) {
  if (this.isType(value)) {
    return value;
  }

  if (originalValue && typeof originalValue === 'object') {
    const {day, month, year} = originalValue;
    if (!day || !month || !year) {
      return undefined;
    }
    const input = Date.parse(`${year}-${month}-${day}`);
    return input.isValid() ? input.toDate() : undefined;
  }
  return value;
}

const createDateSchema = ({name, validations = []}) => {
  let schema = date().transform(parseDate);
  validations.forEach(({type, value, message}) => {
    switch (type) {
      case 'required':
        schema = schema.required(message);
        break;
      case 'min':
        schema = schema.min(value, message);
        break;
      case 'max':
        schema = schema.max(value, message);
        break;
      case 'past':
        schema = schema.min(new Date(), message);
        break;
      case 'future':
        schema = schema.max(new Date(), message);
        break;
      case 'before':
        schema = schema.when(value, (field, fieldSchema) =>
          field ? fieldSchema.max(field, message) : fieldSchema,
        );
        break;
      case 'after':
        schema = schema.when(value, (field, fieldSchema) =>
          field ? fieldSchema.min(field, message) : fieldSchema,
        );
        break;
      default:
        throw new Error(
          `Date: validation type ${type} not implemented for field ${name}.`,
        );
    }
  });
  return schema;
};

export default createDateSchema;
