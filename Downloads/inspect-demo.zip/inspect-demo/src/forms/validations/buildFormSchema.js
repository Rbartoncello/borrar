import {object} from 'yup';
import createSchema from './createSchema';
import {isReadOnlyField, validateEnablerForm} from './util';
import {isString} from '@/util';

const buildFormSchema = ({fields, enabler}) => {
  const schema = {};
  fields
    .filter(field => !isReadOnlyField(field))
    .forEach(field => {
      if (isString(field.name)) {
        schema[field.name] = createSchema(field);
        return;
      }
      const types = field.type.split('With');
      if (!field || !Array.isArray(field.name)) {
        return;
      }
      schema[field.name[0]] = createSchema({
        ...field,
        name: field.name[0],
        type: types[0],
      });
      schema[field.name[1]] = createSchema({
        ...field,
        name: field.name[1],
        type: types[1].toLowerCase(),
      });
    });
  if (enabler) {
    schema[enabler] = schema[enabler]?.test(validateEnablerForm(enabler));
  }
  return object(schema);
};

export default buildFormSchema;
