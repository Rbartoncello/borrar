import {string, ref} from 'yup';
import {equalsTo} from './extensions';

const createTelephoneSchema = ({name, validations = []}) => {
  let schema = string();
  validations.forEach(({type, value, message}) => {
    switch (type) {
      case 'required':
        schema = schema.required(message);
        break;
      case 'matches':
        schema = schema.matches(value, message);
        break;
      case 'equals':
        schema = schema.test(equalsTo(ref(value), message));
        break;
      default:
        throw new Error(
          `TelephoneSchema: validation type ${type} not implemented for field ${name}.`,
        );
    }
  });
  return schema;
};

export default createTelephoneSchema;
