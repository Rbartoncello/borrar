export const isReadOnlyField = ({type, isReadOnly}) => {
  if (isReadOnly === true) {
    return true;
  }
  switch (type) {
    case 'actionLink':
    case 'error':
    case 'title':
    case 'subsections':
      return true;
    default:
      return false;
  }
};

export const validateEnablerForm =
  enabler =>
  (value, {parent}) => {
    if (!value) {
      return true;
    }
    return Object.keys(parent)
      .filter(fieldName => fieldName !== enabler)
      .some(fieldName => {
        if (fieldName === 'subsections' && parent[fieldName]) {
          return Object.values(parent[fieldName]).some(
            val => Object.keys(val).length,
          );
        }
        return Array.isArray(parent[fieldName])
          ? parent[fieldName].length > 0
          : !!parent[fieldName];
      });
  };
