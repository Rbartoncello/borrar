import {string} from 'yup';

const createDocumentSchema = ({name, validations = []}) => {
  let schema = string();
  validations.forEach(({type, message}) => {
    switch (type) {
      case 'required':
        schema = string().required(message);
        break;
      case 'min':
      case 'max':
      case 'future':
      case 'past':
        // ignored because it's handled by the second field, e.g. photoWithDate.
        break;
      default:
        throw new Error(
          `PhotoSchema: validation type ${type} not implemented for field ${name}.`,
        );
    }
  });
  return schema;
};

export default createDocumentSchema;
