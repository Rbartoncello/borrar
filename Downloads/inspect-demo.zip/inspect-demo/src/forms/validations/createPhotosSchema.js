import {array, object, string} from 'yup';

const createPhotosSchema = ({name, validations = []}) => {
  let schema = object({values: array().of(string())});
  validations.forEach(({type, value, message}) => {
    switch (type) {
      case 'required':
        schema = schema.concat(
          object({values: array().of(string()).required(message)}),
        );
        break;
      case 'min':
        schema = schema.concat(
          object({values: array().of(string()).min(value, message)}),
        );
        break;
      case 'max':
        schema = schema.concat(
          object({values: array().of(string()).max(value, message)}),
        );
        break;
      default:
        throw new Error(
          `PhotosSchema: validation type ${type} not implemented for field ${name}.`,
        );
    }
  });
  return schema;
};

export default createPhotosSchema;
