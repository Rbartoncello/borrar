import {Formik} from 'formik';
import {useEffect, useMemo, useRef, useState} from 'react';
import InnerForm from './InnerForm';
import ComponentsRegistry from './componentsRegistry';
import useFormikSchema from './useFormikSchema';
import {formatValues} from './util';
import {useEvent} from '@/hooks';

export const DynamicForm = ({
  formSchema,
  initialValues = {},
  reinitializeValues = {},
  components,
  onCancel,
  onChange = () => {},
  onAction,
  onSubmitValidationError,
  onSubmit,
  onFormDirty = () => {},
}) => {
  const ref = useRef();
  const [values, setValues] = useState(initialValues);
  const componentsRegistry = useMemo(
    () => new ComponentsRegistry(components),
    [components],
  );
  const [schema, validationSchema] = useFormikSchema(formSchema, values);
  const handleChange = useEvent((key, value) => {
    setValues({...values, [key]: value});
    onChange(key, value);
  });
  const handleSubmit = useEvent((formikValues, actions) => {
    // for forms/tabs changes, set dirty to initial
    onFormDirty(false);
    // Returns void because if onSubmit returns a Promise, the isSubmitting
    // could be wrongly dismissed when the Promised is resolved.
    onSubmit(formatValues(formikValues, schema.fields), actions);
  });
  useEffect(() => {
    // force reinitialize values by navigating between forms/tabs without submit
    ref.current?.validateForm();
    ref.current?.resetForm({values: {...reinitializeValues, ...values}});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reinitializeValues]);
  useEffect(() => {
    onFormDirty(ref.current?.dirty);
  }, [onFormDirty, values]);
  return (
    <Formik
      validationSchema={validationSchema}
      initialValues={initialValues}
      onSubmit={handleSubmit}
      validateOnMount
      innerRef={ref}>
      {props => (
        <InnerForm
          {...props}
          onFormDirty={onFormDirty}
          formSchema={schema}
          componentsRegistry={componentsRegistry}
          onCancel={onCancel}
          onAction={onAction}
          onChange={handleChange}
          onSubmitValidationError={onSubmitValidationError}
        />
      )}
    </Formik>
  );
};

export default DynamicForm;
