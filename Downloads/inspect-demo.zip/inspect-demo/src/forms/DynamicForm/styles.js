export const createButtonsStyles = theme => ({
  submit: {
    marginTop: theme.spacing.marginVertical,
    marginHorizontal: theme.spacing.marginHorizontal,
    marginBottom: theme.spacing.marginVertical * 2.5,
  },
});

export const createFormStyles = theme => ({
  form: {
    flex: 1,
    paddingHorizontal: theme.spacing.paddingHorizontal,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
});
