import {Fragment} from 'react';
import {createButtonsStyles} from './styles';
import {Button} from '@/components';
import {useThemedStyles} from '@/hooks';

const FormButtons = ({
  formSchema = {},
  isSubmitting,
  isValid,
  onCancel,
  onSubmit,
}) => {
  const [styles] = useThemedStyles(createButtonsStyles);
  return (
    <Fragment>
      <Button
        disabled={isSubmitting || !isValid}
        title={formSchema.submitText || 'submit'}
        onPress={onSubmit}
        containerStyle={styles.submit}
        {...formSchema?.submitButton}
      />
      {onCancel && (
        <Button
          type="clear"
          title={formSchema.cancelText || 'cancel'}
          onPress={onCancel}
          disabled={isSubmitting}
        />
      )}
    </Fragment>
  );
};

export default FormButtons;
