import {useEffect, useState} from 'react';

export const handleSubmit =
  (setFormActions, onSubmit) =>
  (values, {setSubmitting}) => {
    setFormActions({setSubmitting});
    onSubmit(values);
  };

export const handleDismiss = (dismiss, formActions, setFormActions) => {
  if (dismiss && formActions) {
    formActions.setSubmitting(false);
    setFormActions(null);
  }
};

const useDismissibleSubmit = (onSubmit, dismiss) => {
  const [formActions, setFormActions] = useState();
  useEffect(
    () => handleDismiss(dismiss, formActions, setFormActions),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [dismiss],
  );
  return handleSubmit(setFormActions, onSubmit);
};

export default useDismissibleSubmit;
