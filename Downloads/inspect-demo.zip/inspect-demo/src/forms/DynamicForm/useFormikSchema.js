import {useMemo} from 'react';
import {useSelector} from 'react-redux';
import {buildFormSchema} from '@/forms/validations';
import {selectQuestionnaireOptions} from '@/state/selector/staticData';
import {isString, template} from '@/util';

const getOptions = (field, options, values) => {
  let key = template(field.options, values);
  if (key.indexOf(':') > -1) {
    // the prefix is only used as i18n namespace, so it's not needed here.
    key = key.substring(key.indexOf(':') + 1);
  }
  return options[key]?.map(value => ({value, label: value}));
};
const useFormikSchema = (formSchema, values) => {
  const options = useSelector(selectQuestionnaireOptions);
  return useMemo(() => {
    const hasEnabler = formSchema.enabler
      ? values?.[formSchema.enabler] !== true
      : false;
    const fields = formSchema.fields.map(field => {
      const disabled =
        field.disabled ?? (hasEnabler && field.name !== formSchema.enabler);
      if (!isString(field.options)) {
        // if it has enabler and its value is false, all fields should not have validations
        if (hasEnabler && typeof values?.[formSchema.enabler] === 'boolean') {
          return {
            ...field,
            disabled,
            isReadOnly: true,
          };
        }
        return {...field, disabled};
      }
      return {
        ...field,
        disabled,
        options: getOptions(field, options, values) || [],
      };
    });
    const cameraType = fields.find(x => x.type === 'camera');
    if (cameraType) {
      cameraType.fields = fields.filter(
        field => field.type.startsWith('photo') && field.type !== 'photos',
      );
    }
    const schema = {...formSchema, fields};
    return [schema, buildFormSchema(schema)];
  }, [formSchema, values, options]);
};

export default useFormikSchema;
