import {Field} from 'formik';
import {Fragment} from 'react';
import {View} from 'react-native';
import FormButtons from './FormButtons';
import OnSubmitValidationError from './OnSubmitValidationError';
import Submitting from './Submitting';
import {createFormStyles} from '@/forms/DynamicForm/styles';
import {useEvent, useThemedStyles} from '@/hooks';

const InnerForm = ({
  isSubmitting,
  formSchema,
  onSubmitValidationError,
  componentsRegistry,
  isValid,
  validateForm,
  submitForm,
  onCancel,
  onAction,
  onChange,
}) => {
  const [styles] = useThemedStyles(createFormStyles);
  const handleChange = useEvent((key, value) => {
    onChange(key, value);
    // Force run the validation to allow submitting valid forms.
    // See https://github.com/jaredpalmer/formik/issues/2083
    setTimeout(validateForm, 100);
  });
  return (
    <Fragment>
      {isSubmitting && <Submitting text={formSchema.submittingText} />}
      {onSubmitValidationError && (
        <OnSubmitValidationError callback={onSubmitValidationError} />
      )}
      <View style={styles.form}>
        {formSchema.fields.map((field, i) => {
          const name = Array.isArray(field.name) ? field.name[0] : field.name;
          return (
            <Field
              key={`${name}-${i}`}
              name={name}
              config={field}
              component={componentsRegistry.get(field.type)}
              onAction={onAction}
              onChange={handleChange}
            />
          );
        })}
      </View>
      <FormButtons
        {...{
          formSchema,
          isSubmitting,
          isValid,
          onCancel,
          onSubmit: submitForm,
          onAction,
        }}
      />
    </Fragment>
  );
};

export default InnerForm;
