export const formatDateValue = (value = {}) => {
  const {day, month, year} = value || {};
  return day && month && year
    ? new Date(year, month, day).toISOString()
    : undefined;
};

/**
 * Formats the values before pass them to the onSubmit handler
 */
export const formatValues = (values, fields) => {
  const data = {...values};
  fields
    .filter(field => field.type === 'date')
    .forEach(field => {
      data[field.name] = formatDateValue(values[field.name]);
    });
  return data;
};
