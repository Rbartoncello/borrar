import {
  ActionLink,
  BoolField,
  CameraField,
  CheckboxListField,
  ChipListField,
  DateField,
  DocumentField,
  DocumentsField,
  ErrorFeedback,
  NumberField,
  PhotoField,
  PhotosField,
  PhotoWithDateField,
  PhotoWithNumberField,
  PhotoWithSelectField,
  SelectField,
  SubsectionsField,
  TextAreaField,
  TextField,
  Title,
} from '../fields';

/**
 * Builds a registry of components to quick and dynamic access.
 */
class ComponentsRegistry {
  /**
   * @param {Array<string, object>[]} components Custom components to be added to the registry.
   */
  constructor(components) {
    this.components = {};
    this.add(ActionLink, 'actionLink');
    this.add(BoolField, 'bool');
    this.add(CameraField, 'camera');
    this.add(CheckboxListField, 'checkboxList');
    this.add(ChipListField, 'chip');
    this.add(DateField, 'date');
    this.add(DocumentField, 'document');
    this.add(DocumentsField, 'documents');
    this.add(ErrorFeedback, 'error');
    this.add(NumberField, 'number');
    this.add(PhotoField, 'photo');
    this.add(PhotosField, 'photos');
    this.add(PhotoWithSelectField, 'photoWithSelect');
    this.add(PhotoWithDateField, 'photoWithDate');
    this.add(PhotoWithNumberField, 'photoWithNumber');
    this.add(SelectField, 'select');
    this.add(SubsectionsField, 'subsections');
    this.add(TextAreaField, 'textArea');
    this.add(TextField, 'text');
    this.add(Title, 'title');

    if (components) {
      components.forEach(component => this.add(component[1], component[0]));
    }
  }

  /**
   * Add a component to the registry.
   * @param component a component to add to the registry.
   * @param {string} key a key to lookup the component in the registry.
   * component.displayName is used if a key is not given.
   */
  add(component, key = null) {
    const name = key || component.displayName;
    if (!name) {
      throw new Error(
        'ComponentsRegistry: displayName is required to support minification if a key is not given.',
      );
    }
    this.components[name] = component;
  }

  /**
   * Returns a component from the registry.
   * @param {string} key a key to look up for the component.
   * @returns {*} Returns the found component or `undefined`.
   */
  get(key) {
    const component = this.components[key];
    if (!component) {
      throw new Error(`ComponentsRegistry: component ${key} not registered.`);
    }
    return component;
  }
}

export default ComponentsRegistry;
