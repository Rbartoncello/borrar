import {useTranslation} from 'react-i18next';
import {Text} from 'react-native';

const Submitting = ({text = 'pleaseWait'}) => {
  const {t} = useTranslation();
  return <Text>{t(text)}</Text>;
};

export default Submitting;
