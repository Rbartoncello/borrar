import {connect} from 'formik';
import {ErrorFeedback} from '../fields';

const config = {
  label: 'You have not filled all the required fields correctly.',
};

export const SubmissionError = ({formik: {isValid, submitCount}}) =>
  !!submitCount && !isValid && <ErrorFeedback config={config} />;

export default connect(SubmissionError);
