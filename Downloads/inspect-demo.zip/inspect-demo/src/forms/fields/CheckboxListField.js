import getFieldError from './getFieldError';
import useChange from './useChange';
import {CheckboxList} from '@/components';

const CheckboxListField = ({field, config, form, onChange}) => {
  const handleChange = useChange(form, field, onChange);
  return (
    <CheckboxList
      options={config.options}
      label={config.label}
      onChange={handleChange}
      value={field.value}
      disabled={config.disabled}
      errorMessage={getFieldError(form, field)}
    />
  );
};

export default CheckboxListField;
