import {View} from 'react-native';
import {createCameraStyles} from './styles';
import {Button, Camera} from '@/components';
import {useThemedStyles, useEvent, useBoolean} from '@/hooks';
import {Camera as CameraIcon} from '@/icons';
import {isString} from '@/util';

export const CameraField = ({form, onChange, config}) => {
  const [modalCamera, setModalCamera] = useBoolean(false);
  const [styles] = useThemedStyles(createCameraStyles);
  const handleClose = useEvent((values, isComplete) => {
    setModalCamera.off();
    if (values) {
      Object.keys(values).map(key => {
        const {hidden = false} = config.fields.find(field =>
          Array.isArray(field.name) ? field.name[0] : field.name === key,
        );
        if (values[key]?.registrationName) {
          console.error('The user canceled the action');
          return;
        }
        if (values[key] === 'object' || isString(values[key])) {
          const isPhoto =
            isString(values[key]) && values[key].startsWith('file:');
          form.setFieldValue(
            key,
            isPhoto
              ? {
                  hidden,
                  value: values[key],
                }
              : values[key],
          );
          onChange(key, isPhoto ? {hidden, value: values[key]} : values[key]);
        }
      });
      if (isComplete) {
        setTimeout(form.submitForm, 250);
      }
    }
  });
  return (
    <View style={styles.container}>
      <Camera
        visible={modalCamera}
        photoFields={config.fields}
        onClose={handleClose}
      />
      <Button
        containerStyle={styles.buttonContainer}
        buttonStyle={styles.button}
        onPress={setModalCamera.on}>
        {config.label || <CameraIcon strokeWidth={2} />}
      </Button>
    </View>
  );
};

export default CameraField;
