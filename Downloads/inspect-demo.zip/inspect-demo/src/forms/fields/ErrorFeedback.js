import {useTranslation} from 'react-i18next';
import {createErrorFeedbackStyles} from './styles';
import {Text} from '@/components';
import {useThemedStyles} from '@/hooks';

export const ErrorFeedback = ({config}) => {
  const [styles] = useThemedStyles(createErrorFeedbackStyles);
  const {t} = useTranslation();
  return !!config.label && <Text style={styles.text}>{t(config.label)}</Text>;
};

export default ErrorFeedback;
