import {Fragment} from 'react';
import {useTranslation} from 'react-i18next';
import {BoolSelector, ConfirmDialog, Text} from '@/components';
import {useBoolean} from '@/hooks';

const hasLoadedFlaws = form => Object.keys(form.values).length > 1;

const BoolField = ({field, form, config = {}, onChange, ...props}) => {
  const {t} = useTranslation('inspection');
  const [showConfirm, setShowConfirm] = useBoolean();
  const setValue = value => {
    form.setFieldValue(field.name, value);
    onChange(field.name, value);
    if (value === false) {
      setTimeout(form.submitForm, 151);
    }
  };
  const handleChange = value => {
    if (value === false && hasLoadedFlaws(form)) {
      return setShowConfirm.on();
    }
    setValue(value);
  };
  const handleAccept = () => {
    setShowConfirm.off();
    setValue(false);
  };
  return (
    <Fragment>
      {showConfirm && (
        <ConfirmDialog
          title="inspection:approvePromptTitle"
          acceptText="inspection:approve"
          onAccept={handleAccept}
          onCancel={setShowConfirm.off}>
          <Text>{t('inspection:approvePromptMessage')}</Text>
        </ConfirmDialog>
      )}
      <BoolSelector
        {...props}
        {...config}
        value={field.value}
        onChange={handleChange}
      />
    </Fragment>
  );
};

export default BoolField;
