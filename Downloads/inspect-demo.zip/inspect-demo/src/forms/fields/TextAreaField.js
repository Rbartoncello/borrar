import getFieldError from './getFieldError';
import {createInputStyles} from './styles';
import useChange from './useChange';
import {TextArea} from '@/components';
import {useThemedStyles} from '@/hooks';

const TextAreaField = ({field, form, config, onChange, ...props}) => {
  const [styles] = useThemedStyles(createInputStyles);
  const handleChange = useChange(form, field, onChange);
  return (
    <TextArea
      {...field}
      {...props}
      label={config.label}
      disabled={config.disabled}
      placeholder={config.placeholder}
      errorMessage={getFieldError(form, field)}
      labelStyle={styles.label}
      onFocus={() => form.setFieldTouched(field.name)}
      onBlur={() => form.handleBlur(field.name)}
      onChange={handleChange}
    />
  );
};

export default TextAreaField;
