export const createSubsectionsStyles = theme => ({
  container: {
    width: '100%',
    marginBottom: theme.spacing.marginVertical * 2,
  },
});

export const createTitleStyles = theme => ({
  text: {
    width: '100%',
    paddingHorizontal: theme.spacing.paddingHorizontal,
    paddingBottom: theme.spacing.paddingHorizontal,
    textAlign: 'center',
  },
});

export const createErrorFeedbackStyles = theme => ({
  text: {
    paddingVertical: theme.spacing.paddingVertical * 2,
    color: theme.colors.red800,
  },
});

export const createInputStyles = theme => ({
  label: {
    marginVertical: 2,
    fontWeight: 'bold',
    color: theme.colors.black,
    fontSize: theme.typography.regular.fontSize,
    paddingBottom: theme.spacing.paddingVertical / 2,
  },
});

export const createCameraStyles = theme => ({
  container: {
    width: '100%',
  },
  button: {
    paddingVertical: theme.spacing.paddingVertical,
    backgroundColor: theme.colors.blue700,
  },
  buttonContainer: {
    alignSelf: 'center',
    marginHorizontal: 0,
  },
});
