import {useEffect} from 'react';
import {View} from 'react-native';
import {createSubsectionsStyles} from './styles';
import {SubsectionList} from '@/components';
import {useThemedStyles} from '@/hooks';

const SubsectionsField = ({form, config, section, onAction, onChange}) => {
  const [styles] = useThemedStyles(createSubsectionsStyles);
  useEffect(() => {
    form.setFieldValue('subsections', config.values);
    onChange('subsections', config.values);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [config.values]);
  return (
    <View style={styles.container}>
      <SubsectionList
        subsections={config.subsections}
        chapter={config.chapter}
        sectionName={section}
        values={config.values}
        disabled={config.disabled}
        onAdd={e => onAction('add', e)}
        onEdit={e => onAction('edit', {...e, values: config.values})}
        onRemove={e => onAction('remove', {...e, values: config.values})}
      />
    </View>
  );
};

export default SubsectionsField;
