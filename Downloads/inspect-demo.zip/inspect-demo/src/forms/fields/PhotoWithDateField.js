import {Field} from 'formik';
import DateField from './DateField';
import PhotoField from './PhotoField';
import {DateUtilService} from '@/services';

const dateUtil = new DateUtilService();

const getValidation = (validations, validationTypes) => {
  const validation = validations?.find(({type}) =>
    validationTypes.includes(type),
  );
  return validation ? dateUtil.tryParseOrDefault(validation.value) : undefined;
};

const PhotoWithDateField = ({field, config, options, onChange, ...props}) => (
  <PhotoField
    {...props}
    name={config.name[0]}
    field={field}
    config={config}
    onChange={onChange}>
    <Field
      {...props}
      name={config.name[1]}
      config={{
        minimumDate: getValidation(config.validations, ['min', 'past']),
        maximumDate: getValidation(config.validations, ['max', 'future']),
        placeholder: config.caption,
      }}
      component={DateField}
      onChange={onChange}
    />
  </PhotoField>
);

export default PhotoWithDateField;
