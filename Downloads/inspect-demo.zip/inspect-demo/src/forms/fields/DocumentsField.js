import getFieldError from './getFieldError';
import useChange from './useChange';
import {DocumentsPicker} from '@/components';
import {ErrorFeedback} from '@/forms/fields';

const DocumentsField = ({field, form, config, onChange, ...props}) => {
  const handleChange = useChange(form, field, onChange);
  return (
    <>
      <DocumentsPicker
        {...props}
        value={field.value}
        type={config.type}
        disabled={config.disabled}
        onChange={handleChange}
      />
      <ErrorFeedback config={{label: getFieldError(form, field)}} />
    </>
  );
};

export default DocumentsField;
