import {Field} from 'formik';
import NumberField from './NumberField';
import PhotoField from './PhotoField';

const PhotoWithNumberField = ({field, config, options, onChange, ...props}) => (
  <PhotoField
    {...props}
    name={config.name[0]}
    field={field}
    config={config}
    onChange={onChange}>
    <Field
      {...props}
      name={config.name[1]}
      config={{placeholder: config.caption}}
      component={NumberField}
      onChange={onChange}
    />
  </PhotoField>
);

export default PhotoWithNumberField;
