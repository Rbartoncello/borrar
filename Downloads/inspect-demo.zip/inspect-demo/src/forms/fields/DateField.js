import getFieldError from './getFieldError';
import useChange from './useChange';
import {DateInput} from '@/components';

const DateField = ({field, form, config, onChange, ...props}) => {
  const handleChange = useChange(form, field, onChange);
  return (
    <DateInput
      {...field}
      {...props}
      label={config.label}
      disabled={config.disabled}
      textStyles={config.textStyles}
      labelStyles={config.labelStyles}
      iconColor={config.iconColor}
      placeholder={config.placeholder}
      minimumDate={config.minimumDate}
      maximumDate={config.maximumDate}
      inputContainerStyle={config.inputContainerStyle}
      errorMessage={getFieldError(form, field)}
      onChange={handleChange}
    />
  );
};

export default DateField;
