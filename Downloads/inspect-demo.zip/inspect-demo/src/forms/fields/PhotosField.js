import useChange from './useChange';
import {ImagesPicker} from '@/components';

const PhotosField = ({field, form, config, onChange, ...props}) => {
  const handleChange = useChange(form, field, onChange);
  return (
    <ImagesPicker
      {...props}
      defaultValue={field.value}
      label={config.label}
      caption={config.caption}
      onChange={handleChange}
      hidden={config.hidden}
    />
  );
};

export default PhotosField;
