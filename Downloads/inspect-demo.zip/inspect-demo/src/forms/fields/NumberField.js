import {Platform} from 'react-native';
import TextField from './TextField';

const keyboardType = Platform.select({
  android: () => 'numeric',
  ios: () => 'number-pad',
  default: () => undefined,
})();

const NumberField = props => (
  <TextField keyboardType={keyboardType} {...props} />
);

export default NumberField;
