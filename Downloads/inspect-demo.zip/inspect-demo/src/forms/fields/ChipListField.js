import {useEffect} from 'react';
import getFieldError from './getFieldError';
import useChange from './useChange';
import {ChipList} from '@/components';

const ChipListField = ({field, config, form, onChange}) => {
  const handleChange = useChange(form, field, onChange);
  useEffect(() => {
    if (field.value?.length) {
      // clean not available chips from previous options.
      const value = field.value.filter(val =>
        config.options.find(option => option.value === val),
      );
      if (value.length !== field.value.length) {
        handleChange(value);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [config.options]);
  return (
    <ChipList
      options={config.options}
      label={config.label}
      onChange={handleChange}
      value={field.value}
      errorMessage={getFieldError(form, field)}
    />
  );
};

export default ChipListField;
