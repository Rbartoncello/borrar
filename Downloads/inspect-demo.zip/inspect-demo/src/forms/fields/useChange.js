import {useEvent} from '@/hooks';

const useChange = (form, field, onChange) =>
  useEvent(value => {
    form.setFieldValue(field.name, value);
    onChange(field.name, value);
  });

export default useChange;
