import getFieldError from './getFieldError';
import useChange from './useChange';
import {DocumentPicker} from '@/components';

const DocumentField = ({field, form, config, onChange, children, ...props}) => {
  const handleChange = useChange(form, field, onChange);
  return (
    <DocumentPicker
      {...props}
      label={config.label}
      value={field.value}
      placeholder={config.placeholder}
      type={config.type}
      disabled={config.disabled}
      errorMessage={getFieldError(form, field)}
      onChange={handleChange}
      hidden={config.hidden}>
      {children}
    </DocumentPicker>
  );
};

export default DocumentField;
