const getErrorText = (errors, touched, field) =>
  touched[field] ? errors[field] : undefined;

export default getErrorText;
