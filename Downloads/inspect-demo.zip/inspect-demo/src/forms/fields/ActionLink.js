import {Button} from '@/components';

export const ActionLink = ({config, onAction}) => (
  <Button type="clear" onPress={() => onAction(config.name)}>
    {config.label}
  </Button>
);

export default ActionLink;
