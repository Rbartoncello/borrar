import getFieldError from './getFieldError';
import useChange from './useChange';
import {CarImagePicker} from '@/components';

const PhotoField = ({field, form, config, onChange, children, ...props}) => {
  const handleChange = useChange(form, field, onChange);
  return (
    <CarImagePicker
      {...props}
      label={config.label}
      value={field.value?.value}
      placeholder={config.placeholder}
      type={config.type}
      errorMessage={getFieldError(form, field)}
      onChange={handleChange}
      hidden={config.hidden}>
      {children}
    </CarImagePicker>
  );
};

export default PhotoField;
