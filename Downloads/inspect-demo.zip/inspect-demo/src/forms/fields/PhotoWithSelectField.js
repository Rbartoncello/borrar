import {Field} from 'formik';
import PhotoField from './PhotoField';
import SelectField from './SelectField';

const PhotoWithSelectField = ({field, config, onChange, ...props}) => (
  <PhotoField
    {...props}
    name={config.name[0]}
    field={field}
    config={config}
    onChange={onChange}>
    <Field
      {...props}
      name={config.name[1]}
      config={{...config, placeholder: config.caption, label: undefined}}
      component={SelectField}
      onChange={onChange}
    />
  </PhotoField>
);

export default PhotoWithSelectField;
