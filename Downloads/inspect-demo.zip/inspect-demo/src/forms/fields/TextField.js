import getFieldError from './getFieldError';
import {createInputStyles} from './styles';
import useChange from './useChange';
import {TextInput} from '@/components';
import {useThemedStyles} from '@/hooks';

const TextField = ({field, form, config, onChange}) => {
  const [styles] = useThemedStyles(createInputStyles);
  const handleChange = useChange(form, field, onChange);
  return (
    <TextInput
      {...field}
      label={config.label}
      disabled={config.disabled}
      placeholder={config.placeholder}
      errorMessage={getFieldError(form, field)}
      onFocus={() => form.setFieldTouched(field.name)}
      onBlur={() => form.handleBlur(field.name)}
      labelStyle={[styles.label, config.labelStyles]}
      inputContainerStyle={config.inputContainerStyle}
      onChange={handleChange}
    />
  );
};

export default TextField;
