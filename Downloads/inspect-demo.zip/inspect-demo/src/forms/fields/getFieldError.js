/**
 * Returns the error to show on the HTML form
 * @param form The wrapper Form
 * @param {number} form.submitCount Number of times user tried to submit the form
 * @param form.touched Touched fields.
 * @param form.errors Form validation errors.
 * @param field A given field
 * @param {string} field.name The field name
 * @return {string} Error message
 */
const getFieldError = ({submitCount, touched, errors}, {name}) =>
  submitCount || !!touched[name] ? errors[name] : undefined;

export default getFieldError;
