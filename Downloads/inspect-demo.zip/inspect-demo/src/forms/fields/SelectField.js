import getFieldError from './getFieldError';
import {createInputStyles} from './styles';
import useChange from './useChange';
import {Select} from '@/components';
import {useThemedStyles} from '@/hooks';

/**
 * Filter the options that should be hidden.
 * @returns {Array<*>} The options for the select field.
 */
const getOptions = ({hiddenOptions, options}) =>
  hiddenOptions?.length > 0
    ? options.filter(option => !hiddenOptions.includes(option.value))
    : options;

const SelectField = ({field, form, config, onChange = () => {}, ...props}) => {
  const [styles] = useThemedStyles(createInputStyles);
  const handleChange = useChange(form, field, onChange);
  return (
    <Select
      {...field}
      {...props}
      label={config.label}
      value={field.value}
      options={getOptions(config)}
      disabled={config.disabled}
      placeholder={config.placeholder}
      valueKey={config.valueKey}
      labelKey={config.labelKey}
      errorMessage={getFieldError(form, field)}
      onChange={handleChange}
      labelStyle={styles.label}
    />
  );
};

export default SelectField;
