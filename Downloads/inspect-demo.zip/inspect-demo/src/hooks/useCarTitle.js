import {useSelector} from 'react-redux';
import {SITES} from '@/constants';
import {selectSite} from '@/state/selector/session';

const useCarTitle = inspection => {
  const site = useSelector(selectSite);
  if (!inspection?.car) {
    return '';
  }
  const {car} = inspection;
  return car.brand
    ? `${car.brand.name} ${car.model.name} ${
        site === SITES.AR ? car.assembly : car.year
      }`
    : car.plate;
};

export default useCarTitle;
