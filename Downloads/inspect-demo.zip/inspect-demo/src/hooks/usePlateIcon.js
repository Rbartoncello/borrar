import {useTranslation} from 'react-i18next';
import {LANGUAGES} from '@/constants';
import {PlateAr, PlateBr} from '@/icons';

const usePlateIcon = () => {
  const {i18n} = useTranslation();
  switch (i18n.language) {
    case LANGUAGES.ES:
      return PlateAr;
    case LANGUAGES.PT:
      return PlateBr;
    default:
      return undefined;
  }
};

export default usePlateIcon;
