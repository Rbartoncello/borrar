import {useEffect} from 'react';
import {useTranslation} from 'react-i18next';
import {Alert, Platform} from 'react-native';
import useBoolean from './useBoolean';

const useAlertStatusError = status => {
  const {t} = useTranslation();
  const [isFetching, setIsFetching] = useBoolean();
  useEffect(() => {
    if (status.isFetching) {
      setIsFetching.on();
    } else if (isFetching && status.isError) {
      setIsFetching.off();
      Platform.select({
        native: () =>
          Alert.alert(undefined, t('errorMessage'), [t('ok')], {
            cancelable: true,
          }),
        // eslint-disable-next-line no-alert
        default: () => window.alert('errorMessage'),
      })();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, isFetching]);
};

export default useAlertStatusError;
