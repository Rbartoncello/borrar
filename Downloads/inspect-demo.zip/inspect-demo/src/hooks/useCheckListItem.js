import {useEvent} from '@/hooks/index';

const useCheckListItem = (value, onChange) =>
  useEvent(option => {
    const hasValue = value.includes(option.value);
    const newValues = hasValue
      ? value.filter(opt => opt !== option.value)
      : [...value, option.value];
    onChange(newValues);
  });

export default useCheckListItem;
