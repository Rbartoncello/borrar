import {useMemo} from 'react';
import {useSelector} from 'react-redux';
import {selectQuestionnaireOptions} from '@/state/selector/staticData';

const useHasIterableSubsectionOptionsAvailable = (subsection, values) => {
  const options = useSelector(selectQuestionnaireOptions);
  return useMemo(() => {
    const field = subsection.fields.find(f => f.name === subsection.iteratee);
    return values.length < options[field.options].length;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [subsection, values.length]);
};

export default useHasIterableSubsectionOptionsAvailable;
