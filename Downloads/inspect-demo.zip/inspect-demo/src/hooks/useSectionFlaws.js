import {useMemo} from 'react';

/**
 * Get the detail of a given flaw using the status field.
 * @returns {Array<string>} The status of the issue.
 */
const getStatus = (subsection, values) => {
  const statusField = subsection.fields.find(field => field.type === 'chip');
  return values[statusField.name];
};

const getIterateeSubsectionFlaws = (subsection, values) =>
  values.map(value => ({
    name: value[subsection.iteratee],
    status: getStatus(subsection, value),
  }));

/**
 * Get the subsections' flaws of a given section.
 * @param section The section to get the subsections' flaws from.
 * @param values The answer for the subsections.
 */
const getSubsectionFlaws = (section, values) =>
  values
    ? Object.entries(values).flatMap(([key, value]) => {
        const subsection = section.subsections.find(x => x.name === key);
        if (Array.isArray(value)) {
          return getIterateeSubsectionFlaws(subsection, value);
        }
        if (Object.keys(value).length) {
          return {
            name: subsection.label,
            status: getStatus(subsection, value),
          };
        }
      })
    : [];

/**
 * Get flaws with status of a given section.
 */
const useSectionFlaws = (section, values) =>
  useMemo(
    () =>
      section.fields
        .flatMap(field => {
          switch (field.type) {
            case 'checkboxList':
              if (!values[field.name]) {
                return;
              }
              return values[field.name].map(name => ({name}));
            case 'photoWithSelect':
              const value = values[field.name[1]];
              if (!value) {
                return;
              }
              const isApproved =
                field.approvedOptions?.includes(value) ?? false;
              return !isApproved
                ? {name: field.label, status: [value]}
                : undefined;
            default:
              return;
          }
        })
        .concat(getSubsectionFlaws(section, values?.subsections))
        .filter(x => x),
    [section, values],
  );

export default useSectionFlaws;
