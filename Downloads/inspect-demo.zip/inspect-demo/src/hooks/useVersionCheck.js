import {useEffect} from 'react';
import {useTranslation} from 'react-i18next';
import {Alert, BackHandler, Linking} from 'react-native';
import VersionCheck from 'react-native-version-check';

const useVersionCheck = () => {
  const {t} = useTranslation();
  useEffect(() => {
    checkVersion();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const checkVersion = async () => {
    try {
      const version = await VersionCheck.needUpdate();
      if (version?.isNeeded) {
        Alert.alert(
          t('updateRequired'),
          t('mustUpdateApp'),
          [
            {
              text: t('Update'),
              onPress: () => {
                BackHandler.exitApp();
                Linking.openURL(version.storeUrl);
              },
            },
          ],
          {cancelable: false},
        );
      }
    } catch (err) {
      console.log(err);
    }
  };
};

export default useVersionCheck;
