import {useCallback} from 'react';
import {useTranslation} from 'react-i18next';
import {Alert, Platform} from 'react-native';
import ImagePicker from 'react-native-image-crop-picker';

export const openPicker = async (fromCamera, onChange) => {
  try {
    const openImagePicker = fromCamera
      ? ImagePicker.openCamera
      : ImagePicker.openPicker;
    const {path} = await openImagePicker({
      mediaType: 'photo',
      showCropFrame: true,
      compressImageMaxWidth: 2560,
      compressImageMaxHeight: 1440,
      compressImageQuality: 0.8,
      enableRotationGesture: true,
    });
    onChange(path);
  } catch (err) {
    console.error(err);
  }
};

const useImagePicker = onChange => {
  const {t} = useTranslation();
  return useCallback(
    () =>
      Platform.select({
        native: () =>
          Alert.alert(
            null,
            t('uploadPhotoAlert'),
            [
              {text: t('cancel')},
              {
                text: t('takePhoto'),
                onPress: () => openPicker(true, onChange),
              },
              {
                text: t('chooseFromGallery'),
                onPress: () => openPicker(false, onChange),
              },
            ],
            {cancelable: true},
          ),
        // eslint-disable-next-line no-alert
        default: () => window.alert('Not implemented.'),
      })(),
    [t, onChange],
  );
};

export default useImagePicker;
