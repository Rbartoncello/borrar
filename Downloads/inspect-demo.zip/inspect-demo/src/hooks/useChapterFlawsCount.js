import {useMemo} from 'react';

const getSubsectionFlawsCount = subsections =>
  subsections
    ? Object.keys(subsections).reduce((accum, key) => {
        const subsection = subsections[key];
        if (Array.isArray(subsection)) {
          return accum + subsection.length;
        }
        return subsection ? accum + 1 : accum;
      }, 0)
    : 0;

/**
 * Count photos with flaws, and checked boxes, in a given section.
 * @returns {number} Count of flaws in a given section.
 */
const getSectionFlawsCount = (section, values) =>
  section.fields
    .filter(field => field.type === 'checkboxList')
    .reduce((accum, field) => {
      const value = values[field.name];
      return Array.isArray(value) ? accum + value.length : accum;
    }, 0) +
  section.fields
    .filter(field => field.type === 'photoWithSelect')
    .reduce((accum, field) => {
      const isApproved =
        field.approvedOptions?.includes(values[field.name[1]]) ?? false;
      return !isApproved ? accum + 1 : accum;
    }, 0);

const useChapterFlawsCount = (chapter, values) =>
  useMemo(
    () =>
      values
        ? chapter.sections
            ?.filter(section => values[section.name])
            .reduce(
              (accum, section) =>
                accum +
                getSectionFlawsCount(section, values[section.name]) +
                getSubsectionFlawsCount(values[section.name].subsections),
              0,
            )
        : 0,
    [chapter, values],
  );

export default useChapterFlawsCount;
