import {
  CommonActions,
  useNavigation,
  TabActions,
} from '@react-navigation/native';
import {useMemo} from 'react';

const useNavigator = () => {
  const navigation = useNavigation();
  return useMemo(
    () => ({
      dispatch: navigation.dispatch,
      goBack: () => navigation.dispatch(CommonActions.goBack()),
      navigate: (name, params) =>
        navigation.dispatch(
          CommonActions.navigate({
            name,
            params,
          }),
        ),
      jumpTo: (name, params) =>
        navigation.dispatch(TabActions.jumpTo(name, params)),
      reset: name =>
        navigation.dispatch(
          CommonActions.reset({
            index: 1,
            routes: [{name: name}],
          }),
        ),
    }),
    [navigation],
  );
};

export default useNavigator;
