import {useMemo} from 'react';

const useChapterProgress = (sections, chapterValues) =>
  useMemo(() => {
    if (!sections) {
      return 100;
    }
    const completedSections = sections.filter(
      section =>
        !!chapterValues?.[section.name] &&
        Object.keys(chapterValues[section.name]).some(
          key => key !== 'subsections',
        ),
    );
    return Math.round((completedSections.length * 100) / sections.length);
  }, [chapterValues, sections]);

export default useChapterProgress;
