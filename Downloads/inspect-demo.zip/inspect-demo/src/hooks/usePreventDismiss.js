import {useNavigation} from '@react-navigation/native';
import {useEffect, useState} from 'react';
import {useTranslation} from 'react-i18next';
import {useBoolean} from '@/hooks/index';

const usePreventDismiss = isDirty => {
  const {t} = useTranslation();
  const navigation = useNavigation();
  const [dismiss, setDismiss] = useBoolean(false);
  const [action, setAction] = useState();
  useEffect(
    () =>
      navigation.addListener('beforeRemove', e => {
        if (isDirty) {
          e.preventDefault();
          setAction(e.data.action);
          setDismiss.on();
        }
      }),
    [isDirty, navigation, setDismiss, t],
  );
  return [dismiss, setDismiss, action];
};

export default usePreventDismiss;
