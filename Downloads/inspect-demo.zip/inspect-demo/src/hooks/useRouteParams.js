import {useRoute} from '@react-navigation/native';

const useRouteParams = () => useRoute().params;

export default useRouteParams;
