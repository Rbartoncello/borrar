import {useMemo} from 'react';

/**
 * Create a source object.
 * @param uri {String} The URI of the given source.
 * @return {{uri: String}} The Source object.
 */
const useSourceUri = uri => useMemo(() => ({uri}), [uri]);

export default useSourceUri;
