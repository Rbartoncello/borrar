export const AR_PLATE_REGEX = /^[a-z]{2}([a-z]\d{3}|\d{3}[a-z]{2})$/i;
export const BR_PLATE_REGEX = /^[a-z\d]{7}$/i;
export const LANGUAGES = Object.freeze({ES: 'es', PT: 'pt'});
export const SITES = Object.freeze({BR: 'br', AR: 'ar'});
export const SEARCH_STORE_MIN_LENGTH = 4;
export const INSPECTION_STATUS = {
  PENDING: 'pending',
  CLOSED: 'closed',
};
export const DEMO_USERS = Object.freeze([
  'demoar@karvi.com',
  'demobr@karvi.com',
]);
