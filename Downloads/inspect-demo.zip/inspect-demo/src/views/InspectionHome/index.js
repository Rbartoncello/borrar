import {Fragment} from 'react';
import {useTranslation} from 'react-i18next';
import {View, FlatList} from 'react-native';
import {connect} from 'react-redux';
import createStyles from './styles';
import {Header, InspectionCard, Text, Button} from '@/components';
import {useCarTitle, useNavigation, useThemedStyles} from '@/hooks';
import Routes from '@/navigation/routes';
import {
  selectInspection,
  selectInspectionProgress,
  selectInspectionStatus,
} from '@/state/selector/inspection';
import {selectQuestionnaire} from '@/state/selector/staticData';

const renderItem = (chapter, values) => (
  <InspectionCard chapter={chapter} values={values} />
);

const InspectionHome = ({inspection, progress, questionnaire, status}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createStyles);
  const {navigate} = useNavigation();
  const title = useCarTitle(inspection);
  return (
    <Fragment>
      <Header title={title} caption={inspection.car?.plate} />
      <View style={styles.container}>
        {status.isFetching && <Text>Loading...</Text>}
        <FlatList
          columnWrapperStyle={styles.column}
          numColumns={2}
          data={questionnaire?.chapters}
          renderItem={({item}) => renderItem(item, inspection[item.name])}
          keyExtractor={item => item.name}
          ListFooterComponent={
            progress === 100 && (
              <View style={styles.containerButtonFooter}>
                <Button onPress={() => navigate(Routes.INSPECTION_RESUME)}>
                  {t('inspection:resumeButton')}
                </Button>
              </View>
            )
          }
        />
      </View>
    </Fragment>
  );
};

export default connect(state => ({
  inspection: selectInspection(state),
  progress: selectInspectionProgress(state),
  questionnaire: selectQuestionnaire(state),
  status: selectInspectionStatus(state),
}))(InspectionHome);
