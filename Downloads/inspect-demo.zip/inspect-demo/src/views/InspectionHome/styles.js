const createStyles = theme => ({
  container: {
    flex: 1,
    padding: theme.spacing.paddingVertical * 1.5,
    backgroundColor: theme.colors.grey100,
  },
  column: {flex: 1, justifyContent: 'space-evenly'},
  containerButtonFooter: {
    paddingVertical: 16,
    marginTop: 80,
  },
});

export default createStyles;
