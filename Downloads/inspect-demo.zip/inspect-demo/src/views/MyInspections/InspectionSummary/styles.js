const createStyles = theme => ({
  container: {
    paddingHorizontal: theme.spacing.paddingHorizontal,
  },
  separator: {
    height: 1,
    backgroundColor: theme.colors.grey200,
    alignSelf: 'stretch',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: theme.spacing.paddingVertical + 2,
  },
  rowMarginBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: theme.spacing.paddingVertical + 2,
    marginBottom: theme.spacing.paddingVertical,
  },
  carName: {flex: 1, fontSize: theme.typography.regular.fontSize},
  dot: {
    height: 15,
    width: 15,
    borderRadius: 8,
  },
  title: {flex: 1, marginLeft: 6, fontSize: theme.typography.small.fontSize},
  plate: {marginLeft: 16},
  buttonIcon: {
    marginLeft: theme.spacing.paddingVertical,
    color: theme.colors.brandPrimary,
  },
  buttonContainer: {
    alignSelf: 'flex-end',
  },
});

export default createStyles;
