import PropTypes from 'prop-types';
import {useTranslation} from 'react-i18next';
import {Pressable, View} from 'react-native';
import createStyles from './styles';
import {Text, ProgressBar, Button, Menu} from '@/components';
import {INSPECTION_STATUS} from '@/constants';
import {
  useBoolean,
  useCarTitle,
  useEvent,
  usePlateIcon,
  useThemedStyles,
} from '@/hooks';
import {
  ArrowRightToClipboard,
  Circle,
  EllipsisVertical,
  LocationDot,
  TrashCan,
} from '@/icons';

const InspectionSummary = ({
  inspection,
  onEdit,
  onReopen,
  onRemove,
  status = INSPECTION_STATUS.PENDING,
}) => {
  const {t} = useTranslation();
  const [styles, theme] = useThemedStyles(createStyles);
  const [showMenu, setShowMenu] = useBoolean();
  const title = useCarTitle(inspection);
  const PlateIcon = usePlateIcon();
  const handleStart = useEvent(() => onEdit({id: inspection.id}));
  const options =
    status === INSPECTION_STATUS.CLOSED
      ? [
          {
            icon: <ArrowRightToClipboard color={theme.colors.black} />,
            label: 'inspection:reopenInspection',
            onPress: () => onReopen(inspection),
          },
          {
            icon: <TrashCan />,
            label: 'delete',
            onPress: () => onRemove(inspection),
          },
        ]
      : [
          {
            icon: <ArrowRightToClipboard color={theme.colors.black} />,
            label: 'inspection:startInspection',
            onPress: handleStart,
          },
          {
            icon: <TrashCan />,
            label: 'delete',
            onPress: () => onRemove(inspection),
          },
        ];
  return (
    <View style={styles.container}>
      <View style={styles.separator} />
      <View style={styles.row}>
        <Text bold style={styles.carName}>
          {title}
        </Text>
        <Pressable onPress={setShowMenu.on}>
          <EllipsisVertical />
        </Pressable>
        <Menu visible={showMenu} onClose={setShowMenu.off} options={options} />
      </View>
      <View style={styles.row}>
        {inspection.car?.color?.hex && (
          <Circle color={inspection.car.color?.hex} height={18} width={18} />
        )}
        <Text style={styles.title}>{inspection.car?.color?.name}</Text>
        <PlateIcon style={styles.plate} width={27} height={18} />
        <Text style={styles.title}>{inspection.car?.plate}</Text>
      </View>
      <View style={styles.row}>
        <LocationDot />
        <Text style={styles.title} numberOfLines={1}>
          {`${inspection.car?.store.name} - ${inspection.car?.store.address}`}
        </Text>
      </View>
      <View style={inspection.done ? styles.rowMarginBottom : styles.row}>
        <ProgressBar value={inspection.progress} />
      </View>
      {!inspection.done && (
        <View style={styles.buttonContainer}>
          <Button type="clear" onPress={handleStart}>
            <ArrowRightToClipboard strokeWidth="2" />
            <Text bold style={styles.buttonIcon}>
              {t('inspection:startInspection')}
            </Text>
          </Button>
        </View>
      )}
    </View>
  );
};

InspectionSummary.propTypes = {
  inspection: PropTypes.shape({}),
  onInitInspection: PropTypes.func,
  onDelete: PropTypes.func,
};

export default InspectionSummary;
