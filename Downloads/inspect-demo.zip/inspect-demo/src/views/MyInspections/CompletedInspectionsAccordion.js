import InspectionSummary from './InspectionSummary';
import MyInspectionsAccordionFooter from './MyInspectionsAccordionFooter';
import MyInspectionsAccordionHeader from './MyInspectionsAccordionHeader';
import {Accordion} from '@/components';
import {INSPECTION_STATUS} from '@/constants';

const CompletedInspectionsAccordion = ({
  inspections,
  onSubmit,
  onRemove,
  onReopen,
}) => (
  <Accordion
    marginHorizontal={8}
    marginVertical={10}
    header={
      <MyInspectionsAccordionHeader
        type={INSPECTION_STATUS.CLOSED}
        quantity={inspections.length}
      />
    }
    footer={
      inspections.length > 0 && (
        <MyInspectionsAccordionFooter onSubmit={onSubmit} />
      )
    }>
    {inspections.map(inspection => (
      <InspectionSummary
        key={inspection.id}
        status={INSPECTION_STATUS.CLOSED}
        inspection={inspection}
        onRemove={onRemove}
        onReopen={onReopen}
      />
    ))}
  </Accordion>
);

export default CompletedInspectionsAccordion;
