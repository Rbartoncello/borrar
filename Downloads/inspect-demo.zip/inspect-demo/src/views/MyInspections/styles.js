const createStyles = theme => ({
  containerHeader: {
    marginHorizontal: theme.spacing.baseUnit,
  },
  containerSection: {marginVertical: theme.spacing.baseUnit},
});

export default createStyles;
