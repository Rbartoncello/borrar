const createStyles = theme => ({
  container: {
    position: 'absolute',
    bottom: 42,
    right: 16,
    shadowColor: theme.colors.black,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  buttonStyle: {
    height: 60,
    paddingHorizontal: theme.spacing.paddingHorizontal * 2,
  },
  icon: {marginRight: 8},
});
export default createStyles;
