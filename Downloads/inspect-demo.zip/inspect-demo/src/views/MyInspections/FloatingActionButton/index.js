import PropTypes from 'prop-types';
import createStyles from './styles';
import {Button} from '@/components';
import {useThemedStyles} from '@/hooks';
import {CarPlus} from '@/icons';

const FloatingActionButton = ({onPress}) => {
  const [styles, theme] = useThemedStyles(createStyles);
  return (
    <Button
      title="car:newCar"
      icon={<CarPlus color={theme.colors.white} style={styles.icon} />}
      onPress={onPress}
      containerStyle={styles.container}
      buttonStyle={styles.buttonStyle}
    />
  );
};

FloatingActionButton.propTypes = {
  onPress: PropTypes.func,
};

export default FloatingActionButton;
