const createStyles = theme => ({
  container: {
    flexDirection: 'row',
    height: 70,
    alignItems: 'center',
    padding: theme.spacing.paddingHorizontal,
  },
});

export default createStyles;
