import PropTypes from 'prop-types';
import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import createStyles from './styles';
import {Text} from '@/components';
import {INSPECTION_STATUS} from '@/constants';
import {useThemedStyles} from '@/hooks';
import {CarCircleCheck, CarClockRotateRight} from '@/icons';

const MyInspectionsAccordionHeader = ({quantity = 0, type}) => {
  const [styles] = useThemedStyles(createStyles);
  const {t} = useTranslation();
  return (
    <View style={styles.container}>
      {type === INSPECTION_STATUS.PENDING ? (
        <CarClockRotateRight />
      ) : (
        <CarCircleCheck />
      )}
      <Text bold>
        {t(
          type === INSPECTION_STATUS.PENDING
            ? 'inspection:pending'
            : 'inspection:completed',
        )}
      </Text>
      <Text>{` (${quantity})`}</Text>
    </View>
  );
};

MyInspectionsAccordionHeader.propTypes = {
  quantity: PropTypes.number,
  type: PropTypes.oneOf([INSPECTION_STATUS.PENDING, INSPECTION_STATUS.CLOSED])
    .isRequired,
};

export default MyInspectionsAccordionHeader;
