const createStyles = theme => ({
  container: {
    paddingHorizontal: theme.spacing.paddingHorizontal,
  },
  buttonIcon: {
    marginLeft: theme.spacing.paddingVertical,
    color: theme.colors.brandPrimary,
  },
  separator: {
    height: 1,
    backgroundColor: theme.colors.grey200,
    alignSelf: 'stretch',
  },
  buttonContainer: {
    alignSelf: 'flex-end',
    height: theme.spacing.baseUnit * 3.2,
  },
});

export default createStyles;
