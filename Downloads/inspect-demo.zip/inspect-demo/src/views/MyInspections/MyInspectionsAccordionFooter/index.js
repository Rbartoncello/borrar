import PropTypes from 'prop-types';
import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import createStyles from './styles';
import {Text, Button} from '@/components';
import {useThemedStyles} from '@/hooks';
import {ArrowUpFromBracket} from '@/icons';

const MyInspectionsAccordionFooter = ({onSubmit}) => {
  const [styles] = useThemedStyles(createStyles);
  const {t} = useTranslation();
  return (
    <View style={styles.container}>
      <View style={styles.separator} />
      <View style={styles.buttonContainer}>
        <Button type="clear" onPress={onSubmit}>
          <ArrowUpFromBracket />
          <Text bold style={styles.buttonIcon}>
            {t('sendInspections')}
          </Text>
        </Button>
      </View>
    </View>
  );
};

MyInspectionsAccordionFooter.propTypes = {
  onSubmit: PropTypes.func.isRequired,
};

export default MyInspectionsAccordionFooter;
