import {Accordion} from '@/components';
import {INSPECTION_STATUS} from '@/constants';
import InspectionSummary from '@/views/MyInspections/InspectionSummary';
import MyInspectionsAccordionHeader from '@/views/MyInspections/MyInspectionsAccordionHeader';

const PendingInspectionsAccordion = ({inspections, onEdit, onRemove}) => (
  <Accordion
    marginHorizontal={8}
    marginVertical={10}
    header={
      <MyInspectionsAccordionHeader
        type={INSPECTION_STATUS.PENDING}
        quantity={inspections.length}
      />
    }>
    {inspections.map(inspection => (
      <InspectionSummary
        key={inspection.id}
        inspection={inspection}
        onEdit={onEdit}
        onRemove={onRemove}
      />
    ))}
  </Accordion>
);

export default PendingInspectionsAccordion;
