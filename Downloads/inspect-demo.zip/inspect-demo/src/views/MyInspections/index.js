import {useFocusEffect} from '@react-navigation/native';
import {useState} from 'react';
import {useTranslation} from 'react-i18next';
import {ScrollView} from 'react-native';
import {connect} from 'react-redux';
import CompletedInspectionsAccordion from './CompletedInspectionsAccordion';
import FloatingActionButton from './FloatingActionButton';
import PendingInspectionsAccordion from './PendingInspectionsAccordion';
import {ConfirmDialog, Container, Header, Text} from '@/components';
import {useBoolean, useEvent, useNavigation} from '@/hooks';
import Routes from '@/navigation/routes';
import {
  editInspection,
  fetchInspections,
  removeInspection,
  reopenInspection,
} from '@/state/reducer/inspection';
import {
  selectCompletedInspections,
  selectPendingInspections,
} from '@/state/selector/inspection';

const MyInspections = ({
  inspections,
  completedInspections,
  onEdit,
  onMount,
  onRemove,
  onReopen,
}) => {
  const {t} = useTranslation();
  const {navigate} = useNavigation();
  const [showModal, setShowModal] = useBoolean(false);
  const [inspectionId, setInspectionId] = useState();
  useFocusEffect(
    useEvent(() => {
      onMount();
    }),
  );
  const handleRemove = inspection => {
    setInspectionId(inspection.id);
    setShowModal.on();
  };
  const handleAcceptRemove = () => {
    onRemove(inspectionId);
    setShowModal.off();
  };
  const handleReopen = inspection => onReopen(inspection.id);
  return (
    <Container>
      {showModal && (
        <ConfirmDialog
          title="confirm"
          onAccept={handleAcceptRemove}
          onCancel={setShowModal.off}>
          <Text>{t('inspection:deleteConfirm')}</Text>
        </ConfirmDialog>
      )}
      <Header
        enableMenu
        hideBack
        title="inspection:myInspections"
        caption="By Karvi"
      />
      <ScrollView>
        <PendingInspectionsAccordion
          inspections={inspections}
          onEdit={onEdit}
          onRemove={handleRemove}
        />
        <CompletedInspectionsAccordion
          inspections={completedInspections}
          onSubmit={() => navigate(Routes.INSPECTION_SYNC)}
          onRemove={handleRemove}
          onReopen={handleReopen}
        />
      </ScrollView>
      <FloatingActionButton onPress={() => navigate(Routes.CAR_EDITOR)} />
    </Container>
  );
};

export default connect(
  state => ({
    inspections: selectPendingInspections(state),
    completedInspections: selectCompletedInspections(state),
  }),
  {
    onMount: fetchInspections,
    onEdit: editInspection,
    onRemove: removeInspection,
    onReopen: reopenInspection,
  },
)(MyInspections);
