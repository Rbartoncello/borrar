import {ScrollView} from 'react-native';
import createStyles from './styles';
import useSectionSchema from './useSectionSchema';
import {DynamicForm} from '@/forms';
import {useThemedStyles} from '@/hooks';

const SectionEditor = ({
  section,
  initialValues,
  sectionValues,
  onSubmit,
  onAction,
  onFormDirty,
}) => {
  const [styles] = useThemedStyles(createStyles);
  const schema = useSectionSchema(section, initialValues?.subsections);
  return (
    <ScrollView style={styles.container}>
      <DynamicForm
        initialValues={initialValues}
        reinitializeValues={sectionValues}
        formSchema={schema}
        onSubmit={onSubmit}
        onAction={onAction}
        onFormDirty={onFormDirty}
      />
    </ScrollView>
  );
};

export default SectionEditor;
