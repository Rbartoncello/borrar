const createStyles = theme => ({
  container: {
    width: '100%',
    paddingTop: theme.spacing.paddingVertical * 1.5,
    backgroundColor: theme.colors.grey100,
  },
});

export default createStyles;
