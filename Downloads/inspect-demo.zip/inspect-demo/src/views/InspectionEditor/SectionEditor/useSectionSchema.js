import {useMemo} from 'react';

const useSectionSchema = (section, values) =>
  useMemo(() => {
    const fields = section.fields.map(field =>
      field.type === 'subsections'
        ? {
            ...field,
            values,
            subsections: section.subsections,
          }
        : field,
    );
    return {...section, fields};
  }, [section, values]);

export default useSectionSchema;
