import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import {Fragment, useState} from 'react';
import {useTranslation} from 'react-i18next';
import SectionEditor from './SectionEditor';
import TabBarHeader from './TabBarHeader';
import {ConfirmDialog, Text} from '@/components';
import {useNavigation} from '@/hooks';
import usePreventDismiss from '@/hooks/usePreventDismiss';

const Tab = createMaterialTopTabNavigator();

const getSectionData = (inspection, chapterName, name) => {
  const chapter = inspection[chapterName];
  return chapter ? chapter[name] || {} : {};
};

const InspectionSections = ({
  inspection,
  initialRouteName,
  sections,
  chapter,
  title,
  progress,
  onSubmit,
  onAction,
  onFocus,
  isSubmit,
}) => {
  const [sectionValues, setSectionValues] = useState();
  const [sectionName, setSectionName] = useState();
  const [isDirty, setIsDirty] = useState(false);
  const [dismiss, setDismiss, action] = usePreventDismiss(isDirty, isSubmit);
  const navigation = useNavigation();
  const {t} = useTranslation();
  const handleConfirm = () => {
    setDismiss.off();
    setSectionName(undefined);
    if (sectionName) {
      navigation.jumpTo(sectionName);
    } else {
      navigation.dispatch(action);
    }
  };
  const handleTabPress = e => {
    if (isDirty) {
      e.preventDefault();
      setDismiss.on();
      const sectionToChange = e.target.split('-')[0];
      setSectionName(sectionToChange);
    }
  };
  const handleFocus = section => {
    onFocus(section);
    setSectionValues(getSectionData(inspection, chapter, section.name));
    setIsDirty(false);
  };
  const handleCancel = () => {
    setSectionName(undefined);
    setDismiss.off();
  };
  return (
    <Fragment>
      {dismiss && (
        <ConfirmDialog
          onAccept={handleConfirm}
          title="inspection:approveDismissTitle"
          onCancel={handleCancel}>
          <Text>{t('inspection:approveDismissMessage')}</Text>
        </ConfirmDialog>
      )}
      <Tab.Navigator
        // eslint-disable-next-line react/no-unstable-nested-components
        tabBar={props => (
          <TabBarHeader
            chapter={inspection[chapter]}
            title={title}
            progress={progress}
            {...props}
          />
        )}
        initialRouteName={initialRouteName}
        backBehavior="order">
        {sections.map(section => (
          <Tab.Screen
            key={section.name}
            id={section.name}
            name={section.name}
            listeners={{
              focus: () => handleFocus(section),
              tabPress: handleTabPress,
            }}
            options={{
              tabBarLabel: section.label,
              lazy: true,
              swipeEnabled: false,
            }}>
            {() => (
              <SectionEditor
                chapter={chapter}
                initialValues={getSectionData(
                  inspection,
                  chapter,
                  section.name,
                )}
                sectionValues={sectionValues}
                section={section}
                onSubmit={onSubmit}
                onAction={onAction}
                onFormDirty={setIsDirty}
              />
            )}
          </Tab.Screen>
        ))}
      </Tab.Navigator>
    </Fragment>
  );
};
export default InspectionSections;
