import {Fragment, useRef} from 'react';
import {FlatList, View} from 'react-native';
import createStyles from './styles';
import {Header, ProgressBar} from '@/components';
import SectionItem from '@/components/Sections/SectionItem';
import {useThemedStyles} from '@/hooks';

const isComplete = section =>
  Object.keys(section || {}).some(key => key !== 'subsections');

const TabBarHeader = ({
  state,
  descriptors,
  navigation,
  chapter,
  title,
  progress,
}) => {
  const ref = useRef();
  const [styles, theme] = useThemedStyles(createStyles);
  return (
    <Header title={title}>
      <Fragment>
        <View style={styles.header}>
          <ProgressBar
            value={progress}
            positionValue="right"
            barColor={theme.colors.blue900}
            barIndicatorColor={theme.colors.green900}
          />
        </View>
      </Fragment>
      <FlatList
        horizontal
        style={styles.sections}
        ref={ref}
        data={state.routes}
        keyExtractor={route => route.key}
        renderItem={({item, index}) => {
          const {options} = descriptors[item.key];
          const isFocused = state.index === index;
          const label = options.tabBarLabel || options.title || item.name;

          const onPress = () => {
            const event = navigation.emit({
              type: 'tabPress',
              target: item.key,
              canPreventDefault: true,
            });
            if (!isFocused && !event.defaultPrevented) {
              navigation.navigate({name: item.name, merge: true});
              ref.current?.scrollToIndex({
                index: state.routes.findIndex(x => x.key === item.key),
                animated: true,
              });
            }
          };

          const onLongPress = () => {
            navigation.emit({
              type: 'tabLongPress',
              target: item.key,
            });
          };

          return (
            <SectionItem
              label={label}
              completed={isComplete(chapter?.[item.name])}
              active={isFocused}
              accessibilityRole="button"
              accessibilityState={isFocused ? {selected: true} : {}}
              accessibilityLabel={options.tabBarAccessibilityLabel}
              testID={options.tabBarTestID}
              onPress={onPress}
              onLongPress={onLongPress}
            />
          );
        }}
      />
    </Header>
  );
};

export default TabBarHeader;
