const createStyles = theme => ({
  header: {marginHorizontal: theme.spacing.baseUnit},
  sections: {marginVertical: theme.spacing.baseUnit},
});

export default createStyles;
