import {useState} from 'react';
import {connect} from 'react-redux';
import InspectionSections from './InspectionSections';
import {useChapterProgress, useEvent, useNavigation} from '@/hooks';
import Routes from '@/navigation/routes';
import {
  saveInspectionSection,
  removeInspectionSubsection,
} from '@/state/reducer/inspection';
import {selectInspection} from '@/state/selector/inspection';
import {selectQuestionnaire} from '@/state/selector/staticData';

const InspectionEditor = ({
  inspection,
  route,
  questionnaire,
  onSubmit,
  onRemove,
}) => {
  const {label, sections} = questionnaire.chapters.find(
    chapter => chapter.name === route.params.chapter,
  );
  const {section} = route.params;
  const {navigate, jumpTo} = useNavigation();
  const [routeName, setRouteName] = useState(
    section ? sections.find(s => s.name === section) : sections[0],
  );
  const progress = useChapterProgress(
    sections,
    inspection[route.params.chapter],
  );
  const handleSubmit = useEvent(values => {
    const enablerField = routeName.enabler;
    if (enablerField && values[enablerField] === false) {
      values = {[enablerField]: false};
    }
    onSubmit({
      values,
      chapter: route.params.chapter,
      section: routeName.name,
      subsections: undefined,
    });
    const index = sections.findIndex(s => s.name === routeName.name) + 1;
    if (index === sections.length) {
      navigate(Routes.INSPECTION_HOME);
      return;
    }
    jumpTo(sections[index].name);
  });
  const handleFocus = value =>
    setRouteName(sections.find(s => s.name === value.name));
  const handleAction = useEvent((type, params) => {
    switch (type) {
      case 'add':
      case 'edit':
        const subsection = params.subsection || params;
        navigate(Routes.SUBSECTION_EDITOR, {
          subsection,
          chapter: route.params.chapter,
          sectionName: routeName.name,
          index: params?.index,
          initialValues: params.values
            ? Array.isArray(params.values[subsection.name])
              ? params.values[subsection.name][params.index]
              : params.values[subsection.name]
            : undefined,
        });
        break;
      case 'remove':
        onRemove({
          chapter: route.params.chapter,
          sectionName: routeName.name,
          subsections: params.subsection,
          index: params.index,
        });
        break;
    }
  });

  return (
    <InspectionSections
      sections={sections}
      initialRouteName={routeName.name}
      chapter={route.params.chapter}
      route={route}
      inspection={inspection}
      title={label}
      progress={progress}
      onFocus={handleFocus}
      onAction={handleAction}
      onSubmit={handleSubmit}
    />
  );
};

export default connect(
  state => ({
    inspection: selectInspection(state),
    questionnaire: selectQuestionnaire(state),
  }),
  {onSubmit: saveInspectionSection, onRemove: removeInspectionSubsection},
)(InspectionEditor);
