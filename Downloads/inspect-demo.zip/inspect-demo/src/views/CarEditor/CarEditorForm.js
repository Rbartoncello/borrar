import {Field, Formik} from 'formik';
import {useMemo} from 'react';
import {useTranslation} from 'react-i18next';
import {ScrollView, View} from 'react-native';
import CarDataEditor from './CarDataEditor';
import CarDataViewer from './CarDataViewer';
import PlateIndicator from './PlateIndicator';
import carSchema from './carSchema';
import {createStyles} from './styles';
import {Button, Card, StoreField, Text} from '@/components';
import {SITES} from '@/constants';
import {buildFormSchema, SelectField, TextField, NumberField} from '@/forms';
import {usePlateIcon, useThemedStyles} from '@/hooks';
import {CircleInfo} from '@/icons';

const CarEditorForm = ({
  car,
  brands,
  colors,
  models,
  site,
  status,
  versions,
  onChange,
  onSubmit,
  configurations,
  plate,
  years,
}) => {
  const [styles] = useThemedStyles(createStyles);
  const {t} = useTranslation();
  const PlateIcon = usePlateIcon();
  const formSchema = useMemo(
    () => carSchema(site, !!car, configurations),
    [site, car, configurations],
  );
  const fieldPriceConfig = formSchema.fields.find(
    f => f.name === 'originalPrice',
  );
  const fieldConfig = formSchema.fields.find(f => f.name === 'configuration');
  const initialValues = {
    plate: '',
    configuration: configurations.length > 1 ? '' : configurations[0]?.value,
  };
  return (
    <Formik
      validationSchema={buildFormSchema(formSchema)}
      initialValues={initialValues}
      enableReinitialize
      onSubmit={({
        startInspection,
        storeId,
        brandId,
        modelId,
        colorId,
        ...values
      }) => onSubmit(values, startInspection)}>
      {({handleSubmit, setFieldValue}) => (
        <ScrollView style={styles.container}>
          {fieldConfig.options?.length > 1 && (
            <Card title={t('car:configuration')} style={styles.store}>
              <Field
                name={fieldConfig.name}
                config={fieldConfig}
                component={SelectField}
              />
            </Card>
          )}
          <Card title={t('inspection:store')} style={styles.store}>
            <Field
              name={formSchema.fields[1].name}
              config={formSchema.fields[1]}
              component={StoreField}
              onChange={store => setFieldValue('store', store)}
            />
          </Card>
          <Card title={t('car:plate')}>
            <Field
              name={formSchema.fields[2].name}
              config={{
                ...formSchema.fields[2],
                inputContainerStyle: styles.plate,
              }}
              component={TextField}
              maxLength={7}
              leftIcon={<PlateIcon />}
              rightIcon={<PlateIndicator status={status} hasCar={!!car} />}
              onChange={onChange}
            />
            {site === SITES.BR && (
              <View style={styles.plateInfoContainer}>
                <CircleInfo style={styles.plateInfo} />
                <Text>{t('car:autofillInfo')}</Text>
              </View>
            )}
          </Card>
          {car || !plate ? (
            <CarDataViewer car={car} colors={colors} />
          ) : (
            <CarDataEditor
              brands={brands}
              formSchema={formSchema}
              colors={colors}
              models={models}
              versions={versions}
              onChange={onChange}
              years={years}
              site={site}
            />
          )}
          <Card title={t('car:additionalData')}>
            <Field
              name={fieldPriceConfig.name}
              config={{...fieldPriceConfig, disabled: !plate}}
              component={NumberField}
            />
          </Card>
          <Button
            title="inspection:startInspection"
            containerStyle={styles.button}
            onPress={() => {
              setFieldValue('startInspection', true);
              handleSubmit();
            }}
          />
          <Button
            type="clear"
            title="car:inspectLater"
            containerStyle={styles.button}
            onPress={() => {
              setFieldValue('startInspection', false);
              handleSubmit();
            }}
          />
        </ScrollView>
      )}
    </Formik>
  );
};

export default CarEditorForm;
