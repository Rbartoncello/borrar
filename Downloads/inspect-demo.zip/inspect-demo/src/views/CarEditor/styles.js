export const createStyles = theme => ({
  container: {flex: 1, marginBottom: theme.spacing.marginVertical},
  plate: {paddingLeft: 3},
  plateInfoContainer: {
    flex: 1,
    flexDirection: 'row',
    marginBottom: theme.spacing.marginVertical,
  },
  plateInfo: {
    marginLeft: theme.spacing.marginHorizontal,
    marginTop: theme.spacing.marginVertical / 2,
  },
  store: {paddingBottom: theme.spacing.baseUnit},
  button: {
    marginHorizontal: theme.spacing.marginHorizontal,
    marginVertical: theme.spacing.marginHorizontal / 2,
  },
});

export const createCarDataEditorStyles = theme => ({
  container: {paddingBottom: theme.spacing.paddingVertical * 2},
  yearsRow: {flex: 1, flexDirection: 'row'},
  yearContainer: {flex: 1, marginRight: theme.spacing.paddingHorizontal / 2},
  assemblyContainer: {
    flex: 1,
    marginLeft: theme.spacing.paddingHorizontal / 2,
  },
});
