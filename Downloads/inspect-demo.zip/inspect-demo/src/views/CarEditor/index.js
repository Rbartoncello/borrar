import {useEffect, useState} from 'react';
import {useTranslation} from 'react-i18next';
import {Keyboard} from 'react-native';
import {connect} from 'react-redux';
import CarEditorForm from './CarEditorForm';
import {Container, Header, Text, ConfirmDialog} from '@/components';
import {
  useAlertStatusError,
  useBoolean,
  useEvent,
  useNavigation,
} from '@/hooks';
import {CarsService} from '@/services';
import DateUtil from '@/services/dateUtil';
import {cleanCar, findCar} from '@/state/reducer/cars';
import {fetchModels, fetchVersions, fetchYears} from '@/state/reducer/catalog';
import {createInspection} from '@/state/reducer/inspection';
import {selectCar, selectCarStatus, selectPlate} from '@/state/selector/cars';
import {
  selectColors,
  selectVersions,
  selectBrands,
  selectModels,
  selectYears,
} from '@/state/selector/catalog';
import {selectSite} from '@/state/selector/session';
import {selectQuestionnaires} from '@/state/selector/staticData';

const versionDependencies = ['brandId', 'modelId', 'year', 'versionId'];
const yearDependencies = ['brandId', 'modelId'];
const carsService = new CarsService();

const CarEditor = ({
  brands,
  car,
  colors,
  models,
  versions,
  site,
  status,
  onChange,
  onChangeBrand,
  onChangePlate,
  onMount,
  onSubmit,
  questionnaires,
  plate,
  onChangeBrandOrModel,
  years,
}) => {
  const {i18n} = useTranslation();
  const [values, setValues] = useState({});
  const [showConfirm, setShowConfirm] = useBoolean();
  const {t} = useTranslation();
  const {goBack} = useNavigation();
  const dateUtils = new DateUtil();
  const configurations = questionnaires.map(questionnaire => ({
    value: questionnaire.id,
    label: t(questionnaire.name),
  }));
  useAlertStatusError(status);
  const handleChange = useEvent((k, v) => {
    if (k === 'plate') {
      if (carsService.isValidPlate(v, i18n.language)) {
        onChangePlate(v);
        Keyboard.dismiss();
      }
    } else if (versionDependencies.includes(k)) {
      if (yearDependencies.includes(k)) {
        onChangeBrandOrModel({...values, [k]: v});
      }
      if (k === 'brandId') {
        onChangeBrand(v);
      }
      setValues({...values, [k]: v});
    }
  });
  const handleCancel = () => {
    setShowConfirm.off();
    goBack();
  };
  useEffect(() => onMount, [onMount]);
  useEffect(() => {
    if (values.brandId && values.modelId && values.year) {
      onChange(values);
    }
  }, [values, onChange]);
  useEffect(() => {
    if (car?.lastInspection) {
      setShowConfirm.on();
    }
  }, [car, setShowConfirm]);
  return (
    <Container>
      <Header title="car:newCarTitle" />
      {showConfirm && (
        <ConfirmDialog
          title="Confirmar"
          onAccept={setShowConfirm.off}
          onCancel={handleCancel}>
          <Text>
            {t('car:inspectionExists')}
            {` ${dateUtils.formatDateTime(car?.lastInspection)}. `}
            {t('car:continue')}
          </Text>
        </ConfirmDialog>
      )}
      <CarEditorForm
        {...{
          car,
          status,
          brands,
          colors,
          configurations,
          models,
          site,
          versions,
          plate,
          years,
        }}
        onChange={handleChange}
        onSubmit={(val, startInspection) =>
          onSubmit({car: val, startInspection})
        }
      />
    </Container>
  );
};

export default connect(
  state => ({
    car: selectCar(state),
    status: selectCarStatus(state),
    brands: selectBrands(state),
    colors: selectColors(state),
    models: selectModels(state),
    site: selectSite(state),
    versions: selectVersions(state),
    questionnaires: selectQuestionnaires(state),
    plate: selectPlate(state),
    years: selectYears(state),
  }),
  {
    onMount: cleanCar,
    onChange: fetchVersions,
    onChangePlate: findCar,
    onChangeBrand: fetchModels,
    onSubmit: createInspection,
    onChangeBrandOrModel: fetchYears,
  },
)(CarEditor);
