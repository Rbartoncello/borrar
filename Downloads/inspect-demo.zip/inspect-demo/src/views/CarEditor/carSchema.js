import {AR_PLATE_REGEX, BR_PLATE_REGEX, SITES} from '@/constants';
import {InspectionService} from '@/services';

const getCarFields = [
  {
    name: 'brandId',
    type: 'select',
    label: 'car:brand',
    placeholder: 'car:brandPlaceholder',
    validations: [
      {
        type: 'required',
        message: 'required',
      },
    ],
  },
  {
    name: 'modelId',
    type: 'select',
    label: 'car:model',
    placeholder: 'car:modelPlaceholder',
    validations: [
      {
        type: 'required',
        message: 'required',
      },
    ],
  },
  {
    name: 'year',
    type: 'select',
    label: 'car:year',
    placeholder: 'car:yearPlaceholder',
    validations: [
      {
        type: 'required',
        message: 'required',
      },
    ],
  },
  {
    name: 'assembly',
    type: 'select',
    label: 'car:assembly',
    placeholder: 'car:assemblyPlaceholder',
    validations: [
      {
        type: 'required',
        message: 'required',
      },
    ],
  },
  {
    name: 'versionId',
    type: 'select',
    label: 'car:version',
    placeholder: 'car:versionPlaceholder',
    validations: [
      {
        type: 'required',
        message: 'required',
      },
    ],
  },
  {
    name: 'colorId',
    type: 'select',
    label: 'car:color',
    placeholder: 'car:colorPlaceholder',
    validations: [
      {
        type: 'required',
        message: 'required',
      },
    ],
  },
];

const carSchema = (site, hasFoundCar, configurations) => {
  const fields = [
    {
      name: 'configuration',
      type: 'select',
      options: configurations,
      placeholder: 'car:configurationPlaceholder',
      validations: [
        {
          type: 'required',
          message: 'required',
        },
      ],
    },
    {
      name: 'storeId',
      type: 'number',
      placeholder: 'car:storePlaceholder',
      validations: [
        {
          type: 'required',
          message: 'required',
        },
      ],
    },
    {
      name: 'plate',
      type: 'text',
      placeholder: 'car:platePlaceholder',
      validations: [
        {
          type: 'required',
          message: 'required',
        },
        {
          type: 'matches',
          value: site === SITES.BR ? BR_PLATE_REGEX : AR_PLATE_REGEX,
          message: 'car:invalidCarPlate',
        },
        {
          type: 'test',
          value: {
            async test(value) {
              const regex = site === SITES.BR ? BR_PLATE_REGEX : AR_PLATE_REGEX;
              if (!regex.test(value)) {
                return false;
              }
              const inspectionService = new InspectionService();
              const inspection = await inspectionService.findByPlate(value);
              return inspection
                ? this.createError({message: 'car:plateAlreadyUsed'})
                : true;
            },
          },
        },
      ],
    },
  ];
  if (!hasFoundCar) {
    fields.push(...getCarFields);
  }
  fields.push({
    name: 'originalPrice',
    type: 'number',
    label: 'car:price',
    validations: [
      {
        type: 'min',
        message: 'car:minimumPrice',
        value: site === SITES.BR ? 15000 : 600000,
      },
    ],
  });
  return {id: 'CAR_EDITOR', fields};
};

export default carSchema;
