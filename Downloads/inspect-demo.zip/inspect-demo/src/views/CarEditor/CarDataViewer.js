import {View} from 'react-native';
import {Card, TextInput} from '@/components';
import {useThemedStyles} from '@/hooks';
import {Circle} from '@/icons';
import {createCarDataEditorStyles} from '@/views/CarEditor/styles';

const CarDataViewer = ({car, colors}) => {
  const [styles] = useThemedStyles(createCarDataEditorStyles);
  car = car || {brand: {}, model: {}, color: {}};
  const color = car.color.id ? colors.find(c => c.id === car.color.id) : {};
  return (
    <Card title="car:carEditorTitle" style={styles.container}>
      <TextInput
        label="car:brand"
        value={car.brand.name}
        placeholder=""
        disabled
      />
      <TextInput
        label="car:model"
        value={car.model.name}
        placeholder=""
        disabled
      />
      <View style={styles.yearsRow}>
        <View style={styles.yearContainer}>
          <TextInput
            label="car:year"
            value={car.year}
            placeholder=""
            disabled
          />
        </View>
        <View style={styles.assemblyContainer}>
          <TextInput
            label="car:assembly"
            value={car.assembly}
            placeholder=""
            disabled
          />
        </View>
      </View>
      <TextInput
        label="car:version"
        value={car.version?.name}
        placeholder=""
        disabled
      />
      <TextInput
        label="car:color"
        value={color.name}
        leftIcon={color.hex && <Circle color={color.hex} />}
        placeholder=""
        disabled
      />
    </Card>
  );
};

export default CarDataViewer;
