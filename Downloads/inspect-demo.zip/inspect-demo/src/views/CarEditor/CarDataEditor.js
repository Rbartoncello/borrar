import {Field, useFormikContext} from 'formik';
import {useMemo} from 'react';
import {View} from 'react-native';
import {Card} from '@/components';
import {SITES} from '@/constants';
import {SelectField} from '@/forms';
import {useEvent, useThemedStyles} from '@/hooks';
import {Circle} from '@/icons';
import {getIn} from '@/util';
import {createCarDataEditorStyles} from '@/views/CarEditor/styles';

const getColorOptions = colors =>
  colors.map(color => ({
    id: color.id,
    name: color.name,
    // Use key to force re-render color icon when color is changed.
    icon: color.hex ? <Circle key={color.hex} color={color.hex} /> : undefined,
  }));

const setObjectField = (setFieldValue, fieldName, value, values) =>
  setFieldValue(
    fieldName,
    values.find(x => x.id === value),
  );

const getAssemblyYears = (year, site) => {
  if (!year) {
    return [];
  }
  const parsedYear = Number(year);
  const maxYear = new Date().getFullYear() + 1;
  const limit = maxYear - parsedYear;
  const years = Array.from({length: limit > 5 ? 5 : limit}, (_, i) =>
    site === SITES.BR ? -i + parsedYear : i + parsedYear,
  ).map(value => ({value: value.toString(), label: value}));
  return site === SITES.BR ? years : years.reverse();
};

const CarDataEditor = ({
  brands,
  colors,
  formSchema,
  models,
  versions,
  onChange,
  years,
  site,
}) => {
  const [styles] = useThemedStyles(createCarDataEditorStyles);
  const {values, setFieldValue} = useFormikContext();
  const colorOptions = useMemo(() => getColorOptions(colors), [colors]);
  const handleChange = useEvent((key, value) => onChange(key, value));
  const versionOptions =
    getIn(versions, [values.brandId, values.modelId, values.year]) || [];
  return (
    <Card title="car:carEditorTitle" style={styles.container}>
      <Field
        name={formSchema.fields[3].name}
        config={{
          ...formSchema.fields[3],
          options: brands,
          valueKey: 'id',
          labelKey: 'name',
        }}
        component={SelectField}
        onChange={(key, value) => {
          setObjectField(setFieldValue, 'brand', value, brands);
          handleChange(key, value);
        }}
      />
      <Field
        name={formSchema.fields[4].name}
        config={{
          ...formSchema.fields[4],
          options: models[values.brandId] || [],
          valueKey: 'id',
          labelKey: 'name',
        }}
        component={SelectField}
        onChange={(key, value) => {
          setObjectField(setFieldValue, 'model', value, models[values.brandId]);
          handleChange(key, value);
        }}
      />
      <View style={styles.yearsRow}>
        <View style={styles.yearContainer}>
          <Field
            name={formSchema.fields[5].name}
            config={{...formSchema.fields[5], options: years}}
            component={SelectField}
            onChange={(key, value) => {
              setFieldValue('assembly', null);
              handleChange(key, value);
            }}
          />
        </View>
        <View style={styles.assemblyContainer}>
          <Field
            name={formSchema.fields[6].name}
            config={{
              ...formSchema.fields[6],
              options: getAssemblyYears(values.year, site),
            }}
            component={SelectField}
          />
        </View>
      </View>
      <Field
        name={formSchema.fields[7].name}
        config={{
          ...formSchema.fields[7],
          options: versionOptions,
          valueKey: 'id',
          labelKey: 'name',
        }}
        onChange={(key, value) => {
          setObjectField(setFieldValue, 'version', value, versionOptions);
          handleChange(key, value);
        }}
        component={SelectField}
      />
      <Field
        name={formSchema.fields[8].name}
        config={{
          ...formSchema.fields[8],
          options: colorOptions,
          valueKey: 'id',
          labelKey: 'name',
        }}
        component={SelectField}
        onChange={(_, value) =>
          setObjectField(setFieldValue, 'color', value, colors)
        }
      />
    </Card>
  );
};

export default CarDataEditor;
