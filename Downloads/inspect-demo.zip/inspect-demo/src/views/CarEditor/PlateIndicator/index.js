import {useTheme} from '@rneui/themed';
import {ActivityIndicator} from 'react-native';
import {CircleCheck} from '@/icons';

const PlateIndicator = ({status, hasCar}) => {
  const {theme} = useTheme();
  if (status.isFetching) {
    return <ActivityIndicator color={theme.colors.blue800} />;
  }
  return hasCar ? <CircleCheck /> : null;
};

export default PlateIndicator;
