const errorMessage = {
  type: 'error',
  label: 'login:invalidCredentials',
};

const loginSchema = hasError => {
  const schema = {
    id: 'SIGN_IN',
    submitText: 'login:submit',
    cancelText: 'Back',
    submitButton: {
      disabled: false,
    },
    fields: [
      {
        type: 'title',
        label: 'login:title',
      },
      {
        name: 'email',
        type: 'email',
        label: 'login:email',
        placeholder: 'login:placeholderEmail',
        inputContainerStyle: {
          borderWidth: 2,
          borderBottomWidth: 2,
        },
        validations: [
          {
            type: 'required',
            message: 'login:emailRequired',
          },
        ],
      },
      {
        name: 'password',
        type: 'password',
        label: 'login:password',
        placeholder: 'login:placeholderPassword',
        validationType: 'text',
        inputContainerStyle: {
          borderWidth: 2,
          borderBottomWidth: 2,
        },
        validations: [
          {
            type: 'required',
            message: 'login:passwordRequired',
          },
          {
            type: 'min',
            value: 4,
            message: 'login:passwordLength',
          },
          {
            type: 'max',
            value: 30,
            message: 'login:passwordLength',
          },
        ],
      },
    ],
  };
  if (hasError) {
    schema.fields.push(errorMessage);
  }
  return schema;
};

export default loginSchema;
