import {Pressable} from 'react-native';
import {fieldStyles} from './styles';
import {TextInput as Input} from '@/components';
import {getFieldError} from '@/forms';
import {useBoolean} from '@/hooks';
import {Lock, EyeSlash, Eye} from '@/icons';

const PasswordField = ({field, form, config, ...props}) => {
  const [secureEntry, setSecureEntry] = useBoolean(true);
  return (
    <Input
      {...field}
      {...props}
      autoComplete="password"
      secureTextEntry={secureEntry}
      label={config.label}
      leftIcon={<Lock />}
      rightIcon={
        <Pressable onPress={setSecureEntry.toggle}>
          {secureEntry ? <EyeSlash /> : <Eye />}
        </Pressable>
      }
      inputContainerStyle={[fieldStyles.container, config.inputContainerStyle]}
      disabled={config.disabled}
      placeholder={config.placeholder}
      errorMessage={getFieldError(form, field)}
      onFocus={() => form.setFieldTouched(field.name)}
      onChangeText={value => form.setFieldValue(field.name, value)}
      onBlur={() => form.handleBlur(field.name)}
    />
  );
};

export default PasswordField;
