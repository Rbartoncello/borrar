import {fieldStyles} from './styles';
import {TextField} from '@/forms/fields';
import {Envelope} from '@/icons';

const EmailField = props => (
  <TextField
    keyboardType="email-address"
    inputContainerStyle={fieldStyles.container}
    leftIcon={<Envelope />}
    {...props}
  />
);

export default EmailField;
