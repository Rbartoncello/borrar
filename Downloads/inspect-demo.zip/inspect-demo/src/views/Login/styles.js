import {Dimensions, StyleSheet} from 'react-native';

const height = Dimensions.get('screen').height - 70;

export const fieldStyles = StyleSheet.create({
  container: {minHeight: 50},
});

export const createStyles = theme => ({
  container: {
    backgroundColor: theme.colors.white,
  },
  content: {
    height,
  },
  version: {
    position: 'absolute',
    color: theme.colors.blue600,
    bottom: theme.spacing.marginVertical / 2,
    right: theme.spacing.marginHorizontal,
  },
});

export const createTitleStyles = theme => ({
  title: {
    marginTop: theme.spacing.baseUnit + 4,
    marginBottom: theme.spacing.baseUnit,
    marginLeft: 4,
    fontSize: theme.typography.extraLarge.fontSize,
  },
});
