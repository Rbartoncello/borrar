import {useTranslation} from 'react-i18next';
import {createTitleStyles} from './styles';
import {Text} from '@/components';
import {useThemedStyles} from '@/hooks';

const Title = ({config}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createTitleStyles);
  return (
    <Text h3 style={styles.title}>
      {t(config.label)}
    </Text>
  );
};

export default Title;
