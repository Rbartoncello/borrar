import {useMemo} from 'react';
import {ScrollView, ImageBackground} from 'react-native';
import VersionCheck from 'react-native-version-check';
import {connect} from 'react-redux';
import EmailField from './EmailField';
import PasswordField from './PasswordField';
import Title from './Title';
import loginSchema from './loginSchema';
import {createStyles} from './styles';
import loginImage from '@/assets/images/login.png';
import {LanguageSwitch, LoadingOverlay, Text} from '@/components';
import {DynamicForm, useDismissibleSubmit} from '@/forms';
import {useThemedStyles} from '@/hooks';
import {login} from '@/state/reducer/session';
import {selectSessionStatus} from '@/state/selector/session';

const components = [
  ['password', PasswordField],
  ['email', EmailField],
  ['title', Title],
];

const initialValue = {email: '', password: ''};

const Login = ({status, onSubmit}) => {
  const [styles] = useThemedStyles(createStyles);
  const schema = useMemo(() => loginSchema(status.isError), [status.isError]);
  const handleSubmit = useDismissibleSubmit(onSubmit, status.isError);
  const version = VersionCheck.getCurrentVersion();
  return (
    <ScrollView style={styles.container}>
      <ImageBackground
        source={loginImage}
        resizeMode="cover"
        style={styles.content}>
        {status.isFetching && <LoadingOverlay />}
        <LanguageSwitch />
        <DynamicForm
          initialValues={initialValue}
          components={components}
          formSchema={schema}
          onSubmit={handleSubmit}
        />
        <Text style={styles.version}>{version}</Text>
      </ImageBackground>
    </ScrollView>
  );
};

export default connect(state => ({status: selectSessionStatus(state)}), {
  onSubmit: login,
})(Login);
