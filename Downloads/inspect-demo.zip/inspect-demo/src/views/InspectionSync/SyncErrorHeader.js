import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import {createHeaderStyles} from './styles';
import {Text} from '@/components';
import {useThemedStyles} from '@/hooks';
import {CircleExclamationStroke} from '@/icons';

const SyncErrorHeader = () => {
  const [styles, theme] = useThemedStyles(createHeaderStyles);
  const {t} = useTranslation();
  return (
    <View style={styles.body}>
      <CircleExclamationStroke
        height={50}
        width={50}
        backgroundColor={theme.colors.orange300}
        color={theme.colors.orange800}
        style={styles.mainIcon}
      />
      <Text style={styles.sendInspectionText} size="lg" bold>
        {t('somethingWentWrong')}
      </Text>
      <Text style={styles.errorText}>{t('sendInspectionError')}</Text>
    </View>
  );
};

export default SyncErrorHeader;
