import Separator from './Separator';
import {CarArrowUpFromBracket, CircleCheck} from '@/icons';

export const renderSeparator = () => <Separator />;

export const getIconSyncHeader = (status, style) =>
  status.success ? (
    <CircleCheck height={50} width={50} style={style} />
  ) : (
    <CarArrowUpFromBracket height={79} width={79} style={style} />
  );

export const getSyncHeaderTitle = status =>
  status.success ? 'syncedSuccessfully' : 'sendingInspections';

export const getStatus = status => {
  if (status.success) {
    return 'successfully';
  }
  if (status.isError) {
    return 'error';
  }
  return 'processing';
};
