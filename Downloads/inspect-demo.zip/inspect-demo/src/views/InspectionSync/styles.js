import {Platform} from 'react-native';

const createStyles = theme => ({
  container: {backgroundColor: theme.colors.white},
  footer: {margin: theme.spacing.baseUnit},
});

export const createSyncErrorStyles = theme => ({
  ...createStyles(theme),
  safeArea: {flex: 1},
  retryButton: {marginBottom: 8},
});

export const createSeparatorStyles = theme => ({
  separator: {
    height: 1,
    marginHorizontal: theme.spacing.marginHorizontal * 3.2,
    backgroundColor: theme.colors.grey300,
  },
});

export const createHeaderStyles = theme => ({
  body: {margin: theme.spacing.baseUnit},
  wifiContainer: {
    paddingHorizontal: theme.spacing.baseUnit - 2,
    paddingVertical: theme.spacing.baseUnit - 6,
    backgroundColor: theme.colors.grey200,
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
  },
  circleInfoIcon: {marginRight: 14},
  mainIcon: {marginVertical: 37, alignItems: 'center'},
  wifiText: {
    color: theme.colors.grey1000,
    alignSelf: 'center',
  },
  sendInspectionText: {
    color: theme.colors.grey1000,
    alignSelf: 'center',
    marginBottom: 20,
  },
  errorText: {
    color: theme.colors.grey1000,
    alignSelf: 'center',
    textAlign: 'center',
    marginBottom: 12,
  },
});

export const createRowStyles = theme => ({
  container: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginVertical: theme.spacing.baseUnit - 4,
    marginHorizontal: theme.spacing.baseUnit * 2,
  },
  dot: {
    height: 6,
    width: 6,
    backgroundColor: theme.colors.blue800,
    borderRadius: 3,
    marginTop: Platform.select({android: () => 8, default: () => 5})(),
    marginRight: 8,
  },
  content: {flex: 1},
});

export default createStyles;
