import {useTranslation} from 'react-i18next';
import {SafeAreaView, FlatList, View} from 'react-native';
import {connect} from 'react-redux';
import InspectionSyncRow from './InspectionSyncRow';
import SyncErrorHeader from './SyncErrorHeader';
import {createSyncErrorStyles} from './styles';
import {renderSeparator} from './util';
import {Button, Container, Header, Modal} from '@/components';
import {useThemedStyles} from '@/hooks';
import {retrySync} from '@/state/reducer/inspection';
import {selectNonSyncedInspections} from '@/state/selector/inspection';

const renderItem = inspection => (
  <InspectionSyncRow status="error" inspection={inspection} />
);

const SyncErrorModal = ({inspections, onBack, onRetry}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createSyncErrorStyles);
  return (
    <Modal visible presentationStyle="fullScreen">
      <SafeAreaView style={styles.safeArea}>
        <Container style={styles.container}>
          <Header title={t('sendInspections')} hideBack />
          <FlatList
            ListHeaderComponent={<SyncErrorHeader />}
            data={inspections}
            ItemSeparatorComponent={renderSeparator}
            renderItem={({item}) => renderItem(item)}
            keyExtractor={item => item.id}
          />
          <View style={styles.footer}>
            <Button containerStyle={styles.retryButton} onPress={onRetry}>
              {t('retry')}
            </Button>
            <Button type="clear" onPress={onBack}>
              {t('tryAgainLater')}
            </Button>
          </View>
        </Container>
      </SafeAreaView>
    </Modal>
  );
};

export default connect(
  state => ({inspections: selectNonSyncedInspections(state)}),
  {onRetry: retrySync},
)(SyncErrorModal);
