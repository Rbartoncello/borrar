import {useTheme} from '@rneui/themed';
import {ActivityIndicator} from 'react-native';
import {CircleCheck, CircleExclamationStroke} from '@/icons';

const UploadIndicator = ({status}) => {
  const {theme} = useTheme();
  switch (status) {
    case 'processing':
      return <ActivityIndicator size="small" color={theme.colors.blue800} />;
    case 'successfully':
      return (
        <CircleCheck
          height={20}
          width={20}
          backgroundColor={theme.colors.green900}
          color={theme.colors.white}
        />
      );
    case 'error':
      return (
        <CircleExclamationStroke backgroundColor={theme.colors.orange700} />
      );
    default:
      return null;
  }
};

export default UploadIndicator;
