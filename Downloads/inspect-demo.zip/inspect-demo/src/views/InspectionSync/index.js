import {useEffect} from 'react';
import {useTranslation} from 'react-i18next';
import {FlatList} from 'react-native';
import {connect} from 'react-redux';
import InspectionSyncRow from './InspectionSyncRow';
import SyncErrorModal from './SyncErrorModal';
import SyncHeader from './SyncHeader';
import createStyles from './styles';
import {getStatus, renderSeparator} from './util';
import {Container, Header, Button} from '@/components';
import {useNavigation, useThemedStyles} from '@/hooks';
import {syncInspections} from '@/state/reducer/inspection';
import {
  selectCompletedInspections,
  selectInspectionStatus,
  selectShowSyncError,
  selectSyncProgress,
} from '@/state/selector/inspection';

const renderItem = (inspection, status) => (
  <InspectionSyncRow
    status={!inspection.synced ? getStatus(status) : 'successfully'}
    inspection={inspection}
  />
);

const InspectionSync = ({
  inspections,
  progress,
  status,
  showSyncError,
  onMount,
}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createStyles);
  const {goBack} = useNavigation();
  useEffect(() => {
    onMount();
  }, [onMount]);
  return (
    <Container style={styles.container}>
      {showSyncError && <SyncErrorModal onBack={goBack} />}
      <Header title={t('sendInspections')} hideBack={status.isFetching} />
      <FlatList
        ListHeaderComponent={<SyncHeader progress={progress} status={status} />}
        data={inspections}
        ItemSeparatorComponent={renderSeparator}
        renderItem={({item}) => renderItem(item, status)}
        keyExtractor={item => item.id}
      />
      {status.success && (
        <Button containerStyle={styles.footer} onPress={goBack}>
          {t('backToInit')}
        </Button>
      )}
    </Container>
  );
};

export default connect(
  state => ({
    inspections: selectCompletedInspections(state),
    progress: selectSyncProgress(state),
    showSyncError: selectShowSyncError(state),
    status: selectInspectionStatus(state),
  }),
  {onMount: syncInspections},
)(InspectionSync);
