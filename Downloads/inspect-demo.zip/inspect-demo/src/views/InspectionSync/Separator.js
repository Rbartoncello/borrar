import {View} from 'react-native';
import {createSeparatorStyles} from './styles';
import {useThemedStyles} from '@/hooks';

const Separator = () => {
  const [styles] = useThemedStyles(createSeparatorStyles);
  return <View style={styles.separator} />;
};

export default Separator;
