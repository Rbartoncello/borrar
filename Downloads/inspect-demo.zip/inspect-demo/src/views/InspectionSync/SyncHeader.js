import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import {createHeaderStyles} from './styles';
import {getIconSyncHeader, getSyncHeaderTitle} from './util';
import {ProgressBar, Text} from '@/components';
import {useThemedStyles} from '@/hooks';
import {CircleInfo} from '@/icons';

const SyncHeader = ({progress, status}) => {
  const [styles, theme] = useThemedStyles(createHeaderStyles);
  const {t} = useTranslation();
  return (
    <View style={styles.body}>
      <View style={styles.wifiContainer}>
        <CircleInfo style={styles.circleInfoIcon} />
        <Text size="sm" style={styles.wifiText}>
          {t('useWifi')}
        </Text>
      </View>
      {getIconSyncHeader(status, styles.mainIcon)}
      <Text style={styles.sendInspectionText} size="lg" bold>
        {t(getSyncHeaderTitle(status))}
      </Text>
      <ProgressBar
        positionValue="none"
        value={progress}
        barIndicatorColor={theme.colors.green800}
      />
    </View>
  );
};

export default SyncHeader;
