import {View} from 'react-native';
import UploadIndicator from './UploadIndicator';
import {createRowStyles} from './styles';
import {Text} from '@/components';
import {useCarTitle, useThemedStyles} from '@/hooks';

const InspectionSyncRow = ({status, inspection}) => {
  const [styles] = useThemedStyles(createRowStyles);
  const title = useCarTitle(inspection);
  return (
    <View style={styles.container}>
      <View style={styles.dot} />
      <View style={styles.content}>
        <Text bold size="sm">
          {title}
        </Text>
        <Text size="sm">{inspection.car.plate}</Text>
      </View>
      <UploadIndicator status={status} />
    </View>
  );
};

export default InspectionSyncRow;
