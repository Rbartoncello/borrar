import {useRef} from 'react';
import {useTranslation} from 'react-i18next';
import {View, FlatList} from 'react-native';
import {connect} from 'react-redux';
import ChapterResume from './ChapterResume';
import createStyles from './styles';
import {
  Button,
  Container,
  Header,
  InspectionResumeCar,
  Text,
} from '@/components';
import {useNavigation, useThemedStyles} from '@/hooks';
import {CircleCheckOutline, PenToSquare} from '@/icons';
import Routes from '@/navigation/routes';
import {closeInspection} from '@/state/reducer/inspection';
import {selectInspection} from '@/state/selector/inspection';
import {selectQuestionnaireChapters} from '@/state/selector/staticData';

const renderItem = (chapter, inspection, onEdit) => (
  <ChapterResume
    chapter={chapter}
    values={inspection[chapter.name]}
    onEdit={section => onEdit(chapter.name, section)}
  />
);

const renderSeparator = style => <View style={style} />;

const InspectionResume = ({chapters, inspection, onSubmit}) => {
  const ref = useRef();
  const {t} = useTranslation();
  const [styles, theme] = useThemedStyles(createStyles);
  const {navigate} = useNavigation();
  const handleEdit = (chapter, section) =>
    navigate(Routes.INSPECTION_EDITOR, {chapter, section});
  const handlePressIndicator = index =>
    ref.current?.scrollToIndex({index, animated: true});
  return (
    <Container>
      <Header />
      <FlatList
        ref={ref}
        style={styles.list}
        ListHeaderComponent={
          <View style={styles.containerComponent}>
            <CircleCheckOutline style={styles.icon} />
            <Text bold size="lg" style={styles.title}>
              {t('inspection:finishTitle')}
            </Text>
            <Text style={styles.info}>{t('inspection:finishText')}</Text>
            <InspectionResumeCar
              chapters={chapters}
              inspection={inspection}
              onPressIndicator={handlePressIndicator}
            />
          </View>
        }
        ItemSeparatorComponent={() => renderSeparator(styles.separator)}
        data={chapters}
        renderItem={({item}) => renderItem(item, inspection, handleEdit)}
        keyExtractor={item => item.name}
        ListFooterComponent={
          <View style={styles.containerComponent}>
            <Button containerStyle={styles.finishButton} onPress={onSubmit}>
              {t('inspection:finish')}
            </Button>
            <Button
              type="clear"
              onPress={() => navigate(Routes.INSPECTION_HOME)}>
              <PenToSquare
                height={20}
                width={20}
                color={theme.colors.blue800}
                style={styles.penIcon}
              />
              {t('inspection:keepEditing')}
            </Button>
          </View>
        }
      />
    </Container>
  );
};

export default connect(
  state => ({
    chapters: selectQuestionnaireChapters(state),
    inspection: selectInspection(state),
  }),
  {onSubmit: closeInspection},
)(InspectionResume);
