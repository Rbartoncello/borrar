import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import {SvgXml} from 'react-native-svg';
import {createCardHeaderStyles} from './styles';
import {Text, FlawsIndicator} from '@/components';
import {useChapterFlawsCount, useThemedStyles} from '@/hooks';
import {Check} from '@/icons';

const ChapterResumeHeader = ({chapter, values}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createCardHeaderStyles);
  const flaws = useChapterFlawsCount(chapter, values);
  return (
    <View style={styles.container}>
      <View style={styles.image}>
        <SvgXml height={55} width={55} xml={chapter.image} />
      </View>
      <Text bold style={styles.title}>
        {t(chapter.label)}
      </Text>
      {flaws ? (
        <FlawsIndicator flaws={flaws} />
      ) : (
        <Check style={styles.check} />
      )}
    </View>
  );
};

export default ChapterResumeHeader;
