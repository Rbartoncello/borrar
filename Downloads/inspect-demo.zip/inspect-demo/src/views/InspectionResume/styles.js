import {Platform} from 'react-native';

export const createCardHeaderStyles = theme => ({
  container: {flexDirection: 'row', alignItems: 'center'},
  image: {
    height: 60,
    width: 60,
    backgroundColor: theme.colors.blue150,
    borderRadius: 30,
    marginRight: 12,
  },
  title: {flex: 1},
  check: {
    height: 24,
    width: 24,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 12,
    backgroundColor: theme.colors.green900,
  },
});

export const createChapterResumeStyles = theme => ({
  container: {marginTop: theme.spacing.marginVertical * 2, marginBottom: 8},
});

export const createSectionFlawsStyles = theme => ({
  container: {
    marginBottom: theme.spacing.baseUnit,
    paddingLeft: theme.spacing.paddingHorizontal * 1.2,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  dot: {
    height: 6,
    width: 6,
    marginTop: Platform.select({android: () => 10, default: () => 8})(),
    marginRight: 8,
    borderRadius: 3,
    backgroundColor: theme.colors.blue800,
  },
  info: {flex: 1},
  name: {marginTop: 2},
  status: {color: theme.colors.grey800, marginTop: 6},
});

const createStyles = theme => ({
  title: {alignSelf: 'center'},
  info: {
    marginTop: 12,
    marginBottom: 30,
    marginHorizontal: theme.spacing.baseUnit,
    textAlign: 'center',
    alignItems: 'center',
  },
  icon: {
    marginBottom: theme.spacing.baseUnit - 2,
    alignItems: 'center',
  },
  penIcon: {marginRight: 12},
  finishButton: {marginBottom: 10},
  list: {marginHorizontal: 16},
  containerComponent: {marginVertical: theme.spacing.baseUnit * 2},
  separator: {height: 1, backgroundColor: theme.colors.grey300},
});

export default createStyles;
