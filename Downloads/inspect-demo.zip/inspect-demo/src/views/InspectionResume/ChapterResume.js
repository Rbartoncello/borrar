import {View} from 'react-native';
import ChapterResumeHeader from './ChapterResumeHeader';
import SectionFlaws from './SectionFlaws';
import {createChapterResumeStyles} from './styles';
import {useThemedStyles} from '@/hooks';

const ChapterResume = ({chapter, values, onEdit}) => {
  const [styles] = useThemedStyles(createChapterResumeStyles);
  return (
    <View style={styles.container}>
      <ChapterResumeHeader chapter={chapter} values={values} />
      {chapter.sections.map(section => (
        <SectionFlaws
          key={section.name}
          section={section}
          values={values[section.name]}
          onEdit={() => onEdit(section.name)}
        />
      ))}
    </View>
  );
};

export default ChapterResume;
