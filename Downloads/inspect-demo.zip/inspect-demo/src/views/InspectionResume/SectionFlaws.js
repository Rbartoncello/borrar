import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import {createSectionFlawsStyles} from './styles';
import {EditButton, Text} from '@/components';
import {useSectionFlaws, useThemedStyles} from '@/hooks';

const SectionFlaws = ({section, values, onEdit}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createSectionFlawsStyles);
  const issues = useSectionFlaws(section, values);
  return issues.map(issue => (
    <View key={issue.name} style={styles.container}>
      <View style={styles.dot} />
      <View style={styles.info}>
        <Text bold size="sm" style={styles.name}>
          {t(issue.name)}
        </Text>
        {issue.status && (
          <Text size="sm" style={styles.status}>
            {issue.status.map(t).join(', ')}
          </Text>
        )}
      </View>
      <EditButton onPress={() => onEdit(section.name)} />
    </View>
  ));
};

export default SectionFlaws;
