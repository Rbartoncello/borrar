const createStyles = theme => ({
  container: {
    paddingTop: theme.spacing.paddingVertical * 1.5,
    backgroundColor: theme.colors.white,
  },
});

export default createStyles;
