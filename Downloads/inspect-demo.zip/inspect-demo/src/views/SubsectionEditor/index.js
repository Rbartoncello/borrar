import {Fragment, useMemo} from 'react';
import {ScrollView} from 'react-native';
import {connect} from 'react-redux';
import createStyles from './styles';
import {Header} from '@/components';
import {DynamicForm} from '@/forms';
import {useEvent, useThemedStyles} from '@/hooks';
import {saveInspectionSubsection} from '@/state/reducer/inspection';
import {selectInspection} from '@/state/selector/inspection';
import {getIn} from '@/util';

/**
 * Get the selected values for the iteratee field in the current subsection.
 * @returns {Array<string>|undefined} Selected values for the current subsection.
 */
const getNonEligibleOptions = (
  inspection,
  chapter,
  sectionName,
  subsectionName,
  iteratee,
) => {
  const subsections =
    getIn(inspection, [chapter, sectionName, 'subsections', subsectionName]) ||
    [];
  return subsections.map(subsection => subsection[iteratee]);
};

const SubsectionEditor = ({inspection, route, onSave}) => {
  const [styles] = useThemedStyles(createStyles);
  const {chapter, sectionName, subsection, index, initialValues} = route.params;
  const formSchema = useMemo(() => {
    if (!subsection.iteratee) {
      return subsection;
    }
    return {
      ...subsection,
      fields: subsection.fields.map(field => {
        if (field.name !== subsection.iteratee) {
          return field;
        }
        return initialValues
          ? {
              ...field,
              // the iteratee field is not editable.
              disabled: true,
            }
          : {
              ...field,
              // a value for the iteratee field cannot be duplicated.
              hiddenOptions: getNonEligibleOptions(
                inspection,
                chapter,
                sectionName,
                subsection.name,
                subsection.iteratee,
              ),
            };
      }),
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [subsection, initialValues]);
  const handleSubmit = useEvent(values => {
    onSave({
      values,
      chapter,
      sectionName,
      subsection,
      index,
    });
  });
  return (
    <Fragment>
      <Header title={subsection.label} />
      <ScrollView style={styles.container}>
        <DynamicForm
          initialValues={initialValues}
          formSchema={formSchema}
          onSubmit={handleSubmit}
        />
      </ScrollView>
    </Fragment>
  );
};
export default connect(state => ({inspection: selectInspection(state)}), {
  onSave: saveInspectionSubsection,
})(SubsectionEditor);
