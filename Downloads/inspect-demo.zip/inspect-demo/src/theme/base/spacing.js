const spacing = {
  paddingHorizontal: 10,
  paddingVertical: 10,
  marginVertical: 10,
  marginHorizontal: 10,
  baseUnit: 16,
};

export default spacing;
