import colors from './colors';
import spacing from './spacing';
import typography from './typography';

export default {
  colors,
  spacing,
  typography,
};
