export const checkbox = theme => ({
  fontFamily: theme.typography.fontFamily.ralewayMedium,
  textStyle: {
    fontSize: theme.typography.regular.fontSize,
    color: theme.colors.grey1000,
    fontWeight: 'normal',
  },
});
