export const dialog = () => ({
  overlayStyle: {borderRadius: 12},
});

export const dialogButton = theme => ({
  containerStyle: {borderRadius: 8},
  titleStyle: {color: theme.colors.brandPrimary},
});

export const dialogTitle = theme => ({
  titleStyle: {
    fontSize: theme.typography.large.fontSize,
    color: theme.colors.black,
  },
});
