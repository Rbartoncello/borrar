export const text = theme => ({
  h1Style: {
    fontSize: 40,
  },
  h2Style: {
    fontSize: 34,
  },
  h3Style: {
    fontSize: 28,
  },
  h4Style: {fontSize: 22},
  base: {
    color: theme.colors.black,
  },
  title: {
    marginTop: theme.spacing.marginVertical,
    marginBottom: theme.spacing.marginVertical,
    color: theme.colors.black,
    fontSize: theme.typography.extraLarge.fontSize,
  },
  primaryTitle: {
    color: theme.colors.white,
  },
  body: {
    marginTop: theme.spacing.marginVertical,
    marginBottom: theme.spacing.marginVertical,
    color: theme.colors.grey300,
    fontSize: theme.typography.regular.fontSize,
  },
  danger: {
    color: theme.colors.red200,
  },
  dropdown: {
    fontStyle: 'normal',
    fontWeight: '500',
    fontSize: 16,
    color: theme.colors.brandDark,
  },
  style: {fontFamily: theme.typography.fontFamily.ralewayMedium},
});

export const boldText = theme => ({
  ...text(theme),
  style: {fontFamily: theme.typography.fontFamily.ralewayBold},
});
