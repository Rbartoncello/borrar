const overlay = theme => ({
  overlayStyle: {backgroundColor: theme.colors.white},
});

export default overlay;
