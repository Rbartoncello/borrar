export const button = theme => ({
  containerStyle: {
    borderRadius: 60,
  },
  buttonStyle: {
    minWidth: 120,
    paddingVertical: theme.spacing.paddingVertical * 1.5,
    backgroundColor: theme.colors.brandPrimary,
  },
  titleStyle: {
    fontFamily: theme.typography.fontFamily.ralewayMedium,
    fontSize: theme.typography.regular.fontSize,
    fontWeight: 'bold',
    color: theme.colors.white,
  },
  disabledStyle: {
    backgroundColor: theme.colors.blue250,
  },
  disabledTitleStyle: {
    color: theme.colors.white,
  },
});

export const chipButton = theme => ({
  containerStyle: {
    marginHorizontal: theme.spacing.marginHorizontal,
    marginBottom: theme.spacing.marginVertical,
    borderRadius: 10,
  },
  buttonStyle: {
    backgroundColor: theme.colors.blue150,
    paddingVertical: theme.spacing.paddingVertical,
    borderRadius: 10,
  },
  activeButton: {
    backgroundColor: theme.colors.brandPrimary,
    marginHorizontal: theme.spacing.marginHorizontal,
    paddingVertical: theme.spacing.paddingVertical,
    borderRadius: 10,
  },
  titleStyle: {
    color: theme.colors.brandPrimary,
    fontFamily: theme.typography.fontFamily.ralewayMedium,
  },
  activeTitle: {color: theme.colors.white},
});

export const clearButton = theme => ({
  containerStyle: {
    marginHorizontal: theme.spacing.marginHorizontal,
  },
  buttonStyle: {
    paddingVertical: theme.spacing.paddingVertical * 1.5,
  },
  titleStyle: {
    fontSize: theme.typography.regular.fontSize,
    fontFamily: theme.typography.fontFamily.ralewayMedium,
    color: theme.colors.brandPrimary,
  },
});

export const outlineButton = theme => ({
  containerStyle: {
    minWidth: 120,
    marginHorizontal: theme.spacing.marginHorizontal,
    paddingVertical: 0,
    borderRadius: 60,
    borderWidth: 2,
    borderColor: theme.colors.brandPrimary,
    backgroundColor: 'transparent',
  },
  titleStyle: {
    fontSize: theme.typography.regular.fontSize,
    fontWeight: '700',
    color: theme.colors.brandPrimary,
  },
});
