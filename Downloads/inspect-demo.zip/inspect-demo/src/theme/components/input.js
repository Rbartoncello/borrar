const input = theme => ({
  containerStyle: {
    borderBottomWidth: 0,
  },
  inputContainerStyle: {
    marginHorizontal: -theme.spacing.marginHorizontal,
    paddingHorizontal: theme.spacing.paddingHorizontal,
    borderWidth: 1,
    borderBottomWidth: 1,
    borderColor: theme.colors.grey600,
    borderRadius: 12,
    backgroundColor: theme.colors.white,
  },
  labelStyle: {
    paddingBottom: 5,
    color: theme.colors.grey800,
  },
  errorStyle: {
    color: theme.colors.red800,
  },
});

export default input;
