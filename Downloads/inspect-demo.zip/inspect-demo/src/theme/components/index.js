import {createTheme} from '@rneui/themed';
import {button, chipButton, clearButton, outlineButton} from './button';
import {checkbox} from './checkbox';
import {dialog, dialogButton, dialogTitle} from './dialog';
import input from './input';
import overlay from './overlay';
import {boldText, text} from './text';

const buildTheme = theme =>
  createTheme({
    ...theme,
    components: {
      BoldText: boldText(theme),
      Button: button(theme),
      CheckBox: checkbox(theme),
      ChipButton: chipButton(theme),
      ClearButton: clearButton(theme),
      Dialog: dialog(theme),
      DialogButton: dialogButton(theme),
      DialogTitle: dialogTitle(theme),
      Input: input(theme),
      OutlineButton: outlineButton(theme),
      Overlay: overlay(theme),
      Text: text(theme),
    },
  });

export default buildTheme;
