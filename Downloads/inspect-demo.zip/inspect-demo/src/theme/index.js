import base from './base';
import buildTheme from './components';

export default buildTheme(base);
