export type Config = {
    label: string;
    placeholder: string;
    disabled: boolean;
}