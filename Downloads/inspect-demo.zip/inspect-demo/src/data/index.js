const ASSET_DOMAIN = 'https://d2flsm521ymy6v.cloudfront.net/inspect/';

export const carTopView = `${ASSET_DOMAIN}ASST-inspect-f43a927d-4651-493d-9218-655a725a83b4.png`;
export const carPlaceholder = `${ASSET_DOMAIN}ASST-inspect-e44d5631-91c9-44d1-a2b9-9a84a561dff4.png`;
