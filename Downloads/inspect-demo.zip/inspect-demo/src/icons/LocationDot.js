// @flow
import {View} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const LocationDot: IconProps => React$Node = ({
  width = 20,
  height = 20,
  color = theme.colors.blue800,
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 88 88" fill="none">
      <Path
        d="M49.1846 76.6334L64.7423 61.0757C68.8445 56.9733 71.6381 51.7466 72.7698 46.0565C73.9015 40.3665 73.3205 34.4686 71.1003 29.1087C68.8801 23.7488 65.1204 19.1677 60.2965 15.9446C55.4727 12.7214 49.8015 11.0011 44 11.0011C38.1985 11.0011 32.5272 12.7214 27.7034 15.9446C22.8796 19.1677 19.1199 23.7488 16.8997 29.1087C14.6794 34.4686 14.0984 40.3665 15.2302 46.0565C16.3619 51.7466 19.1555 56.9733 23.2576 61.0757L38.819 76.6334C39.4993 77.3144 40.3073 77.8547 41.1966 78.2233C42.0859 78.5919 43.0391 78.7817 44.0018 78.7817C44.9645 78.7817 45.9177 78.5919 46.807 78.2233C47.6963 77.8547 48.5043 77.3144 49.1846 76.6334Z"
        stroke={color}
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M51.7782 48.1115C53.8411 46.0486 55 43.2507 55 40.3333C55 37.4159 53.8411 34.618 51.7782 32.5551C49.7153 30.4922 46.9174 29.3333 44 29.3333C41.0826 29.3333 38.2847 30.4922 36.2218 32.5551C34.1589 34.618 33 37.4159 33 40.3333C33 43.2507 34.1589 46.0486 36.2218 48.1115C38.2847 50.1744 41.0826 51.3333 44 51.3333C46.9174 51.3333 49.7153 50.1744 51.7782 48.1115Z"
        stroke={color}
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  </View>
);

LocationDot.propTypes = iconPropTypes;

export default LocationDot;
