// @flow
import {View} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const ChevronDown: IconProps => React$Node = ({
  width = 24,
  height = 24,
  color = theme.colors.grey800,
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 24 24" fill="none">
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M6.3517 8.75159C6.57673 8.52662 6.8819 8.40025 7.2001 8.40025C7.51829 8.40025 7.82346 8.52662 8.0485 8.75159L12.0001 12.7032L15.9517 8.75159C16.178 8.533 16.4811 8.41205 16.7958 8.41478C17.1104 8.41752 17.4114 8.54372 17.6339 8.76621C17.8564 8.9887 17.9826 9.28967 17.9853 9.60431C17.988 9.91894 17.8671 10.2221 17.6485 10.4484L12.8485 15.2484C12.6235 15.4734 12.3183 15.5997 12.0001 15.5997C11.6819 15.5997 11.3767 15.4734 11.1517 15.2484L6.3517 10.4484C6.12673 10.2234 6.00035 9.91819 6.00035 9.59999C6.00035 9.28179 6.12673 8.97662 6.3517 8.75159Z"
        fill={color}
      />
    </Svg>
  </View>
);

ChevronDown.propTypes = iconPropTypes;

export default ChevronDown;
