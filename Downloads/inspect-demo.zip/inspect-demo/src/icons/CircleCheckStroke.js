// @flow
import {View} from 'react-native';
import Svg, {Path, Rect, Circle} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const CircleCheckStroke: IconProps => React$Node = ({
  width = 30,
  height = 30,
  color = theme.colors.white,
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 30 30" fill="none">
      <Rect width="30" height="30" rx="15" />
      <Circle cx="15" cy="15" r="11" fill="#26DC85" />
      <Path
        d="M10.6 15.2748L13.7226 18.2998L19.4 12.7998"
        stroke={color}
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  </View>
);

CircleCheckStroke.propTypes = iconPropTypes;

export default CircleCheckStroke;
