// @flow
import {View} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const CircleExclamationStroke: IconProps => React$Node = ({
  width = 20,
  height = 20,
  color = theme.colors.white,
  backgroundColor = theme.colors.yellow900,
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 20 20" fill="none">
      <Path
        d="M0 10C0 4.47715 4.47715 0 10 0C15.5228 0 20 4.47715 20 10C20 15.5228 15.5228 20 10 20C4.47715 20 0 15.5228 0 10Z"
        fill={backgroundColor}
      />
      <Path
        d="M9.99414 5.33501V10M9.99414 14.665H10.0058"
        stroke={color}
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  </View>
);

CircleExclamationStroke.propTypes = iconPropTypes;

export default CircleExclamationStroke;
