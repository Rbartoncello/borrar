// @flow
import {View} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const Lock: IconProps => React$Node = ({
  width = 20,
  height = 20,
  color = theme.colors.blue800,
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 20 20" fill="none">
      <Path
        d="M9.99999 12.5V14.1667M4.99999 17.5H15C15.442 17.5 15.8659 17.3244 16.1785 17.0118C16.4911 16.6993 16.6667 16.2754 16.6667 15.8333V10.8333C16.6667 10.3913 16.4911 9.96738 16.1785 9.65482C15.8659 9.34226 15.442 9.16667 15 9.16667H4.99999C4.55797 9.16667 4.13404 9.34226 3.82148 9.65482C3.50892 9.96738 3.33333 10.3913 3.33333 10.8333V15.8333C3.33333 16.2754 3.50892 16.6993 3.82148 17.0118C4.13404 17.3244 4.55797 17.5 4.99999 17.5ZM13.3333 9.16667V5.83333C13.3333 4.94928 12.9821 4.10143 12.357 3.47631C11.7319 2.85119 10.884 2.5 9.99999 2.5C9.11594 2.5 8.26809 2.85119 7.64297 3.47631C7.01785 4.10143 6.66666 4.94928 6.66666 5.83333V9.16667H13.3333Z"
        stroke={color}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  </View>
);

Lock.propTypes = iconPropTypes;

export default Lock;
