// @flow
import {View} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const ArrowRightToClipboard: IconProps => React$Node = ({
  width = 16,
  height = 18,
  color = theme.colors.blue800,
  strokeWidth = '1.5',
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 16 18" fill="none">
      <Path
        d="M11.3332 3.16667H12.9998C13.4419 3.16667 13.8658 3.34226 14.1783 3.65482C14.4909 3.96738 14.6665 4.39131 14.6665 4.83333V14.8333C14.6665 15.2754 14.4909 15.6993 14.1783 16.0118C13.8658 16.3244 13.4419 16.5 12.9998 16.5H4.6665C4.22448 16.5 3.80055 16.3244 3.48799 16.0118C3.17543 15.6993 2.99984 15.2754 2.99984 14.8333V14M11.3332 3.16667C11.3332 3.60869 11.1576 4.03262 10.845 4.34518C10.5325 4.65774 10.1085 4.83333 9.6665 4.83333H7.99984C7.55781 4.83333 7.13389 4.65774 6.82133 4.34518C6.50877 4.03262 6.33317 3.60869 6.33317 3.16667M11.3332 3.16667C11.3332 2.72464 11.1576 2.30072 10.845 1.98816C10.5325 1.67559 10.1085 1.5 9.6665 1.5H7.99984C7.55781 1.5 7.13389 1.67559 6.82133 1.98816C6.50877 2.30072 6.33317 2.72464 6.33317 3.16667M6.33317 3.16667H4.6665C4.22448 3.16667 3.80055 3.34226 3.48799 3.65482C3.17543 3.96738 2.99984 4.39131 2.99984 4.83333V7.33333M1.33317 10.6667H9.6665M9.6665 10.6667L7.1665 8.16667M9.6665 10.6667L7.1665 13.1667"
        stroke={color}
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  </View>
);

ArrowRightToClipboard.propTypes = iconPropTypes;

export default ArrowRightToClipboard;
