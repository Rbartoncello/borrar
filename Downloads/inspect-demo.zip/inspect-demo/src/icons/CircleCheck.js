// @flow
import {View} from 'react-native';
import Svg, {Circle, Path} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const CircleCheck: IconProps => React$Node = ({
  width = 26,
  height = 26,
  color = theme.colors.green900,
  backgroundColor = theme.colors.green300,
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 26 26" fill="none">
      <Circle cx="13" cy="13" r="13" fill={backgroundColor} />
      <Path
        d="M7.80005 13.325L11.4904 16.9L18.2001 10.4"
        stroke={color}
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  </View>
);

CircleCheck.propTypes = iconPropTypes;

export default CircleCheck;
