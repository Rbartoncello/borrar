// @flow
import {View} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const User: IconProps => React$Node = ({
  width = 20,
  height = 20,
  color = theme.colors.grey800,
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 20 20" fill="none">
      <Path
        d="M13.3332 5.83333C13.3332 6.71739 12.982 7.56523 12.3569 8.19036C11.7317 8.81548 10.8839 9.16667 9.99984 9.16667C9.11578 9.16667 8.26794 8.81548 7.64281 8.19036C7.01769 7.56523 6.6665 6.71739 6.6665 5.83333C6.6665 4.94928 7.01769 4.10143 7.64281 3.47631C8.26794 2.85119 9.11578 2.5 9.99984 2.5C10.8839 2.5 11.7317 2.85119 12.3569 3.47631C12.982 4.10143 13.3332 4.94928 13.3332 5.83333V5.83333ZM9.99984 11.6667C8.45274 11.6667 6.96901 12.2812 5.87505 13.3752C4.78109 14.4692 4.1665 15.9529 4.1665 17.5H15.8332C15.8332 15.9529 15.2186 14.4692 14.1246 13.3752C13.0307 12.2812 11.5469 11.6667 9.99984 11.6667V11.6667Z"
        stroke={color}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  </View>
);

User.propTypes = iconPropTypes;

export default User;
