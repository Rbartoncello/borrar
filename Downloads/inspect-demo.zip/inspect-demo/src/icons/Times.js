// @flow
import {View} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const Times: IconProps => React$Node = ({
  width = 24,
  height = 24,
  color = theme.colors.grey1000,
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 24 24" fill="none">
      <Path
        d="M6 6L18 18M6 18L18 6L6 18Z"
        stroke={color}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  </View>
);

Times.propTypes = iconPropTypes;

export default Times;
