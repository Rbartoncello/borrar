// @flow
import {View} from 'react-native';
import Svg, {Defs, LinearGradient, Path, Rect, Stop} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const PlateBr: IconProps => React$Node = ({width = 74, height = 44, style}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 74 44" fill="none">
      <Rect width="74" height="44" rx="8" fill="url(#plate_br)" />
      <Path
        d="M51.628 24.706C51.628 25.426 51.442 26.032 51.07 26.524C50.698 27.004 50.194 27.37 49.558 27.622C48.934 27.874 48.25 28 47.506 28H41.332V15.22H48.172C48.772 15.22 49.288 15.382 49.72 15.706C50.164 16.018 50.5 16.426 50.728 16.93C50.968 17.422 51.088 17.938 51.088 18.478C51.088 19.09 50.932 19.672 50.62 20.224C50.308 20.776 49.852 21.184 49.252 21.448C49.984 21.664 50.56 22.054 50.98 22.618C51.412 23.182 51.628 23.878 51.628 24.706ZM49.126 24.238C49.126 23.914 49.06 23.626 48.928 23.374C48.796 23.11 48.616 22.906 48.388 22.762C48.172 22.606 47.92 22.528 47.632 22.528H43.816V25.894H47.506C47.806 25.894 48.076 25.822 48.316 25.678C48.568 25.522 48.766 25.318 48.91 25.066C49.054 24.814 49.126 24.538 49.126 24.238ZM43.816 17.344V20.566H47.128C47.404 20.566 47.656 20.5 47.884 20.368C48.112 20.236 48.292 20.05 48.424 19.81C48.568 19.57 48.64 19.282 48.64 18.946C48.64 18.622 48.574 18.34 48.442 18.1C48.322 17.86 48.154 17.674 47.938 17.542C47.734 17.41 47.5 17.344 47.236 17.344H43.816ZM53.5664 28V15.22H59.2184C59.8064 15.22 60.3464 15.34 60.8384 15.58C61.3424 15.82 61.7744 16.144 62.1344 16.552C62.5064 16.96 62.7884 17.416 62.9804 17.92C63.1844 18.424 63.2864 18.94 63.2864 19.468C63.2864 20.008 63.1904 20.53 62.9984 21.034C62.8184 21.526 62.5544 21.958 62.2064 22.33C61.8584 22.702 61.4504 22.99 60.9824 23.194L63.8984 28H61.1624L58.5344 23.716H56.0504V28H53.5664ZM56.0504 21.538H59.1644C59.4764 21.538 59.7524 21.448 59.9924 21.268C60.2324 21.076 60.4244 20.824 60.5684 20.512C60.7124 20.2 60.7844 19.852 60.7844 19.468C60.7844 19.06 60.7004 18.706 60.5324 18.406C60.3644 18.094 60.1484 17.848 59.8844 17.668C59.6324 17.488 59.3564 17.398 59.0564 17.398H56.0504V21.538Z"
        fill={theme.colors.white}
      />
      <Path
        d="M21.5 8V13M19 10.5H24"
        stroke={theme.colors.white}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M13.5 17V22M11 19.5H16"
        stroke={theme.colors.white}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M30.5 15V20M28 17.5H33"
        stroke={theme.colors.white}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M23.5 29V34M21 31.5H26"
        stroke={theme.colors.white}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id="plate_br"
          x1="72.4634"
          y1="-4.85372e-06"
          x2="-3.64657"
          y2="33.7407"
          gradientUnits="userSpaceOnUse">
          <Stop stopColor={theme.colors.brandDark} />
          <Stop offset="1" stopColor={theme.colors.brandPrimary} />
        </LinearGradient>
      </Defs>
    </Svg>
  </View>
);

PlateBr.propTypes = iconPropTypes;

export default PlateBr;
