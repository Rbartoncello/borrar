// @flow
import {View} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const ClipboardList: IconProps => React$Node = ({
  width = 20,
  height = 20,
  color = theme.colors.blue800,
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 20 20" fill="none">
      <Path
        d="M7.49984 4.16667H5.83317C5.39114 4.16667 4.96722 4.34226 4.65466 4.65482C4.3421 4.96738 4.1665 5.39131 4.1665 5.83333V15.8333C4.1665 16.2754 4.3421 16.6993 4.65466 17.0118C4.96722 17.3244 5.39114 17.5 5.83317 17.5H14.1665C14.6085 17.5 15.0325 17.3244 15.345 17.0118C15.6576 16.6993 15.8332 16.2754 15.8332 15.8333V5.83333C15.8332 5.39131 15.6576 4.96738 15.345 4.65482C15.0325 4.34226 14.6085 4.16667 14.1665 4.16667H12.4998M7.49984 4.16667C7.49984 4.60869 7.67543 5.03262 7.98799 5.34518C8.30055 5.65774 8.72448 5.83333 9.1665 5.83333H10.8332C11.2752 5.83333 11.6991 5.65774 12.0117 5.34518C12.3242 5.03262 12.4998 4.60869 12.4998 4.16667M7.49984 4.16667C7.49984 3.72464 7.67543 3.30072 7.98799 2.98816C8.30055 2.67559 8.72448 2.5 9.1665 2.5H10.8332C11.2752 2.5 11.6991 2.67559 12.0117 2.98816C12.3242 3.30072 12.4998 3.72464 12.4998 4.16667M9.99984 10H12.4998M9.99984 13.3333H12.4998M7.49984 10H7.50817M7.49984 13.3333H7.50817"
        stroke={color}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  </View>
);

ClipboardList.propTypes = iconPropTypes;

export default ClipboardList;
