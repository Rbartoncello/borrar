// @flow
import {View} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const Calendar: IconProps => React$Node = ({
  width = 18,
  height = 17,
  color = theme.colors.blue800,
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 18 17" fill="none">
      <Path
        d="M5.66667 4.33333V1V4.33333ZM12.3333 4.33333V1V4.33333ZM4.83333 7.66667H13.1667H4.83333ZM3.16667 16H14.8333C15.2754 16 15.6993 15.8244 16.0118 15.5118C16.3244 15.1993 16.5 14.7754 16.5 14.3333V4.33333C16.5 3.89131 16.3244 3.46738 16.0118 3.15482C15.6993 2.84226 15.2754 2.66667 14.8333 2.66667H3.16667C2.72464 2.66667 2.30072 2.84226 1.98816 3.15482C1.67559 3.46738 1.5 3.89131 1.5 4.33333V14.3333C1.5 14.7754 1.67559 15.1993 1.98816 15.5118C2.30072 15.8244 2.72464 16 3.16667 16Z"
        stroke={color}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  </View>
);

Calendar.propTypes = iconPropTypes;

export default Calendar;
