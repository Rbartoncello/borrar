// @flow
import {View} from 'react-native';
import Svg, {Defs, LinearGradient, Path, Rect, Stop} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const PlateBr: IconProps => React$Node = ({width = 74, height = 44, style}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 74 44" fill="none">
      <Rect width="74" height="44" rx="8" fill="url(#plate_ar)" />
      <Path
        d="M42.8058 15.22H45.3258L50.0238 28H47.4678L46.2798 24.814H41.8158L40.6458 28H38.0898L42.8058 15.22ZM45.8298 23.068L44.0658 17.794L42.2298 23.068H45.8298Z"
        fill={theme.colors.white}
      />
      <Path
        d="M51.4256 28V15.22H57.0776C57.6656 15.22 58.2056 15.34 58.6976 15.58C59.2016 15.82 59.6336 16.144 59.9936 16.552C60.3656 16.96 60.6476 17.416 60.8396 17.92C61.0436 18.424 61.1456 18.94 61.1456 19.468C61.1456 20.008 61.0496 20.53 60.8576 21.034C60.6776 21.526 60.4136 21.958 60.0656 22.33C59.7176 22.702 59.3096 22.99 58.8416 23.194L61.7576 28H59.0216L56.3936 23.716H53.9096V28H51.4256ZM53.9096 21.538H57.0236C57.3356 21.538 57.6116 21.448 57.8516 21.268C58.0916 21.076 58.2836 20.824 58.4276 20.512C58.5716 20.2 58.6436 19.852 58.6436 19.468C58.6436 19.06 58.5596 18.706 58.3916 18.406C58.2236 18.094 58.0076 17.848 57.7436 17.668C57.4916 17.488 57.2156 17.398 56.9156 17.398H53.9096V21.538Z"
        fill={theme.colors.white}
      />
      <Path
        d="M21.5 8V13M19 10.5H24"
        stroke={theme.colors.white}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M13.5 17V22M11 19.5H16"
        stroke={theme.colors.white}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M30.5 15V20M28 17.5H33"
        stroke={theme.colors.white}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M23.5 29V34M21 31.5H26"
        stroke={theme.colors.white}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id="plate_ar"
          x1="72.4634"
          y1="-4.85372e-06"
          x2="-3.64657"
          y2="33.7407"
          gradientUnits="userSpaceOnUse">
          <Stop stopColor={theme.colors.brandDark} />
          <Stop offset="1" stopColor={theme.colors.brandPrimary} />
        </LinearGradient>
      </Defs>
    </Svg>
  </View>
);

PlateBr.propTypes = iconPropTypes;

export default PlateBr;
