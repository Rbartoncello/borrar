// @flow
import {View} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const Bars: IconProps => React$Node = ({
  width = 18,
  height = 14,
  color = theme.colors.white,
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 18 14" fill="none">
      <Path d="M1 1H17H1ZM1 7H17H1ZM10 13H17H10Z" fill={color} />
      <Path
        d="M10 13H17M1 1H17H1ZM1 7H17H1Z"
        stroke={color}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  </View>
);

Bars.propTypes = iconPropTypes;

export default Bars;
