// @flow
import {View} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const Check: IconProps => React$Node = ({
  width = 16,
  height = 17,
  color = theme.colors.white,
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 16 17" fill="none">
      <Path
        d="M13.3657 4.73441C13.5157 4.88443 13.5999 5.08788 13.5999 5.30001C13.5999 5.51214 13.5157 5.71559 13.3657 5.86561L6.96568 12.2656C6.81566 12.4156 6.61221 12.4998 6.40008 12.4998C6.18795 12.4998 5.9845 12.4156 5.83448 12.2656L2.63448 9.06561C2.48876 8.91473 2.40812 8.71265 2.40994 8.50289C2.41177 8.29313 2.4959 8.09248 2.64423 7.94416C2.79255 7.79583 2.9932 7.7117 3.20296 7.70987C3.41272 7.70805 3.6148 7.78869 3.76568 7.93441L6.40008 10.5688L12.2345 4.73441C12.3845 4.58444 12.5879 4.50018 12.8001 4.50018C13.0122 4.50018 13.2157 4.58444 13.3657 4.73441Z"
        fillRule="evenodd"
        clipRule="evenodd"
        fill={color}
      />
    </Svg>
  </View>
);

Check.propTypes = iconPropTypes;

export default Check;
