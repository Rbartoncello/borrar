// @flow
import {View} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const ArrowLeft: IconProps => React$Node = ({
  width = 20,
  height = 20,
  color = theme.colors.white,
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 20 20" fill="none">
      <Path
        d="M15 8.75C15.4142 8.75 15.75 8.41421 15.75 8C15.75 7.58579 15.4142 7.25 15 7.25V8.75ZM1 8L0.46967 7.46967C0.176777 7.76256 0.176777 8.23744 0.46967 8.53033L1 8ZM7.46967 15.5303C7.76256 15.8232 8.23744 15.8232 8.53033 15.5303C8.82322 15.2374 8.82322 14.7626 8.53033 14.4697L7.46967 15.5303ZM8.53033 1.53033C8.82322 1.23744 8.82322 0.762563 8.53033 0.46967C8.23744 0.176777 7.76256 0.176777 7.46967 0.46967L8.53033 1.53033ZM15 7.25H1V8.75H15V7.25ZM8.53033 14.4697L1.53033 7.46967L0.46967 8.53033L7.46967 15.5303L8.53033 14.4697ZM1.53033 8.53033L8.53033 1.53033L7.46967 0.46967L0.46967 7.46967L1.53033 8.53033Z"
        stroke={color}
        strokeWidth="1"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={color}
      />
    </Svg>
  </View>
);

ArrowLeft.propTypes = iconPropTypes;

export default ArrowLeft;
