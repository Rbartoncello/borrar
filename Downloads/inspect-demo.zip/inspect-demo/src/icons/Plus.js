// @flow
import {View} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const PenToSquare: IconProps => React$Node = ({
  width = 25,
  height = 24,
  color = theme.colors.blue800,
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 25 24" fill="none">
      <Path
        d="M12.7001 10.8V11.8H13.7001H19.7001C19.7531 11.8 19.804 11.821 19.8415 11.8586C19.879 11.8961 19.9001 11.9469 19.9001 12C19.9001 12.053 19.879 12.1039 19.8415 12.1414C19.804 12.1789 19.7531 12.2 19.7001 12.2H13.7001H12.7001V13.2V19.2C12.7001 19.253 12.679 19.3039 12.6415 19.3414C12.604 19.3789 12.5531 19.4 12.5001 19.4C12.4471 19.4 12.3962 19.3789 12.3587 19.3414C12.3212 19.3039 12.3001 19.253 12.3001 19.2V13.2V12.2H11.3001H5.3001C5.24706 12.2 5.19618 12.1789 5.15868 12.1414C5.12117 12.1039 5.1001 12.053 5.1001 12C5.1001 11.9469 5.12117 11.8961 5.15868 11.8586C5.19618 11.821 5.24706 11.8 5.3001 11.8H11.3001H12.3001V10.8V4.79998C12.3001 4.74693 12.3212 4.69606 12.3587 4.65855C12.3962 4.62105 12.4471 4.59998 12.5001 4.59998C12.5531 4.59998 12.604 4.62105 12.6415 4.65856C12.679 4.69606 12.7001 4.74693 12.7001 4.79998V10.8Z"
        fill={color}
        stroke={color}
        strokeWidth="2"
      />
    </Svg>
  </View>
);

PenToSquare.propTypes = iconPropTypes;

export default PenToSquare;
