// @flow
import {View} from 'react-native';
import Svg, {Circle as C} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const Circle: IconProps => React$Node = ({
  width = 24,
  height = 24,
  color = theme.colors.white,
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 24 24" fill={color}>
      <C cx="12" cy="12" r="11.5" stroke="#AFB1BC" />
    </Svg>
  </View>
);

Circle.propTypes = iconPropTypes;

export default Circle;
