// @flow
import {View} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';

const Brazil: IconProps => React$Node = ({width = 20, height = 20, style}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 20 20" fill="none">
      <Path
        d="M20 10C20 15.5228 15.5228 20 10 20C4.47715 20 0 15.5228 0 10C0 4.47715 4.47715 0 10 0C15.5228 0 20 4.47715 20 10Z"
        fill="#6EA644"
      />
      <Path d="M10.25 4L18.5 10L10.25 16L2 10L10.25 4Z" fill="#FFDB44" />
      <Path
        d="M13.75 10C13.75 11.933 12.183 13.5 10.25 13.5C8.317 13.5 6.75 11.933 6.75 10C6.75 8.067 8.317 6.5 10.25 6.5C12.183 6.5 13.75 8.067 13.75 10Z"
        fill="#0051B5"
      />
      <Path
        d="M7.08682 8.5C6.87085 8.95463 6.75 9.4632 6.75 10C10.35 9.4 12.4375 11.1667 13.0313 12.125C13.3864 11.661 13.6279 11.1055 13.7146 10.5C11.7146 8.5 8.46273 8.33333 7.08682 8.5Z"
        fill="white"
      />
    </Svg>
  </View>
);

Brazil.propTypes = iconPropTypes;

export default Brazil;
