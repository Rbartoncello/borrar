// @flow
import {View} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const ArrowRightFromSquare: IconProps => React$Node = ({
  width = 18,
  height = 14,
  color = theme.colors.grey900,
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 24 24" fill="none">
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M6 4.75C4.75736 4.75 3.75 5.75736 3.75 7V17C3.75 18.2426 4.75736 19.25 6 19.25H10C11.2426 19.25 12.25 18.2426 12.25 17V16C12.25 15.5858 12.5858 15.25 13 15.25C13.4142 15.25 13.75 15.5858 13.75 16V17C13.75 19.0711 12.0711 20.75 10 20.75H6C3.92893 20.75 2.25 19.0711 2.25 17V7C2.25 4.92893 3.92893 3.25 6 3.25H10C12.0711 3.25 13.75 4.92893 13.75 7V8C13.75 8.41421 13.4142 8.75 13 8.75C12.5858 8.75 12.25 8.41421 12.25 8V7C12.25 5.75736 11.2426 4.75 10 4.75H6ZM16.4697 7.46967C16.7626 7.17678 17.2374 7.17678 17.5303 7.46967L21.5303 11.4697C21.671 11.6103 21.75 11.8011 21.75 12C21.75 12.1989 21.671 12.3897 21.5303 12.5303L17.5303 16.5303C17.2374 16.8232 16.7626 16.8232 16.4697 16.5303C16.1768 16.2374 16.1768 15.7626 16.4697 15.4697L19.1893 12.75L7 12.75C6.58579 12.75 6.25 12.4142 6.25 12C6.25 11.5858 6.58579 11.25 7 11.25L19.1893 11.25L16.4697 8.53033C16.1768 8.23744 16.1768 7.76256 16.4697 7.46967Z"
        fill={color}
      />
    </Svg>
  </View>
);

ArrowRightFromSquare.propTypes = iconPropTypes;

export default ArrowRightFromSquare;
