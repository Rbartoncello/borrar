// @flow
import PropTypes from 'prop-types';
import {StyleProp, ViewStyle} from 'react-native';

export interface IconProps {
  style?: StyleProp<ViewStyle>;
  color?: string;
  width?: number;
  height?: number;
  strokeWidth?: string;
}

export const iconPropTypes = {
  color: PropTypes.string,
  width: PropTypes.number,
  height: PropTypes.number,
  strokeWidth: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};
