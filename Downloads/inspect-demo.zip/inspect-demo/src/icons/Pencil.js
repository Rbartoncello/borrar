// @flow
import {View} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const Pencil: IconProps => React$Node = ({
  width = 18,
  height = 18,
  color = theme.colors.blue800,
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 18 18" fill="none">
      <Path
        d="M13.3033 1.303C13.5247 1.07378 13.7895 0.890942 14.0823 0.765161C14.3751 0.639379 14.6901 0.573172 15.0087 0.570403C15.3274 0.567634 15.6434 0.628358 15.9384 0.749032C16.2333 0.869706 16.5013 1.04791 16.7266 1.27326C16.952 1.4986 17.1302 1.76656 17.2509 2.06151C17.3715 2.35647 17.4323 2.6725 17.4295 2.99117C17.4267 3.30984 17.3605 3.62477 17.2347 3.91757C17.109 4.21038 16.9261 4.47521 16.6969 4.6966L15.7453 5.6482L12.3517 2.2546L13.3033 1.303ZM10.6549 3.9514L0.600098 14.0062V17.3998H3.9937L14.0497 7.345L10.6537 3.9514H10.6549Z"
        fill={color}
      />
    </Svg>
  </View>
);

Pencil.propTypes = iconPropTypes;

export default Pencil;
