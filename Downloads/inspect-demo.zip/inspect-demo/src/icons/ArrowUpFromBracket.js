// @flow
import {View} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import {IconProps, iconPropTypes} from './util';
import theme from '@/theme/base';

const ArrowUpFromBracket: IconProps => React$Node = ({
  width = 16,
  height = 16,
  color = theme.colors.blue800,
  style,
}) => (
  <View style={style}>
    <Svg width={width} height={height} viewBox="0 0 16 16" fill="none">
      <Path
        d="M14.6665 11.3333V12.1666C14.6665 12.8297 14.4031 13.4656 13.9343 13.9344C13.4654 14.4033 12.8295 14.6666 12.1665 14.6666H3.83317C3.17013 14.6666 2.53425 14.4033 2.0654 13.9344C1.59656 13.4656 1.33317 12.8297 1.33317 12.1666V11.3333M4.6665 4.66665L7.99984 1.33331M7.99984 1.33331L11.3332 4.66665M7.99984 1.33331V11.3333"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  </View>
);

ArrowUpFromBracket.propTypes = iconPropTypes;

export default ArrowUpFromBracket;
