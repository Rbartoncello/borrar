/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import {ThemeProvider} from '@rneui/themed';
import {useEffect} from 'react';
import {useColorScheme, StyleSheet} from 'react-native';
import Orientation from 'react-native-orientation-locker';
import {SafeAreaProvider, SafeAreaView} from 'react-native-safe-area-context';
import {Colors} from 'react-native/Libraries/NewAppScreen';
import {Provider} from 'react-redux';
import {persistStore} from 'redux-persist';
import {PersistGate} from 'redux-persist/integration/react';
import KeyboardView from './components/KeyboardView';
import Navigation from './navigation';
import {store} from './state';
import theme from './theme';
import {useVersionCheck} from '@/hooks';

const App = () => {
  useVersionCheck();
  const isDarkMode = useColorScheme() === 'dark';
  const backgroundStyle = {
    flex: 1,
    backgroundColor: isDarkMode ? Colors.darker : Colors.lighter,
  };
  useEffect(() => {
    Orientation.lockToPortrait();
  }, []);
  return (
    <Provider store={store}>
      <PersistGate persistor={persistStore(store)}>
        <ThemeProvider theme={theme}>
          <SafeAreaProvider style={backgroundStyle}>
            <SafeAreaView style={styles.safeArea}>
              <KeyboardView>
                <Navigation />
              </KeyboardView>
            </SafeAreaView>
          </SafeAreaProvider>
        </ThemeProvider>
      </PersistGate>
    </Provider>
  );
};

const styles = StyleSheet.create({safeArea: {flex: 1}});

export default App;
