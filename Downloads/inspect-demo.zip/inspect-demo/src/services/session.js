import Http from './http';

class SessionService {
  constructor(token) {
    this.http = new Http(token, 'api/pub/auth-core/v1');
    this.appKey = 'VERIFIKAR';
  }

  login = (email, password) =>
    this.http.post('login', {
      email,
      password,
      application_key: this.appKey,
    });
}

export default SessionService;
