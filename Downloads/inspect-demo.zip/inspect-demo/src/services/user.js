import Http from './http';

class UserService {
  constructor(token) {
    this.http = new Http(token, 'api/auth/verifikar/v1');
  }

  fetchCurrentUser = () => this.http.get('users');
}

export default UserService;
