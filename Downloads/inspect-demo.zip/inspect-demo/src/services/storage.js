import AsyncStorage from '@react-native-async-storage/async-storage';

const getAllKeys = async prefix => {
  const keys = await AsyncStorage.getAllKeys();
  return keys.filter(key => key.startsWith(prefix));
};

class StorageService {
  constructor(collection) {
    this.collection = collection;
    this.prefix = `${collection}:`;
  }

  createKey = id => `${this.prefix}${id}`;

  /**
   * Find the item based on the given id.
   * @param {String|Number} id The ID to lookup into the collection.
   * @returns {Promise<any>}
   */
  async findById(id) {
    return JSON.parse(await AsyncStorage.getItem(this.createKey(id)));
  }

  /**
   * Fetch first item on the collection.
   * @returns {Promise<any>} A promise with the first item.
   */
  async findOne() {
    const keys = await getAllKeys(this.prefix);
    return keys.length ? JSON.parse(await AsyncStorage.getItem(keys[0])) : null;
  }

  /**
   * Fetch all the items on the collection.
   * @returns {Promise<Array<any>>} A promise with the found items.
   */
  async findAll() {
    const keys = await getAllKeys(this.prefix);
    if (!keys.length) {
      return [];
    }
    const items = await AsyncStorage.multiGet(keys);
    return items.map(result => JSON.parse(result[1]));
  }

  /**
   * Saves one or more items into the collection.
   * @param {Array<any>|any} objects One or more object to be saved.
   * @param {Function} keySelector The key selector to generate the item ID.
   * @returns {Promise<void>} A promise when the save is completed.
   */
  async save(objects, keySelector) {
    if (!Array.isArray(objects)) {
      objects = [objects];
    }
    if (!objects.length) {
      return null;
    }
    return AsyncStorage.multiSet(
      objects.map(object => [
        this.createKey(keySelector(object)),
        JSON.stringify(object),
      ]),
    );
  }

  /**
   * Removes one or more items from the collection.
   * @param {Array<String>|Array<Number>|String|Number} ids One or more IDs to be removed.
   * @returns {Promise<void>} A promise when the remove is completed.
   */
  async remove(ids) {
    if (!Array.isArray(ids)) {
      ids = [ids];
    }
    if (!ids.length) {
      return null;
    }
    return AsyncStorage.multiRemove(ids.map(id => this.createKey(id)));
  }

  /**
   * Removes all the items into the collection.
   * @returns {Promise<void>} A promise when the remove is completed.
   */
  async removeAll() {
    const keys = await getAllKeys(this.prefix);
    if (!keys.length) {
      return null;
    }
    return AsyncStorage.multiRemove(keys);
  }

  /**
   * Retrieves the count of items into the collection.
   * @returns {Promise<Number>} A promise with the count of items into the collection.
   */
  async count() {
    const keys = await getAllKeys(this.prefix);
    return keys.length;
  }
}

export default StorageService;
