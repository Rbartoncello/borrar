import Http from './http';

const formatOptions = values =>
  values.map(value => ({id: value.id, name: value.name.toUpperCase()}));

class CatalogService {
  constructor(token) {
    this.http = new Http(token, 'api/auth/verifikar/v1/catalog');
  }

  fetchBrands = async () => {
    const {brands} = await this.http.get('brands');
    return formatOptions(brands);
  };

  fetchModels = async brand => {
    const {models} = await this.http.get(`brands/${brand}/models`);
    return formatOptions(models);
  };

  fetchColors = async () => {
    const {colors} = await this.http.get('colors');
    return colors.map(color =>
      !color.hex || color.hex === '#'
        ? {id: color.id, name: color.name}
        : color,
    );
  };

  fetchVersions = async (brand, model, year) => {
    const {versions} = await this.http.get(
      `brands/${brand}/models/${model}/years/${year}/versions`,
    );
    return formatOptions(versions);
  };

  fetchYears = async (brandId, modelId) => {
    if (!modelId || !brandId) {
      return [];
    }
    return this.http.get(`years/brands/${brandId}/models/${modelId}`);
  };
}

export default CatalogService;
