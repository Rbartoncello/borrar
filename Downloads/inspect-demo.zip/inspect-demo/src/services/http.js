const DOMAIN = '';
const JSON_MIME_TYPE = 'application/json';

class Http {
  constructor(idToken, endpoint) {
    this.idToken = idToken;
    this.endpoint = !endpoint.startsWith('http')
      ? `${DOMAIN}/${endpoint}`
      : endpoint;
  }

  getUrl = url => (url ? `${this.endpoint}/${url}` : this.endpoint);

  /**
   * Get the session token.
   * @returns {string} Returns the current session token.
   */
  getIdToken = () => this.idToken;

  /**
   * Check if a token session is present.
   * @returns {boolean} Returns True when a token is present.
   */
  hasSession = () => !!this.idToken;

  /**
   * Get a Bearer Auth Header for make HTTP requests.
   * @returns {any} An authorization header.
   */
  getAuthHeader = () =>
    this.hasSession() ? {Authorization: `Bearer ${this.idToken}`} : undefined;

  getSearchParams = params => {
    if (!params) {
      return '';
    }
    const searchParams = new URLSearchParams();
    Object.entries(params)
      .filter(([_, value]) => value !== undefined && value !== null)
      .forEach(([key, value]) => searchParams.append(key, value));
    return `?${searchParams.toString()}`;
  };

  processResponse = async response => {
    if (response?.status === 401) {
      throw response;
    }
    const result = await response.json();
    if (response.ok) {
      return result.response?.data || result;
    }
    const error = new Error(result.message || response.statusText);
    error.status = response.status;
    error.response = result;
    throw error;
  };

  get = async (url, params) => {
    const response = await fetch(
      `${this.getUrl(url)}${this.getSearchParams(params)}`,
      {
        headers: {
          ...this.getAuthHeader(),
          Accept: JSON_MIME_TYPE,
        },
      },
    );
    return this.processResponse(response);
  };

  post = async (url, data) => {
    const response = await fetch(this.getUrl(url), {
      method: 'POST',
      headers: {
        ...this.getAuthHeader(),
        'Content-Type': JSON_MIME_TYPE,
      },
      body: JSON.stringify(data),
    });
    return this.processResponse(response);
  };

  /**
   * Send a POST file request to the given URL.
   * @param {string} url a URL where the request is sent.
   * @param {string} uri a URI to the file to be sent in the request body.
   * @returns {Promise<any>} A promise with the response body when the request is completed.
   */
  postFile = async (url, uri) => {
    const body = new FormData();
    body.append('file', {uri, type: 'application/octet-stream', name: 'file'});
    const response = await fetch(this.getUrl(url), {
      body,
      method: 'POST',
      headers: {
        ...this.getAuthHeader(),
        'Content-Type': 'multipart/form-data',
      },
    });
    return this.processResponse(response);
  };
}

export default Http;
