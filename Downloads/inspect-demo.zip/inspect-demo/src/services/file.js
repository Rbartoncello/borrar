import fs from 'react-native-fs';
import {isEmpty, isString} from '@/util';

const getFilename = filePath => filePath.split('/').pop();

const FILE_PROTOCOL = 'file://';
const PDF_EXTENSION = 'pdf';

class FileService {
  constructor(id) {
    this.id = id;
    this.tempDirPath = `${FILE_PROTOCOL}${fs.ExternalStorageDirectoryPath}`;
    this.cacheDirPath = `${FILE_PROTOCOL}${fs.CachesDirectoryPath}`;
    this.dirPath = `${FILE_PROTOCOL}${fs.DocumentDirectoryPath}/inspection-${this.id}`;
  }

  createFolder = () => fs.mkdir(this.dirPath);
  removeFolder = () => fs.unlink(this.dirPath);

  isTempPath = path =>
    isString(path) &&
    (path.startsWith(this.tempDirPath) || path.startsWith(this.cacheDirPath));

  saveFile = async source => {
    if (!this.isTempPath(source)) {
      return;
    }
    const filename = getFilename(source);
    const destinationPath = `${this.dirPath}/${filename}`;
    await fs.copyFile(source, destinationPath);
    return destinationPath;
  };

  saveFileArray = values =>
    values.map(value =>
      this.isTempPath(value) ? this.saveFile(value) : value,
    );

  getFileKeys = values =>
    Object.keys(values).filter(key => {
      let value;
      if (values[key] && isString(values[key])) {
        value = values[key];
      }
      if (values[key] && typeof values[key] === 'object') {
        value = values[key]?.value || values[key]?.values;
      }
      if (!value) {
        return false;
      }
      return (
        (Array.isArray(value) && value.length > 0) || this.isTempPath(value)
      );
    });

  saveFiles = async values => {
    const keys = this.getFileKeys(values);
    if (!keys.length) {
      return values;
    }
    values = {...values};
    for (const key of keys) {
      const value = values[key]?.value || values[key]?.values || values[key];
      if (isString(values[key])) {
        values[key] = await this.saveFile(value);
      } else if (Array.isArray(value)) {
        values[key].values = await Promise.all(this.saveFileArray(value));
      } else {
        values[key].value = await this.saveFile(value);
      }
    }
    return values;
  };

  removeFileArray = values =>
    values.map(value =>
      isString(value) && value.startsWith(FILE_PROTOCOL)
        ? fs.unlink(value)
        : undefined,
    );

  removeFiles = async values => {
    const keys = this.getFileKeys(values);
    if (!keys.length) {
      return;
    }
    return Promise.all(
      keys.map(key => {
        const value = values[key]?.value || values[key]?.values || values[key];
        if (Array.isArray(value)) {
          return Promise.all(this.removeFileArray(value));
        }
        return fs.unlink(value);
      }),
    );
  };

  getFile = (file, id) => {
    const type = typeof file;
    switch (type) {
      case 'object':
        if (Array.isArray(file)) {
          return this.getFilesFromArray(file, id);
        }
        return this.getFilesFromObject(file, id);
      case 'string':
        if (file.startsWith(FILE_PROTOCOL)) {
          return {url: file, path: [], id};
        }
        break;
      default: {
        return undefined;
      }
    }
  };

  getIsPDF = file => file?.split('.').pop() === PDF_EXTENSION;

  mapValueToFile = (value, path, id) => {
    const file = this.getFile(value, id);
    if (file === undefined || isEmpty(file)) {
      return undefined;
    }
    if (Array.isArray(file)) {
      file.forEach(p => p.path.unshift(path));
    } else {
      file.path.unshift(path);
    }
    return file;
  };

  getFilesFromArray = (values, id) =>
    values
      .map((value, index) => this.mapValueToFile(value, index, id))
      .filter(x => x)
      .flatMap(x => x);

  getFilesFromObject = (obj, id) =>
    Object.entries(obj)
      .map(([key, value]) => this.mapValueToFile(value, key, id))
      .filter(x => x)
      .flatMap(x => x);

  clearExternalDirectory = async () => {
    const files = await fs.readDir(fs.ExternalDirectoryPath);
    const pictureFolder = files.find(f => f.name === 'Pictures');
    if (pictureFolder) {
      return fs.unlink(pictureFolder.path);
    }
  };

  clearDocumentDirectory = async () => {
    const files = await fs.readDir(fs.DocumentDirectoryPath);
    const inspectionFolders = files.filter(f =>
      f.name.startsWith('inspection'),
    );
    if (inspectionFolders.length) {
      return Promise.all(inspectionFolders.map(f => fs.unlink(f.path)));
    }
  };

  /**
   * Remove inspection pictures from external storage and
   * Document directory.
   * @returns {Promise<void|undefined>}
   */
  clear = async () => {
    await this.clearDocumentDirectory();
    return this.clearExternalDirectory();
  };
}

export default FileService;
