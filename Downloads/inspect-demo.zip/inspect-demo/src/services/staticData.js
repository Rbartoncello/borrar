import i18next from 'i18next';
import {Image} from 'react-native';
import Http from './http';
import {carTopView} from '@/data';
import {getLanguageFromSite} from '@/util';

class StaticDataService {
  constructor(token) {
    this.http = new Http(token, 'api/auth/verifikar/v1');
  }

  loadResourceLanguage = async site => {
    const resourceLanguage = await this.http.get('i18n');
    const language = getLanguageFromSite(site);
    Object.entries(resourceLanguage).forEach(([ns, resources]) =>
      i18next.addResources(language, ns, resources),
    );
  };

  fetchQuestionnaires = companyId =>
    this.http.get(`questionnaires/full/company/${companyId}`);

  prefetchImages = () => Image.prefetch(carTopView);

  prefectChapterSvgImages = async chapters =>
    chapters &&
    Promise.all(
      chapters.map(async chapter => {
        if (!chapter.imageUrl) {
          return;
        }
        const response = await fetch(chapter.imageUrl);
        return {...chapter, image: await response.text()};
      }),
    );

  prefetchQuestionnaireImages = questionnaire => {
    const images = Array.from(
      new Set(
        questionnaire.chapters
          ?.filter(chapter => chapter.sections)
          .flatMap(chapter =>
            chapter.sections.flatMap(section =>
              section.fields
                .filter(
                  field =>
                    !!field.placeholder &&
                    field.type.startsWith('photo') &&
                    field.placeholder.startsWith('http'),
                )
                .map(field => field.placeholder),
            ),
          ),
      ),
    );
    return Promise.all(images.map(image => Image.prefetch(image)));
  };
}

export default StaticDataService;
