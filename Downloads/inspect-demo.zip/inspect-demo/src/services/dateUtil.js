import {isEmpty} from '@/util';

class DateUtilService {
  minDate = new Date(2000, 0, 1, 12);

  formatDate = date => {
    if (isEmpty(date)) {
      return;
    }
    const formatter = new Intl.DateTimeFormat('es-AR');
    return formatter.format(new Date(date));
  };
  formatDateTime = date => {
    if (!date) {
      return;
    }
    const options = {
      year: 'numeric',
      month: 'numeric',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
      timeZone: 'America/Argentina/Buenos_Aires',
    };
    const formatter = new Intl.DateTimeFormat('es-AR', options);
    return formatter.format(new Date(date));
  };

  parse = input => {
    const date = new Date(input);
    return !Number.isNaN(date.getTime()) ? date : undefined;
  };

  tryParseOrDefault = (input, defaultValue = new Date()) =>
    this.parse(input) || defaultValue;
}

export default DateUtilService;
