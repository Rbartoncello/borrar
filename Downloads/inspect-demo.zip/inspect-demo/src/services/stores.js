import Http from './http';

class StoresService {
  constructor(token) {
    this.http = new Http(token, 'api/auth/verifikar/v1/stores');
  }

  search = async term => {
    const {stores} = await this.http.get('', {q: term});
    return stores;
  };
}

export default StoresService;
