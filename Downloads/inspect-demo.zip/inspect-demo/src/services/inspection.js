import VersionCheck from 'react-native-version-check';
import FileService from './file';
import StorageService from './storage';
import {INSPECTION_STATUS} from '@/constants';
import {getIn, mergeIn, setIn} from '@/util';

class InspectionService {
  constructor() {
    this.storage = new StorageService('inspection');
    this.inspectionExpire = 30;
  }

  fetch = () => this.storage.findAll();
  find = id => this.storage.findById(id);

  getObsoleteInspectionsThreshold() {
    const threshold = new Date();
    threshold.setDate(threshold.getDate() - this.inspectionExpire);
    return threshold.getTime();
  }

  removeObsoletePendingInspections = async () => {
    const threshold = this.getObsoleteInspectionsThreshold();
    const inspections = await this.fetch();
    return Promise.all(
      inspections
        .filter(inspection => inspection.id < threshold && !inspection.done)
        .map(inspection => this.remove(inspection.id)),
    );
  };

  fetchByState = async () => {
    const inspections = await this.fetch();
    return inspections.reduce(
      (accum, inspection) => {
        accum[
          inspection.done ? INSPECTION_STATUS.CLOSED : INSPECTION_STATUS.PENDING
        ].push(inspection);
        return accum;
      },
      {pending: [], closed: []},
    );
  };

  save = async inspection => {
    await this.storage.save(inspection, x => x.id);
    return inspection;
  };

  remove = async id => {
    await this.storage.remove(id);
    const fileService = new FileService(id);
    return fileService.removeFolder();
  };

  saveFiles = (id, values) => {
    const fileService = new FileService(id);
    return fileService.saveFiles(values);
  };

  findByPlate = async plate => {
    const inspections = await this.fetch();
    plate = plate.toUpperCase();
    return inspections.find(inspection => inspection.car.plate === plate);
  };

  create = async (car, defaultValues = {}) => {
    const existingInspection = await this.findByPlate(car.plate);
    if (existingInspection) {
      throw new Error('car:plateAlreadyUsed');
    }
    const id = new Date().getTime();
    const inspection = await this.save({
      id,
      questionnaireId: car.configuration,
      version: VersionCheck.getCurrentVersion(),
      ...defaultValues,
      car: {
        ...car,
        plate: car.plate.toUpperCase(),
      },
    });
    const fileService = new FileService(id);
    await fileService.createFolder();
    return inspection;
  };

  close = async id => {
    const inspection = await this.find(id);
    inspection.done = true;
    inspection.inspectionFinishedAt = new Date().toISOString();
    return this.save(inspection);
  };

  reopenAll = async () => {
    const inspections = await this.fetch();
    return Promise.all(
      inspections
        .filter(inspection => inspection.done)
        .map(inspection => {
          delete inspection.done;
          return this.save(inspection);
        }),
    );
  };

  reopen = async id => {
    const inspection = await this.find(id);
    delete inspection.done;
    return this.save(inspection);
  };

  saveSection = async (id, chapter, section, values) => {
    const inspection = await this.find(id);
    values = await this.saveFiles(id, values);
    setIn(inspection, [chapter, section], values);
    return this.save(inspection);
  };

  saveSubsection = async (
    id,
    chapter,
    sectionName,
    values,
    subsection,
    index,
  ) => {
    const inspection = await this.find(id);
    values = await this.saveFiles(id, values);
    if (index >= 0) {
      // update an item in iterable subsection.
      getIn(inspection, [chapter, sectionName, 'subsections', subsection.name])[
        index
      ] = values;
    } else if (subsection?.iteratee) {
      if (
        !getIn(inspection, [
          chapter,
          sectionName,
          'subsections',
          subsection.name,
        ])
      ) {
        // create an iterable subsection with the first item.
        setIn(
          inspection,
          [chapter, sectionName, 'subsections', subsection.name],
          [values],
        );
      } else {
        // append an item to an iterable subsection.
        mergeIn(
          inspection,
          [chapter, sectionName, 'subsections', subsection.name],
          values,
        );
      }
    } else {
      // update a non-iterable subsection.
      setIn(
        inspection,
        [chapter, sectionName, 'subsections', subsection.name],
        values,
      );
    }
    return this.save(inspection);
  };

  removeSubsection = async (id, chapter, sectionName, subsections, index) => {
    const inspection = await this.find(id);
    const subsection = getIn(inspection, [
      chapter,
      sectionName,
      'subsections',
      subsections.name,
    ]);
    const fileService = new FileService(id);
    if (index >= 0) {
      await fileService.removeFiles(subsection[index]);
      subsection.splice(index, 1);
    } else {
      await fileService.removeFiles(subsection);
      setIn(
        inspection,
        [chapter, sectionName, 'subsections', subsections.name],
        undefined,
      );
    }
    return this.save(inspection);
  };

  /**
   * Remove all inspections from storage.
   * @returns {Promise<void>}
   */
  clear = async () => {
    const fileService = new FileService('');
    await fileService.clear();
    return this.storage.removeAll();
  };
}

export default InspectionService;
