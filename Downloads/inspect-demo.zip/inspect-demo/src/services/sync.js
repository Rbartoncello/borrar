import FileService from './file';
import Http from './http';
import InspectionService from './inspection';
import {DEMO_USERS} from '@/constants';
import {setIn} from '@/util';

class SyncService {
  constructor(token) {
    this.http = new Http(token, 'api/auth/verifikar/v1');
  }

  uploadInspection = async inspection => {
    // not required by the inspections API.
    inspection.car.brandId = undefined;
    inspection.car.modelId = undefined;
    inspection.car.versionId = undefined;
    inspection.car.store.name = undefined;
    inspection.car.store.address = undefined;
    inspection.car.configuration = undefined;
    inspection.done = undefined;
    const {id} = await this.http.post('inspections', {inspection});
    return id;
  };

  uploadPhoto = async photo => {
    const {imageUrl} = await this.http.postFile('images', photo);
    return imageUrl;
  };

  uploadDocument = async (id, path, document) => {
    path.pop();
    const label = path.join('-');
    const {imageUrl} = await this.http.postFile(
      `documents/${id}?label=${label}`,
      document,
    );
    return imageUrl;
  };

  sync = async (inspectionId, userEmail) => {
    const inspectionService = new InspectionService();
    const inspection = await inspectionService.find(inspectionId);
    if (DEMO_USERS.includes(userEmail)) {
      await inspectionService.remove(inspectionId);
      return inspectionId;
    }
    const fileService = new FileService(inspection.id);
    const files = fileService.getFilesFromObject(
      inspection,
      inspection.car.plate,
    );
    for (const file of files) {
      let url;
      if (fileService.getIsPDF(file.url)) {
        url = await this.uploadDocument(file.id, file.path, file.url);
      } else {
        url = await this.uploadPhoto(file.url);
      }
      setIn(inspection, file.path, url);
    }
    const id = await this.uploadInspection(inspection);
    await inspectionService.remove(inspectionId);
    return id;
  };
}

export default SyncService;
