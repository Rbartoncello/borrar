import Http from './http';
import {BR_PLATE_REGEX, AR_PLATE_REGEX, LANGUAGES} from '@/constants';

class CarsService {
  constructor(token) {
    this.http = new Http(token, 'api/auth/verifikar/v1/cars');
  }

  isValidPlate(plate, language) {
    if (language === LANGUAGES.ES) {
      return AR_PLATE_REGEX.test(plate);
    }
    return BR_PLATE_REGEX.test(plate);
  }

  find = async plate => {
    const {car} = await this.http.get(plate);
    return car?.brand ? car : null;
  };
}

export default CarsService;
