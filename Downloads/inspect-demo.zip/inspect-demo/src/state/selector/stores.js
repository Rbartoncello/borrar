export const selectStoreStatus = state => state.stores.status;
export const selectStores = state => state.stores.stores;
