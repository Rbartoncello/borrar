export const selectBrands = state => state.catalog.brands;
export const selectColors = state => state.catalog.colors;
export const selectModels = state => state.catalog.models;
export const selectVersions = state => state.catalog.versions;
export const selectYears = state => state.catalog.years;
