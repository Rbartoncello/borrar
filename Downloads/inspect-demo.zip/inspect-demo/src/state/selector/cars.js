export const selectCar = state => state.cars.car;
export const selectPlate = state => state.cars.plate;
export const selectCarStatus = state => state.cars.status;
