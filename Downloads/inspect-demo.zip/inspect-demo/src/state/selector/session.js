export const selectToken = state => state.session.token;
export const selectSessionStatus = state => state.session.status;
export const selectSite = state => state.session.user?.store?.company?.site;
export const selectCompany = state => state.session.user?.store?.company?.id;
export const selectCurrentUser = state => state.session.user;
