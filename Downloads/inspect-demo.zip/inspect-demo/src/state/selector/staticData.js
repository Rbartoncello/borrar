import {createSelector} from '@reduxjs/toolkit';

export const selectQuestionnaires = state => state.staticData.questionnaires;
export const selectQuestionnaire = state => state.staticData.questionnaire;
export const selectQuestionnaireById = createSelector(
  [selectQuestionnaires, (state, configuration) => configuration],
  (questionnaires, configuration) =>
    questionnaires.find(questionnaire => questionnaire.id === configuration),
);
export const selectQuestionnaireId = createSelector(
  [selectQuestionnaires, (state, configuration) => configuration],
  (questionnaires, configuration) =>
    questionnaires.find(questionnaire => questionnaire.id === configuration)
      ?.id,
);
export const selectQuestionnaireOptions = state => state.staticData.options;
export const selectQuestionnaireChapters = createSelector(
  [selectQuestionnaire],
  questionnaire => questionnaire?.chapters?.filter(chapter => chapter.sections),
);
