export const selectSnackbar = state => state.ui.snackbar;
