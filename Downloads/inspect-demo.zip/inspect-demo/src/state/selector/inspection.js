import {createSelector} from '@reduxjs/toolkit';
import {selectQuestionnaires} from '@/state/selector/staticData';

/**
 * Get percentage of the progress of a given inspection.
 * @param inspection The given inspection from a specific questionnaire.
 * @param questionnaires The questionnaires to find questionnaire and get the progress of chapters.
 * @returns {number} The percentage of the progress of a given inspection.
 */
const getInspectionProgress = (inspection, questionnaires = []) => {
  const questionnaire =
    questionnaires.find(q => q.id === inspection.questionnaireId) || {};
  const chapters =
    questionnaire.chapters?.filter(chapter => chapter.name !== 'data') || [];
  const completedChapters = chapters.filter(
    chapter =>
      !!inspection?.[chapter.name] &&
      chapter.sections.length === Object.keys(inspection[chapter.name]).length,
  );
  return (completedChapters?.length * 100) / chapters.length;
};

const getMyInspections = (inspections, questionnaires = []) =>
  inspections.map(inspection => ({
    ...inspection,
    progress: getInspectionProgress(inspection, questionnaires),
  }));

export const selectInspection = state => state.inspection.inspection;
export const selectInspectionProgress = createSelector(
  [selectInspection, selectQuestionnaires],
  (inspection, questionnaires) =>
    getInspectionProgress(inspection, questionnaires),
);
export const selectInspectionStatus = state => state.inspection.status;
export const selectInspections = state => state.inspection.inspections;
export const selectPendingInspections = createSelector(
  [selectInspections, selectQuestionnaires],
  getMyInspections,
);
export const selectClosedInspections = state =>
  state.inspection.closedInspections;
export const selectCompletedInspections = createSelector(
  [selectClosedInspections, selectQuestionnaires],
  getMyInspections,
);
export const selectNonSyncedInspections = createSelector(
  [selectCompletedInspections],
  inspections => inspections.filter(inspection => !inspection.synced),
);
export const selectClosedInspectionIds = createSelector(
  [selectClosedInspections],
  inspections => inspections.map(inspection => inspection.id),
);
export const selectSyncProgress = createSelector(
  [selectClosedInspections],
  inspections =>
    Math.round(
      (inspections.filter(x => x.synced).length * 100) / inspections.length,
    ),
);
export const selectShowSyncError = state => state.inspection.showSyncError;
