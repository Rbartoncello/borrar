const logger = store => next => action => {
  console.groupCollapsed(`%c ${action.type}`, 'color: #a1a9cb');
  console.log('prev state', store.getState());
  console.info('dispatching', action);
  const result = next(action);
  console.log('next state', store.getState());
  console.groupEnd();
  return result;
};

export default logger;
