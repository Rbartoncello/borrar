import {select} from 'redux-saga/effects';
import {selectToken} from '../selector/session';

function* createService(Service) {
  const token = yield select(selectToken);
  // TODO review token expiration
  return new Service(token);
}

export default createService;
