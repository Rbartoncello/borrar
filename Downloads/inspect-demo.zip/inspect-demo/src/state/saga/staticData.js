import i18next from 'i18next';
import {call, put, select, take, takeLatest} from 'redux-saga/effects';
import {takeLatestAsync} from 'saga-toolkit';
import {fetchBrands, fetchColors} from '../reducer/catalog';
import {fetchCurrentUser, logout} from '../reducer/session';
import {
  fetchQuestionnaire,
  loadResourceLanguage,
  initialize,
  prefetchImages,
  saveQuestionnaire,
} from '../reducer/staticData';
import {selectCompany, selectSite} from '../selector/session';
import {navigationRef} from '@/navigation/navigationRef';
import routes from '@/navigation/routes';
import {StaticDataService} from '@/services';
import createService from '@/state/helper/createService';
import {selectQuestionnaires} from '@/state/selector/staticData';
import {getLanguageFromSite} from '@/util';

export function* handleInitialize() {
  yield put(fetchCurrentUser());
  let site = yield select(selectSite);
  if (!site) {
    // I need site to initialize the app.
    site = (yield take(fetchCurrentUser.fulfilled)).payload.store?.company
      ?.site;
  }
  yield call(i18next.changeLanguage, getLanguageFromSite(site));
  yield put(loadResourceLanguage(site));
  yield put(fetchQuestionnaire());
  yield put(fetchColors());
  yield put(fetchBrands());
}

export function* handleError(err) {
  const route = navigationRef.current.getCurrentRoute()?.name;
  if (err.status === 401 && route !== routes.LOGIN) {
    yield put(logout());
    return;
  }
  throw err;
}

export function* handleLoadResourceLanguage({meta}) {
  try {
    const staticDataService = yield call(createService, StaticDataService);
    yield call(staticDataService.loadResourceLanguage, meta.arg);
  } catch (err) {
    yield call(handleError, err);
  }
}

export function* handleFetchQuestionnaire() {
  try {
    const staticDataService = yield call(createService, StaticDataService);
    const companyId = yield select(selectCompany);
    const questionnaires = yield call(
      staticDataService.fetchQuestionnaires,
      companyId,
    );
    yield put(prefetchImages());
    return questionnaires;
  } catch (err) {
    yield call(handleError, err);
  }
}

export function* handlePrefetchImages() {
  try {
    const {
      payload: {questionnaires},
    } = yield take(fetchQuestionnaire.fulfilled);
    const staticDataService = new StaticDataService();
    yield call(staticDataService.prefetchImages);
    const questionnairesPrefetched = [...questionnaires];
    for (const [index, questionnaire] of questionnairesPrefetched.entries()) {
      const chapters = yield call(
        staticDataService.prefectChapterSvgImages,
        questionnaire.chapters,
      );
      yield call(staticDataService.prefetchQuestionnaireImages, questionnaire);
      questionnairesPrefetched[index] = {
        ...questionnairesPrefetched[index],
        chapters,
      };
    }
    return questionnairesPrefetched;
  } catch (err) {
    yield call(handleError, err);
  }
}

export function* handleSaveQuestionnaire({meta}) {
  try {
    const questionnaires = yield select(selectQuestionnaires);
    return questionnaires.find(questionnaire => questionnaire.id === meta.arg);
  } catch (err) {
    yield call(handleError, err);
  }
}

export default [
  takeLatest(initialize, handleInitialize),
  takeLatestAsync(fetchQuestionnaire.type, handleFetchQuestionnaire),
  takeLatestAsync(loadResourceLanguage.type, handleLoadResourceLanguage),
  takeLatestAsync(prefetchImages.type, handlePrefetchImages),
  takeLatestAsync(saveQuestionnaire.type, handleSaveQuestionnaire),
];
