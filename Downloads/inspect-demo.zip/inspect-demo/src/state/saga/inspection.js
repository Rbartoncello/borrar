import {call, delay, put, select, takeEvery} from 'redux-saga/effects';
import {putAsync, takeLatestAsync} from 'saga-toolkit';
import CreateService from '../helper/createService';
import {cleanCar} from '../reducer/cars';
import {
  closeInspection,
  createInspection,
  createFullInspection,
  editInspection,
  fetchInspections,
  removeInspection,
  removeInspectionSubsection,
  reopenInspections,
  reopenInspection,
  retrySync,
  saveInspectionSection,
  saveInspectionSubsection,
  setSyncedInspection,
  showSyncError,
  syncInspections,
} from '../reducer/inspection';
import {setSnackbar} from '../reducer/ui';
import {selectCar} from '../selector/cars';
import {selectColors} from '../selector/catalog';
import {
  selectClosedInspectionIds,
  selectInspection,
} from '../selector/inspection';
import {selectCurrentUser, selectSite} from '../selector/session';
import {selectQuestionnaires} from '../selector/staticData';
import {SITES} from '@/constants';
import {goBack, navigate, replace, reset} from '@/navigation/navigationRef';
import Routes from '@/navigation/routes';
import {InspectionService, SyncService} from '@/services';
import {saveQuestionnaire} from '@/state/reducer/staticData';
import {handleError} from '@/state/saga/staticData';
import {
  generateFullInspection,
  getDefaultCarValuesBr,
  getDefaultCarValuesAr,
} from '@/util';

export function* handleCreateInspection({meta}) {
  try {
    let car = yield select(selectCar);
    if (car) {
      const colors = yield select(selectColors);
      car = {
        ...meta.arg.car,
        ...car,
        color: colors.find(c => c.id === car.color.id),
      };
    } else {
      car = meta.arg.car;
    }
    const inspectionService = new InspectionService();
    const {id} = yield call(inspectionService.create, car);
    yield put(cleanCar());
    if (meta.arg.startInspection) {
      yield putAsync(editInspection({id, replaceNavigation: true}));
    } else {
      yield put(setSnackbar({message: 'car:carCreated'}));
      yield call(goBack);
    }
  } catch (err) {
    throw err;
  }
}

export function* handleCreateFullInspection() {
  try {
    const [configuration] = yield select(selectQuestionnaires);
    const site = yield select(selectSite);
    const car =
      site === SITES.BR ? getDefaultCarValuesBr() : getDefaultCarValuesAr();
    const defaultValues = generateFullInspection(configuration.chapters);
    const inspectionService = new InspectionService();
    car.configuration = configuration.id;
    const {id} = yield call(inspectionService.create, car, defaultValues);
    yield put(cleanCar());
    yield putAsync(editInspection({id}));
  } catch (err) {
    throw err;
  }
}

export function* handleCloseInspection() {
  try {
    const {id} = yield select(selectInspection);
    const inspectionService = new InspectionService();
    yield call(inspectionService.close, id);
    yield call(reset, 0, Routes.MY_INSPECTIONS);
  } catch (err) {
    throw err;
  }
}

export function* handleSaveInspection({meta}) {
  try {
    const inspectionService = new InspectionService();
    return yield call(inspectionService.save, meta.arg);
  } catch (err) {
    throw err;
  }
}

export function* handleEditInspection({meta}) {
  try {
    const inspectionService = new InspectionService();
    const inspection = yield call(inspectionService.find, meta.arg.id);
    if (!inspection.inspectionStartedAt) {
      inspection.inspectionStartedAt = new Date().toISOString();
      yield call(handleSaveInspection, {meta: {arg: inspection}});
    }
    yield call(
      meta.arg.replaceNavigation ? replace : navigate,
      Routes.INSPECTION_HOME,
    );
    yield put(saveQuestionnaire(inspection.questionnaireId));
    return inspection;
  } catch (err) {
    throw err;
  }
}

export function* handleFetchInspections() {
  try {
    const inspectionService = new InspectionService();
    yield call(inspectionService.removeObsoletePendingInspections);
    return yield call(inspectionService.fetchByState);
  } catch (err) {
    throw err;
  }
}

export function* handleReopenInspection({meta}) {
  try {
    const inspectionService = new InspectionService();
    yield call(inspectionService.reopen, meta.arg);
    yield put(fetchInspections());
  } catch (err) {
    throw err;
  }
}

export function* handleReopenInspections() {
  try {
    const inspectionService = new InspectionService();
    yield call(inspectionService.reopenAll);
    yield put(fetchInspections());
  } catch (err) {
    throw err;
  }
}

export function* handleRemoveInspection({meta}) {
  try {
    const inspectionService = new InspectionService();
    yield call(inspectionService.remove, meta.arg);
    yield put(fetchInspections());
  } catch (err) {
    throw err;
  }
}

export function* handleRemoveSubsection({meta}) {
  try {
    const {id} = yield select(selectInspection);
    const inspectionService = new InspectionService();
    return yield call(
      inspectionService.removeSubsection,
      id,
      meta.arg.chapter,
      meta.arg.sectionName,
      meta.arg.subsections,
      meta.arg.index,
    );
  } catch (err) {
    throw err;
  }
}

export function* handleSaveInspectionSection({meta}) {
  try {
    const {id} = yield select(selectInspection);
    const inspectionService = new InspectionService();
    return yield call(
      inspectionService.saveSection,
      id,
      meta.arg.chapter,
      meta.arg.section,
      meta.arg.values,
    );
  } catch (err) {
    throw err;
  }
}

export function* handleSaveInspectionSubsection({meta}) {
  try {
    const {id} = yield select(selectInspection);
    const inspectionService = new InspectionService();
    const result = yield call(
      inspectionService.saveSubsection,
      id,
      meta.arg.chapter,
      meta.arg.sectionName,
      meta.arg.values,
      meta.arg.subsection,
      meta.arg.index,
    );
    goBack();
    return result;
  } catch (err) {
    throw err;
  }
}

export function* handleSyncInspections() {
  try {
    const ids = yield select(selectClosedInspectionIds);
    const syncService = yield call(CreateService, SyncService);
    const user = yield select(selectCurrentUser);
    for (const id of ids) {
      yield call(syncService.sync, id, user.email);
      yield put(setSyncedInspection({id}));
    }
  } catch (err) {
    yield call(handleError, err);
  }
}

export function* handleRejectedSync() {
  yield delay(500);
  yield put(showSyncError());
}

export function* handleRetrySync() {
  yield putAsync(fetchInspections());
  yield put(syncInspections());
}

export default [
  takeLatestAsync(closeInspection.type, handleCloseInspection),
  takeLatestAsync(createInspection.type, handleCreateInspection),
  takeLatestAsync(createFullInspection.type, handleCreateFullInspection),
  takeLatestAsync(editInspection.type, handleEditInspection),
  takeLatestAsync(fetchInspections.type, handleFetchInspections),
  takeLatestAsync(saveInspectionSection.type, handleSaveInspectionSection),
  takeLatestAsync(
    saveInspectionSubsection.type,
    handleSaveInspectionSubsection,
  ),
  takeLatestAsync(reopenInspections.type, handleReopenInspections),
  takeLatestAsync(reopenInspection.type, handleReopenInspection),
  takeLatestAsync(removeInspection.type, handleRemoveInspection),
  takeLatestAsync(removeInspectionSubsection.type, handleRemoveSubsection),
  takeLatestAsync(syncInspections.type, handleSyncInspections),
  takeEvery(syncInspections.rejected, handleRejectedSync),
  takeEvery(retrySync, handleRetrySync),
];
