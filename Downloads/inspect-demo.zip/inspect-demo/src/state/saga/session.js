import {call, put, takeEvery} from 'redux-saga/effects';
import {takeLatestAsync} from 'saga-toolkit';
import {fetchCurrentUser, login, logout} from '../reducer/session';
import {initialize} from '../reducer/staticData';
import {reset} from '@/navigation/navigationRef';
import Routes from '@/navigation/routes';
import {SessionService, UserService} from '@/services';
import createService from '@/state/helper/createService';
import {handleError} from '@/state/saga/staticData';

export function* handleLogin({meta}) {
  try {
    const sessionService = new SessionService();
    const result = yield call(
      sessionService.login,
      meta.arg.email,
      meta.arg.password,
    );
    // the proxy answers with 2xx to all requests.
    if (!result.jwt_token) {
      throw 'Invalid credentials';
    }
    yield put(login.fulfilled(result.jwt_token));
    yield put(initialize());
    yield call(reset, 0, Routes.MY_INSPECTIONS);
    return result.jwt_token;
  } catch (err) {
    throw err;
  }
}

export function* handleFetchCurrentUser() {
  try {
    const userService = yield call(createService, UserService);
    return yield call(userService.fetchCurrentUser);
  } catch (err) {
    yield call(handleError, err);
  }
}

export function* handleLogout() {
  yield call(reset, 0, Routes.LOGIN);
}

export default [
  takeLatestAsync(login.type, handleLogin),
  takeLatestAsync(fetchCurrentUser.type, handleFetchCurrentUser),
  takeEvery(logout, handleLogout),
];
