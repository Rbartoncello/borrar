import {all} from 'redux-saga/effects';
import cars from './cars';
import catalog from './catalog';
import inspection from './inspection';
import session from './session';
import staticData from './staticData';
import stores from './stores';
import ui from './ui';

function* watchRoot() {
  yield all([
    ...cars,
    ...catalog,
    ...inspection,
    ...session,
    ...staticData,
    ...stores,
    ...ui,
  ]);
}

export default watchRoot;
