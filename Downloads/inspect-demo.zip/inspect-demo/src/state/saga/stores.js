import {call, delay, takeLatest} from 'redux-saga/effects';
import {putAsync, takeLatestAsync} from 'saga-toolkit';
import createService from '../helper/createService';
import {searchStores, startSearchStores} from '../reducer/stores';
import {SEARCH_STORE_MIN_LENGTH} from '@/constants';
import {StoresService} from '@/services';
import {handleError} from '@/state/saga/staticData';

export function* handleSearchStores({meta}) {
  try {
    if (meta.arg.length >= SEARCH_STORE_MIN_LENGTH) {
      const storesService = yield call(createService, StoresService);
      return yield call(storesService.search, meta.arg);
    }
  } catch (err) {
    yield call(handleError, err);
  }
}

export function* handleStartSearchStores({payload}) {
  yield delay(500);
  yield putAsync(searchStores(payload));
}

export default [
  takeLatest(startSearchStores, handleStartSearchStores),
  takeLatestAsync(searchStores.type, handleSearchStores),
];
