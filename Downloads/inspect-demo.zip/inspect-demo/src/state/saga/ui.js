import {delay, put, takeLatest} from 'redux-saga/effects';
import {cleanSnackbar, setSnackbar} from '../reducer/ui';

export function* handleSetSnackbar() {
  yield delay(2000);
  yield put(cleanSnackbar());
}

export default [takeLatest(setSnackbar, handleSetSnackbar)];
