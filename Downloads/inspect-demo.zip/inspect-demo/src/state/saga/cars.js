import {call, delay, put} from 'redux-saga/effects';
import {takeLatestAsync} from 'saga-toolkit';
import createService from '../helper/createService';
import {findCar} from '../reducer/cars';
import {LANGUAGES} from '@/constants';
import {CarsService} from '@/services';
import {setSnackbar} from '@/state/reducer/ui';

export function* handleFindCar({meta}) {
  try {
    yield delay(500);
    const carsService = yield call(createService, CarsService);
    const car = yield call(carsService.find, meta.arg.toUpperCase());
    // The plates from ARG not match with br regex and the snackbar is only to br.
    const isValidPlateBr = carsService.isValidPlate(meta.arg, LANGUAGES.PT);
    if (isValidPlateBr && !car?.lastInspection) {
      yield put(
        setSnackbar({message: car ? 'car:plateFound' : 'car:plateNotFound'}),
      );
    }
    return {car, plate: meta.arg};
  } catch (err) {
    throw err;
  }
}

export default [takeLatestAsync(findCar.type, handleFindCar)];
