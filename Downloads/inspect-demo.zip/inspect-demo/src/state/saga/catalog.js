import {call, select} from 'redux-saga/effects';
import {takeLatestAsync} from 'saga-toolkit';
import createService from '../helper/createService';
import {
  fetchBrands,
  fetchColors,
  fetchModels,
  fetchVersions,
  fetchYears,
} from '../reducer/catalog';
import {selectModels, selectVersions} from '../selector/catalog';
import {CatalogService} from '@/services';
import {getIn} from '@/util';

export function* handleFetchBrands() {
  try {
    const catalogService = yield call(createService, CatalogService);
    return yield call(catalogService.fetchBrands);
  } catch (err) {
    throw err;
  }
}

export function* handleFetchModels({meta}) {
  try {
    const models = yield select(selectModels);
    const isLoaded = !!models[meta.arg];
    if (isLoaded) {
      return;
    }
    const catalogService = yield call(createService, CatalogService);
    return yield call(catalogService.fetchModels, meta.arg);
  } catch (err) {
    throw err;
  }
}

export function* handleFetchColors() {
  try {
    const catalogService = yield call(createService, CatalogService);
    return yield call(catalogService.fetchColors);
  } catch (err) {
    throw err;
  }
}

export function* handleFetchVersions({meta}) {
  try {
    const {brandId, modelId, year} = meta.arg;
    if (!brandId || !modelId || !year) {
      return;
    }
    const versions = yield select(selectVersions);
    const isLoaded = !!getIn(versions, [brandId, modelId, year]);
    if (isLoaded) {
      return;
    }
    const catalogService = yield call(createService, CatalogService);
    return yield call(
      catalogService.fetchVersions,
      meta.arg.brandId,
      meta.arg.modelId,
      meta.arg.year,
    );
  } catch (err) {
    throw err;
  }
}

export function* handleFetchYears({meta}) {
  try {
    const catalogService = yield call(createService, CatalogService);
    const options = yield call(
      catalogService.fetchYears,
      meta.arg.brandId,
      meta.arg.modelId,
    );
    return options.map(({year}) => ({value: year.toString(), label: year}));
  } catch (err) {
    throw err;
  }
}

export default [
  takeLatestAsync(fetchBrands.type, handleFetchBrands),
  takeLatestAsync(fetchModels.type, handleFetchModels),
  takeLatestAsync(fetchColors.type, handleFetchColors),
  takeLatestAsync(fetchVersions.type, handleFetchVersions),
  takeLatestAsync(fetchYears.type, handleFetchYears),
];
