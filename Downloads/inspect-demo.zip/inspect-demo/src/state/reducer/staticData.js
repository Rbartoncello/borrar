import {createSlice} from '@reduxjs/toolkit';
import {createSagaAction} from 'saga-toolkit';
import {
  getDefaultStatus,
  getErrorStatus,
  getStartStatus,
  getSuccessStatus,
} from '../helper/statusStateFactory';

const name = 'staticData';
const initialState = {
  brands: [],
  models: [],
  status: getDefaultStatus(),
  questionnaires: [],
  questionnaire: {},
  options: [],
};

export const loadResourceLanguage = createSagaAction(
  `${name}/loadResourceLanguage`,
);
export const fetchQuestionnaire = createSagaAction(
  `${name}/fetchQuestionnaire`,
);
export const prefetchImages = createSagaAction(`${name}/prefetchImages`);
export const saveQuestionnaire = createSagaAction(`${name}/saveQuestionnaire`);

const staticDataSlice = createSlice({
  name,
  initialState,
  reducers: {
    initialize: () => {},
  },
  extraReducers: builder => {
    builder.addCase(loadResourceLanguage.pending, () => {});
    builder.addCase(loadResourceLanguage.fulfilled, () => {});
    builder.addCase(loadResourceLanguage.rejected, () => {});
    builder.addCase(fetchQuestionnaire.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(fetchQuestionnaire.fulfilled, (state, {payload}) => {
      state.status = getSuccessStatus();
      state.options = payload.options;
      state.questionnaire = payload.questionnaire;
    });
    builder.addCase(fetchQuestionnaire.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
    builder.addCase(prefetchImages.fulfilled, (state, {payload}) => {
      state.questionnaires = payload;
    });
    builder.addCase(saveQuestionnaire.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(saveQuestionnaire.fulfilled, (state, {payload}) => {
      state.status = getSuccessStatus();
      state.questionnaire = payload;
    });
    builder.addCase(saveQuestionnaire.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
  },
});

export const {initialize} = staticDataSlice.actions;
export default staticDataSlice.reducer;
