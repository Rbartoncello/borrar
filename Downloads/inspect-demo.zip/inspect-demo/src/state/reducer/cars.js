import {createSlice} from '@reduxjs/toolkit';
import {createSagaAction} from 'saga-toolkit';
import {
  getDefaultStatus,
  getErrorStatus,
  getStartStatus,
  getSuccessStatus,
} from '../helper/statusStateFactory';

const name = 'cars';
const initialState = {car: null, status: getDefaultStatus(), plate: null};

export const findCar = createSagaAction(`${name}/find`);

const carsSlice = createSlice({
  name,
  initialState,
  reducers: {
    cleanCar: () => initialState,
  },
  extraReducers: builder => {
    builder.addCase(findCar.pending, state => {
      state.status = getStartStatus();
      state.plate = null;
      state.car = null;
    });
    builder.addCase(findCar.fulfilled, (state, {payload}) => {
      state.status = getSuccessStatus();
      state.car = payload.car;
      state.plate = payload.plate;
    });
    builder.addCase(findCar.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
  },
});

export const {cleanCar} = carsSlice.actions;
export default carsSlice.reducer;
