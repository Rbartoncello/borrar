import AsyncStorage from '@react-native-async-storage/async-storage';
import {persistCombineReducers} from 'redux-persist';
import cars from './cars';
import catalog from './catalog';
import inspection from './inspection';
import session from './session';
import staticData from './staticData';
import stores from './stores';
import ui from './ui';

export default persistCombineReducers(
  {
    key: 'root',
    storage: AsyncStorage,
    whitelist: ['session'],
  },
  {
    cars,
    catalog,
    inspection,
    session,
    staticData,
    stores,
    ui,
  },
);
