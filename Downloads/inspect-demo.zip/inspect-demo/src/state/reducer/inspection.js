import {createSlice} from '@reduxjs/toolkit';
import {createSagaAction} from 'saga-toolkit';
import {
  getDefaultStatus,
  getErrorStatus,
  getStartStatus,
  getSuccessStatus,
} from '../helper/statusStateFactory';

const name = 'inspection';
const initialState = {
  inspection: {},
  inspections: [],
  showSyncError: false,
  closedInspections: [],
  status: getDefaultStatus(),
};

export const createInspection = createSagaAction(`${name}/create`);
export const createFullInspection = createSagaAction(`${name}/full/create`);
export const closeInspection = createSagaAction(`${name}/close`);
export const editInspection = createSagaAction(`${name}/edit`);
export const fetchInspections = createSagaAction(`${name}/fetch`);
export const saveInspectionSection = createSagaAction(`${name}/saveSection`);
export const saveInspectionSubsection = createSagaAction(
  `${name}/saveSubsection`,
);
export const removeInspection = createSagaAction(`${name}/remove`);
export const removeInspectionSubsection = createSagaAction(
  `${name}/removeSubsection`,
);
export const reopenInspections = createSagaAction(`${name}/reopenAll`);
export const reopenInspection = createSagaAction(`${name}/reopen`);
export const syncInspections = createSagaAction(`${name}/sync`);

const inspectionSlice = createSlice({
  name,
  initialState,
  reducers: {
    setSyncedInspection: (state, action) => {
      state.closedInspections.find(
        inspection => inspection.id === action.payload.id,
      ).synced = true;
    },
    showSyncError: state => ({...state, showSyncError: true}),
    retrySync: state => ({...state, showSyncError: false}),
  },
  extraReducers: builder => {
    builder.addCase(createInspection.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(createInspection.fulfilled, state => {
      state.status = getSuccessStatus();
    });
    builder.addCase(closeInspection.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(closeInspection.fulfilled, state => {
      state.status = getSuccessStatus();
    });
    builder.addCase(createFullInspection.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(createFullInspection.fulfilled, state => {
      state.status = getSuccessStatus();
    });
    builder.addCase(createFullInspection.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
    builder.addCase(editInspection.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(editInspection.fulfilled, (state, {payload}) => {
      state.inspection = payload;
      state.status = getSuccessStatus();
    });
    builder.addCase(editInspection.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
    builder.addCase(fetchInspections.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(fetchInspections.fulfilled, (state, {payload}) => {
      state.inspections = payload.pending;
      state.closedInspections = payload.closed;
      state.status = getSuccessStatus();
    });
    builder.addCase(fetchInspections.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
    builder.addCase(saveInspectionSection.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(saveInspectionSection.fulfilled, (state, {payload}) => {
      state.inspection = payload;
      state.status = getSuccessStatus();
    });
    builder.addCase(saveInspectionSection.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
    builder.addCase(reopenInspections.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(reopenInspections.fulfilled, state => {
      state.status = getSuccessStatus();
    });
    builder.addCase(reopenInspections.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
    builder.addCase(reopenInspection.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(reopenInspection.fulfilled, state => {
      state.status = getSuccessStatus();
    });
    builder.addCase(reopenInspection.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
    builder.addCase(removeInspection.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(removeInspection.fulfilled, state => {
      state.status = getSuccessStatus();
    });
    builder.addCase(removeInspection.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
    builder.addCase(removeInspectionSubsection.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(
      removeInspectionSubsection.fulfilled,
      (state, {payload}) => {
        state.inspection = payload;
        state.status = getSuccessStatus();
      },
    );
    builder.addCase(removeInspectionSubsection.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
    builder.addCase(saveInspectionSubsection.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(saveInspectionSubsection.fulfilled, (state, {payload}) => {
      state.inspection = payload;
      state.status = getSuccessStatus();
    });
    builder.addCase(saveInspectionSubsection.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
    builder.addCase(syncInspections.pending, state => {
      state.status = getStartStatus();
      state.showSyncError = false;
    });
    builder.addCase(syncInspections.fulfilled, state => {
      state.status = getSuccessStatus();
    });
    builder.addCase(syncInspections.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
  },
});

export const {setSyncedInspection, showSyncError, retrySync} =
  inspectionSlice.actions;
export default inspectionSlice.reducer;
