import {createSlice} from '@reduxjs/toolkit';
import {createSagaAction} from 'saga-toolkit';
import {
  getDefaultStatus,
  getErrorStatus,
  getStartStatus,
  getSuccessStatus,
} from '../helper/statusStateFactory';

const name = 'session';
const initialState = {
  token: null,
  userId: null,
  user: {},
  status: getDefaultStatus(),
};

export const login = createSagaAction(`${name}/login`);
export const fetchCurrentUser = createSagaAction(`${name}/fetchCurrentUser`);

const sessionSlice = createSlice({
  name,
  initialState,
  reducers: {
    logout: state => ({...state, ...initialState}),
    loginRequiest,
    loginSuccess,
  },
  extraReducers: builder => {
    builder.addCase(login.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(login.fulfilled, (state, {payload}) => {
      state.token = payload;
      state.status = getSuccessStatus();
    });
    builder.addCase(login.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
    builder.addCase(fetchCurrentUser.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(fetchCurrentUser.fulfilled, (state, {payload}) => {
      state.user = payload;
      state.status = getSuccessStatus();
    });
    builder.addCase(fetchCurrentUser.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
  },
});

export const {logout} = sessionSlice.actions;
export default sessionSlice.reducer;
