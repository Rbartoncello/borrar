import {createSlice} from '@reduxjs/toolkit';
import {createSagaAction} from 'saga-toolkit';
import {
  getDefaultStatus,
  getErrorStatus,
  getStartStatus,
  getSuccessStatus,
} from '../helper/statusStateFactory';
import {getIn} from '@/util';

const initialColors = [];

const name = 'catalog';
const initialState = {
  brands: [],
  years: [],
  models: {},
  versions: {},
  colors: initialColors,
  status: getDefaultStatus(),
};

export const fetchBrands = createSagaAction(`${name}/fetchBrands`);
export const fetchModels = createSagaAction(`${name}/fetchModels`);
export const fetchColors = createSagaAction(`${name}/fetchColors`);
export const fetchVersions = createSagaAction(`${name}/fetchVersions`);
export const fetchYears = createSagaAction(`${name}/fetchYears`);

const carsSlice = createSlice({
  name,
  initialState,
  reducers: {},
  extraReducers: builder => {
    builder.addCase(fetchBrands.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(fetchBrands.fulfilled, (state, {payload}) => {
      state.status = getSuccessStatus();
      state.brands = payload;
    });
    builder.addCase(fetchBrands.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
    builder.addCase(fetchModels.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(fetchModels.fulfilled, (state, {meta, payload}) => {
      state.models = payload
        ? {...state.models, [meta.arg]: payload}
        : state.models;
      state.status = getSuccessStatus();
    });
    builder.addCase(fetchModels.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
    builder.addCase(fetchColors.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(fetchColors.fulfilled, (state, {payload}) => {
      state.colors = payload.length ? payload : initialColors;
      state.status = getSuccessStatus();
    });
    builder.addCase(fetchColors.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
    builder.addCase(fetchYears.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(fetchYears.fulfilled, (state, {payload}) => {
      state.years = payload;
      state.status = getSuccessStatus();
    });
    builder.addCase(fetchYears.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
    builder.addCase(fetchVersions.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(fetchVersions.fulfilled, (state, {meta, payload}) => {
      state.versions = payload
        ? {
            ...state.versions,
            [meta.arg.brandId]: {
              ...getIn(state.versions, [meta.arg.brandId]),
              [meta.arg.modelId]: {
                ...getIn(state.versions, [meta.arg.brandId, meta.arg.modelId]),
                [meta.arg.year]: [...payload],
              },
            },
          }
        : state.versions;
      state.status = getSuccessStatus();
    });
    builder.addCase(fetchVersions.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
  },
});

export default carsSlice.reducer;
