import {createSlice} from '@reduxjs/toolkit';

const name = 'ui';
const initialState = {snackbar: null};

const storesSlice = createSlice({
  name,
  initialState,
  reducers: {
    cleanSnackbar: state => ({...state, snackbar: null}),
    setSnackbar: (state, action) => ({
      ...state,
      snackbar: action.payload.message,
    }),
  },
});

export const {setSnackbar, cleanSnackbar} = storesSlice.actions;
export default storesSlice.reducer;
