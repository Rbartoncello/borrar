import {createSlice} from '@reduxjs/toolkit';
import {createSagaAction} from 'saga-toolkit';
import {
  getDefaultStatus,
  getErrorStatus,
  getStartStatus,
  getSuccessStatus,
} from '../helper/statusStateFactory';

const name = 'stores';
const initialState = {stores: [], status: getDefaultStatus()};

export const searchStores = createSagaAction(`${name}/search`);

const storesSlice = createSlice({
  name,
  initialState,
  reducers: {
    startSearchStores: state => ({
      ...state,
      status: getStartStatus(),
    }),
  },
  extraReducers: builder => {
    builder.addCase(searchStores.pending, state => {
      state.status = getStartStatus();
    });
    builder.addCase(searchStores.fulfilled, (state, {payload}) => {
      state.stores = payload || [];
      state.status = getSuccessStatus();
    });
    builder.addCase(searchStores.rejected, (state, {error}) => {
      state.status = getErrorStatus(error);
    });
  },
});

export const {startSearchStores} = storesSlice.actions;
export default storesSlice.reducer;
