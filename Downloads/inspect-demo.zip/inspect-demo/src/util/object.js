/**
 * Set a value at a specific path in an object.
 * If a portion of the path doesn't exist, it's created.
 * @param object {object} The object to modify.
 * @param path {Array<string>} The path of the property to set.
 * @param value {*} The value to set.
 */
export const setIn = (object, path, value) => {
  const last = path.pop();
  const parent = path.reduce((obj, key) => {
    if (!obj[key]) {
      obj[key] = {};
    }
    return obj[key];
  }, object);
  parent[last] = value;
};

/**
 * Get a value at a specific path in an object.
 * If a portion of the path doesn't exist, returns undefined.
 * @param object {object} The object to query.
 * @param path {Array<string>} The path of the property to get.
 * @returns {*} The value at the path or undefined.
 */
export const getIn = (object, path) =>
  path.reduce(
    (obj, key) =>
      obj && obj[key] !== null && obj[key] !== undefined ? obj[key] : undefined,
    object,
  );

/**
 * Merge a value at a specific path in an object.
 * Supports append an element to an array and objects.
 * @param object {object} The object to modify.
 * @param path {Array<string>} The path of the property to merge in.
 * @param value {*} The value to set.
 * @returns {*} The value at the path.
 */
export const mergeIn = (object, path, value) => {
  const last = path.pop();
  const parent = path.reduce((obj, key) => {
    if (!obj[key]) {
      obj[key] = {};
    }
    return obj[key];
  }, object);
  parent[last] = Array.isArray(parent[last])
    ? [...parent[last], value]
    : {...parent[last], ...value};
  return parent[last];
};
