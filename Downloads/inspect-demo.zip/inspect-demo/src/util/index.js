import DocumentPicker, {types} from 'react-native-document-picker';
import {LANGUAGES, SITES} from '@/constants';

export * from './object';
export * from './string';

/**
 * Get language for a given site.
 * @param site {string} The user's site.
 * @returns {string} Returns the language code..
 */
export const getLanguageFromSite = site => {
  switch (site) {
    case SITES.BR:
      return LANGUAGES.PT;
    case SITES.AR:
      return LANGUAGES.ES;
    default:
      throw new Error(`Unknown language for site '${site}'`);
  }
};

const generateSectionsValues = (sections, isDocuments) =>
  sections?.reduce(
    (acc, section) => ({
      ...acc,
      [section.name]: isDocuments ? {hasDocuments: false} : {hasFlaws: false},
    }),
    {},
  ) || {};

export const generateFullInspection = chapters => {
  const inspection = {};
  chapters.forEach(chapter => {
    const isDocuments = chapter.name === 'documents';
    inspection[chapter.name] = generateSectionsValues(
      chapter.sections,
      isDocuments,
    );
  });
  return inspection;
};

const getRandomLetters = str =>
  (Math.random() + 1).toString(36).substring(2, str + 2);

export const getDefaultCarValuesAr = () => ({
  plate: getRandomLetters(6),
  assembly: '2011',
  brand: Object.freeze({id: 'BRND-01GAVSSYFGJZJ036DQA7R9BR7G', name: 'FIAT'}),
  color: Object.freeze({
    id: 'COL-01GA3WND9B40RJT0KT7DSJ5VVZ',
    name: 'Cinza',
    hex: '#D0CECF',
  }),
  model: Object.freeze({id: 'MODL-01GAVSZ8ZXAZDEQQET7KWEM49Z', name: 'UNO'}),
  store: Object.freeze({
    id: 1489,
    name: 'Fiat Enzo',
    address:
      'R. Joaquim Murtinho, 2350 - Itanhangá Park, Campo Grande - MS, 79003-020, Brasil',
    dealerId: 146,
  }),
  version: Object.freeze({
    id: 'VRSN-01GAVSZEWAM4F80DP02ZC36541',
    name: '1.4 WAY 8V FLEX 4P MANUAL',
  }),
  year: '2011',
});

export const getDefaultCarValuesBr = () => ({
  plate: getRandomLetters(7),
  assembly: '2011',
  brand: Object.freeze({id: 'BRND-01GAVSSYFGJZJ036DQA7R9BR7G', name: 'FIAT'}),
  color: {
    id: 'COL-01GA3WND9B40RJT0KT7DSJ5VVZ',
    name: 'Cinza',
    hex: '#D0CECF',
  },
  model: Object.freeze({id: 'MODL-01GAVSZ8ZXAZDEQQET7KWEM49Z', name: 'UNO'}),
  store: Object.freeze({
    id: 1489,
    name: 'Fiat Enzo',
    address:
      'R. Joaquim Murtinho, 2350 - Itanhangá Park, Campo Grande - MS, 79003-020, Brasil',
    dealerId: 146,
  }),
  version: Object.freeze({
    id: 'VRSN-01GAVSZEWAM4F80DP02ZC36541',
    name: '1.4 WAY 8V FLEX 4P MANUAL',
  }),
  year: '2011',
});

export const isEmpty = data => {
  if (Array.isArray(data) && data.length === 0) {
    return true;
  }
  return typeof data === 'object' ? Object.keys(data).length === 0 : !data;
};

export const openDocumentPicker = async onChange => {
  try {
    const {fileCopyUri, name} = await DocumentPicker.pickSingle({
      type: [types.pdf],
      presentationStyle: 'fullScreen',
      copyTo: 'cachesDirectory',
    });
    onChange(fileCopyUri, name);
  } catch (err) {
    if (DocumentPicker.isCancel(err)) {
      console.error('Canceled from single doc picker');
    } else {
      console.error('Unknown Error: ' + JSON.stringify(err));
    }
  }
};
