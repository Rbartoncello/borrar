const TEMPLATE_REGEX = /\$\{\s*(\w+)\s*}/g;

/**
 * Interpolates a string with the given data.
 * @param {string} str The template string to fill with values.
 * @param {Object} values The values to replace the template variables with.
 * @return {string} The interpolated string with the given values.
 */
export const template = (str, values) =>
  str.replace(TEMPLATE_REGEX, (match, key) => values[key]);

export const isString = str => typeof str === 'string';
