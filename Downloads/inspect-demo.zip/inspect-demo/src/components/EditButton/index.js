import {useTheme} from '@rneui/themed';
import PropTypes from 'prop-types';
import styles from './styles';
import {Button} from '@/components';
import {PenToSquare} from '@/icons';

const EditButton = ({title, onPress}) => {
  const {theme} = useTheme();
  return (
    <Button
      type="clear"
      containerStyle={styles.container}
      buttonStyle={styles.button}
      onPress={onPress}>
      <PenToSquare
        height={20}
        width={20}
        color={theme.colors.blue800}
        style={title ? styles.iconWithTitle : styles.icon}
      />
      {title}
    </Button>
  );
};

EditButton.propTypes = {
  title: PropTypes.string,
  onPress: PropTypes.func,
};

export default EditButton;
