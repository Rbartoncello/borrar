import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  container: {marginHorizontal: 0},
  button: {paddingVertical: 0},
  icon: {marginRight: -10},
  iconWithTitle: {marginRight: 4},
});

export default styles;
