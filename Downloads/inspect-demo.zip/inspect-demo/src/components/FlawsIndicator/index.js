import {View} from 'react-native';
import createStyles from './styles';
import {Text} from '@/components';
import {useThemedStyles} from '@/hooks';

const FlawsIndicator = ({flaws, containerStyle}) => {
  const [styles] = useThemedStyles(createStyles);
  return (
    !!flaws && (
      <View style={[styles.container, containerStyle]}>
        <Text bold style={styles.content}>
          {flaws}
        </Text>
      </View>
    )
  );
};

export default FlawsIndicator;
