import {Platform} from 'react-native';

const createStyles = theme => ({
  container: {
    height: 24,
    minWidth: 24,
    paddingHorizontal: 8,
    alignItems: 'center',
    borderRadius: 12,
    backgroundColor: theme.colors.brandPrimary,
  },
  content: {
    marginTop: Platform.select({
      android: () => -2,
      default: () => 0,
    })(),
    color: theme.colors.white,
  },
});

export default createStyles;
