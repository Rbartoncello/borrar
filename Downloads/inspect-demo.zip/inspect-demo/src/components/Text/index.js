import {Text as BaseText} from '@rneui/base';
import {Text as ThemedText, useTheme, withTheme} from '@rneui/themed';
import PropTypes from 'prop-types';

const BoldText = withTheme(BaseText, 'BoldText');

const getFontSize = (size, theme) => {
  let fontSize;
  switch (size) {
    case 'sm':
      fontSize = theme.typography.small.fontSize;
      break;
    case 'lg':
      fontSize = theme.typography.large.fontSize;
      break;
    case 'xl':
      fontSize = theme.typography.extraLarge.fontSize;
      break;
    case 'md':
    default:
      fontSize = theme.typography.regular.fontSize;
  }
  return {fontSize};
};

const Text = ({bold = false, size, style, ...props}) => {
  const {theme} = useTheme();
  return bold ? (
    <BoldText style={[getFontSize(size, theme), style]} {...props} />
  ) : (
    <ThemedText style={[getFontSize(size, theme), style]} {...props} />
  );
};

Text.propTypes = {
  ...BaseText?.propTypes,
  bold: PropTypes.bool,
  size: PropTypes.oneOf(['sm', 'md', 'lg', 'xl']),
};

export default Text;
