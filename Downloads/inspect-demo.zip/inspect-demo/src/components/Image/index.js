import {useTranslation} from 'react-i18next';
import {ImageBackground, Text, View} from 'react-native';
import createStyles from './styles';
import {useThemedStyles, useSourceUri} from '@/hooks';
import {Camera, CircleCheckStroke, CircleExclamationStroke} from '@/icons';

const renderStatusIcon = status => {
  switch (status) {
    case 'warning':
      return <CircleExclamationStroke width={40} height={40} />;
    case 'done':
      return <CircleCheckStroke width={40} height={40} />;
    default:
      return undefined;
  }
};

const renderCameraIcon = (variant, styles, theme) =>
  variant === 'clear' ? (
    <Camera height={30} width={30} color={theme.colors.blue800} />
  ) : (
    <View style={styles.cameraIcon}>
      <Camera />
    </View>
  );

const Image = ({
  image,
  status,
  placeholder,
  variant,
  textIcon,
  hideIcon,
  icon: Icon,
}) => {
  const {t} = useTranslation();
  const [styles, theme] = useThemedStyles(createStyles);
  const source = useSourceUri(image || placeholder);
  return (
    <View style={[image ? styles.container : styles.dashedContainer]}>
      <ImageBackground
        source={source}
        resizeMode="cover"
        imageStyle={styles.image}
        style={[image ? styles.containerImage : styles.containerPlaceholder]}>
        <View style={styles.statusIcon}>
          {image && renderStatusIcon(status, styles)}
        </View>
        {!hideIcon && !Icon && (
          <View style={styles.containerIconCamera}>
            {renderCameraIcon(variant, styles, theme)}
            {textIcon && <Text style={styles.textIcon}>{t(textIcon)}</Text>}
          </View>
        )}
        {!hideIcon && Icon && (
          <View style={styles.containerIconCamera}>
            <Icon color={theme.colors.blue800} height={30} width={30} />
            {textIcon && <Text style={styles.textIcon}>{t(textIcon)}</Text>}
          </View>
        )}
      </ImageBackground>
    </View>
  );
};

export default Image;
