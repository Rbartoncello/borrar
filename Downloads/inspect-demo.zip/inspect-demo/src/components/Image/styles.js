const createStyles = theme => ({
  container: {
    height: 130,
    width: 146,
    padding: 2,
    borderRadius: 10,
  },
  dashedContainer: {
    height: 130,
    width: 146,
    borderWidth: 2.3,
    borderStyle: 'dashed',
    borderColor: theme.colors.grey600,
    borderRadius: 10,
  },
  image: {
    borderRadius: 7,
    width: '107%',
    height: '108%',
    left: -5,
    top: -5,
  },
  containerImage: {flex: 1, margin: 4},
  containerPlaceholder: {flex: 1, margin: 8},
  statusIcon: {
    position: 'absolute',
    top: -10,
    left: -10,
  },
  containerIconCamera: {
    flex: 1,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cameraIcon: {
    height: 50,
    width: 50,
    alignItems: 'center',
    justifyContent: 'center',
    opacity: 0.7,
    borderRadius: 50,
    backgroundColor: theme.colors.blue800,
  },
  textIcon: {
    color: theme.colors.blue800,
    fontSize: theme.typography.small.fontSize,
    fontWeight: 'bold',
  },
});
export default createStyles;
