import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import {createValueStyles} from './styles';
import {Text} from '@/components';
import {useThemedStyles} from '@/hooks';

const SelectValue = ({value, option, placeholder, labelKey}) => {
  const [styles] = useThemedStyles(createValueStyles);
  const {t} = useTranslation();
  const text = t(option?.[labelKey] || value || placeholder);
  return option?.icon ? (
    <View style={styles.container}>
      <View style={styles.icon}>{option.icon}</View>
      <Text>{text}</Text>
    </View>
  ) : (
    <Text>{text}</Text>
  );
};

export default SelectValue;
