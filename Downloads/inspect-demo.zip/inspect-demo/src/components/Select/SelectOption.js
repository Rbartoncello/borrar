import {ListItem} from '@rneui/themed';
import {useTranslation} from 'react-i18next';
import {optionStyles} from './styles';

const SelectOption = ({option, labelKey, onPress}) => {
  const {t} = useTranslation();
  return (
    <ListItem containerStyle={optionStyles.container} onPress={onPress}>
      {option.icon}
      <ListItem.Content>
        <ListItem.Title>{t(option[labelKey])}</ListItem.Title>
      </ListItem.Content>
    </ListItem>
  );
};

export default SelectOption;
