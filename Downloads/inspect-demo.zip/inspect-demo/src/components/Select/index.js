import PropTypes from 'prop-types';
import {useEffect, useState} from 'react';
import {useTranslation} from 'react-i18next';
import {Pressable, View} from 'react-native';
import SelectOption from './SelectOption';
import SelectValue from './SelectValue';
import {BottomSheet, Text} from '@/components';
import SelectLabel from '@/components/Select/SelectLabel';
import {createStyles} from '@/components/Select/styles';
import {useBoolean, useThemedStyles} from '@/hooks';
import {ChevronDown} from '@/icons';

const Select = ({
  disabled,
  errorMessage,
  isRequired,
  label,
  labelKey,
  onChange,
  options,
  placeholder,
  style,
  value,
  valueKey,
  labelStyle,
}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createStyles);
  const [showMenu, setShowMenu] = useBoolean();
  const [currentValue, setCurrentValue] = useState(value);
  const handleChange = val => {
    setShowMenu.off();
    setCurrentValue(val);
    onChange(val);
  };
  useEffect(() => {
    setCurrentValue(
      options.find(option => option[valueKey] === value)?.[valueKey],
    );
  }, [value, valueKey, options]);
  const selectedOption = currentValue
    ? options.find(option => option[valueKey] === currentValue)
    : null;
  return (
    <View style={[styles.container, style]}>
      <BottomSheet
        visible={showMenu}
        title={t(placeholder)}
        onClose={setShowMenu.off}>
        {options.map(option => (
          <SelectOption
            key={option[valueKey]}
            option={option}
            labelKey={labelKey}
            onPress={() => handleChange(option[valueKey])}
          />
        ))}
      </BottomSheet>
      {label && (
        <SelectLabel text={label} isRequired={isRequired} style={labelStyle} />
      )}
      <Pressable
        onPress={!disabled ? setShowMenu.on : undefined}
        style={[styles.input, disabled ? styles.disabledInput : undefined]}>
        <SelectValue
          value={currentValue}
          option={selectedOption}
          placeholder={placeholder}
          labelKey={labelKey}
        />
        <ChevronDown />
      </Pressable>
      <Text style={styles.error}>{t(errorMessage)}</Text>
    </View>
  );
};

Select.propTypes = {
  label: PropTypes.string,
  options: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
      value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    }).isRequired,
  ),
  onChange: PropTypes.func.isRequired,
  placeholder: PropTypes.string,
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  isRequired: PropTypes.bool,
  disabled: PropTypes.bool,
  valueKey: PropTypes.string,
  errorMessage: PropTypes.string,
};

Select.defaultProps = {
  placeholder: 'placeholderSelect',
  isRequired: false,
  disabled: false,
  labelKey: 'label',
  valueKey: 'value',
};

export default Select;
