import {StyleSheet} from 'react-native';

export const createStyles = theme => ({
  container: {width: '100%'},
  input: {
    minHeight: 50,
    paddingHorizontal: theme.spacing.paddingHorizontal * 1.5,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 12,
    borderColor: theme.colors.grey600,
  },
  disabledInput: {backgroundColor: theme.colors.grey400},
  error: {color: theme.colors.red800},
});

export const optionStyles = StyleSheet.create({
  container: {borderBottomLeftRadius: 12, borderBottomRightRadius: 12},
});

export const createLabelStyles = theme => ({
  container: {
    flexDirection: 'row',
  },
  label: {
    marginVertical: 2,
    marginRight: 2,
    paddingHorizontal: theme.spacing.paddingHorizontal,
    fontSize: 14,
    fontWeight: 'bold',
    color: theme.colors.grey800,
  },
});

export const createValueStyles = theme => ({
  container: {flexDirection: 'row'},
  icon: {marginRight: theme.spacing.marginHorizontal},
});
