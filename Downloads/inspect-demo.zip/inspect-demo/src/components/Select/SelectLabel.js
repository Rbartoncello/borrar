import PropTypes from 'prop-types';
import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import Text from '../Text';
import {createLabelStyles} from './styles';
import {useThemedStyles} from '@/hooks';

const SelectLabel = ({text, isRequired, style}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createLabelStyles);
  return (
    <View style={styles.container}>
      <Text numberOfLines={1} style={[styles.label, style]}>
        {t(text)}
      </Text>
      {isRequired && <Text size="lg">*</Text>}
    </View>
  );
};

SelectLabel.propTypes = {
  text: PropTypes.string.isRequired,
  isRequired: PropTypes.bool.isRequired,
};

export default SelectLabel;
