const createStyles = theme => ({
  container: {
    width: '100%',
    flexDirection: 'row',
    paddingHorizontal: theme.spacing.paddingHorizontal,
    paddingTop: theme.spacing.paddingHorizontal / 2,
  },
  label: {
    marginBottom: theme.spacing.marginVertical,
    fontWeight: 'bold',
    fontSize: theme.typography.regular.fontSize,
  },
  caption: {fontSize: theme.typography.regular.fontSize},
  captionWithLabel: {paddingLeft: theme.spacing.paddingHorizontal / 2},
});

export default createStyles;
