import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import Text from '../Text';
import createStyles from './styles';
import {useThemedStyles} from '@/hooks';

const Label = ({label, caption}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createStyles);
  return (
    <View style={styles.container}>
      {label && <Text style={styles.label}>{t(label)}</Text>}
      {caption && (
        <Text
          style={[styles.caption, label ? styles.captionWithLabel : undefined]}>
          {t(caption)}
        </Text>
      )}
    </View>
  );
};

export default Label;
