import {View, Pressable} from 'react-native';
import {rowStyles} from './styles';
import {Text} from '@/components';
import {useEvent, useThemedStyles} from '@/hooks';
import {LocationDot} from '@/icons';

const StoreRow = ({store, onSelect}) => {
  const [styles, theme] = useThemedStyles(rowStyles);
  const handlePress = useEvent(() => onSelect(store));
  return (
    <Pressable style={styles.container} onPress={handlePress}>
      <LocationDot style={styles.icon} color={theme.colors.grey700} />
      <View style={styles.content}>
        <Text style={styles.name} numberOfLines={1}>
          {store.name}
        </Text>
        <Text size="sm" style={styles.address} numberOfLines={1}>
          {store.address}
        </Text>
      </View>
    </Pressable>
  );
};

export default StoreRow;
