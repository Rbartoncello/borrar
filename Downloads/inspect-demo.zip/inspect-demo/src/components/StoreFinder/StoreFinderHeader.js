import {Fragment, useState} from 'react';
import {useTranslation} from 'react-i18next';
import {Pressable, View} from 'react-native';
import TextInput from '../TextInput';
import headerStyles from './styles';
import {useEvent, useThemedStyles} from '@/hooks';
import {ArrowLeft, Times} from '@/icons';

const StoreFinderHeader = ({onPressBack, onSearch}) => {
  const {t} = useTranslation();
  const [styles, theme] = useThemedStyles(headerStyles);
  const [value, setValue] = useState();
  const handleChange = useEvent(val => {
    setValue(val);
    if (value !== undefined) {
      onSearch(val);
    }
  });
  const handleClear = useEvent(() => setValue(''));
  return (
    <Fragment>
      <TextInput
        autoFocus
        keyboardType="default"
        returnKeyType="search"
        textContentType="location"
        placeholder={t('inspection:storePlaceholder')}
        value={value}
        onChange={handleChange}
        containerStyle={styles.container}
        labelStyle={styles.label}
        inputContainerStyle={styles.inputContainer}
        leftIcon={
          <Pressable onPress={onPressBack}>
            <ArrowLeft color={theme.colors.grey1000} />
          </Pressable>
        }
        rightIcon={
          value?.length > 0 && (
            <Pressable onPress={handleClear}>
              <Times color={theme.colors.grey1000} />
            </Pressable>
          )
        }
      />
      <View style={styles.separator} />
    </Fragment>
  );
};

export default StoreFinderHeader;
