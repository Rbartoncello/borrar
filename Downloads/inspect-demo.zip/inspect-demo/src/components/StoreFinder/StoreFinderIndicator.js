import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import Text from '../Text';
import StoreFinderIcon from './StoreFinderIcon';
import {emptyListStyles} from './styles';
import {useThemedStyles} from '@/hooks';

const getMessage = hasSearchValue =>
  hasSearchValue ? 'noStoresFound' : 'storesPlaceholder';

const StoreFinderIndicator = ({status, hasSearchValue}) => {
  const {t} = useTranslation('car');
  const [styles] = useThemedStyles(emptyListStyles);
  return (
    <View style={styles.container}>
      <StoreFinderIcon status={status} hasSearchValue={hasSearchValue} />
      <Text size="sm" style={styles.label}>
        {!status.isFetching && t(getMessage(hasSearchValue))}
      </Text>
    </View>
  );
};

export default StoreFinderIndicator;
