export const rowStyles = theme => ({
  container: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginHorizontal: theme.spacing.baseUnit + 2,
    marginVertical: 9,
  },
  icon: {marginRight: theme.spacing.baseUnit - 4, marginTop: 2},
  content: {flex: 1},
  name: {color: theme.colors.grey1000, marginBottom: 4},
  address: {color: theme.colors.grey800},
});

export const emptyListStyles = theme => ({
  container: {alignItems: 'center', marginTop: 36},
  label: {color: theme.colors.grey600, marginTop: 16},
});

const headerStyles = theme => ({
  container: {height: 50, backgroundColor: theme.colors.white},
  inputContainer: {borderWidth: 0, borderBottomWidth: 0, borderRadius: 0},
  separator: {height: 1, backgroundColor: theme.colors.grey200},
  label: {color: theme.colors.grey1000},
});

export default headerStyles;
