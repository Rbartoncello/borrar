import {useTheme} from '@rneui/themed';
import {ActivityIndicator} from 'react-native';
import {LocationCircleTimes, LocationDot} from '@/icons';

const StoreFinderIcon = ({status, hasSearchValue}) => {
  const {theme} = useTheme();
  if (status.isFetching) {
    return (
      <ActivityIndicator
        animating
        size="large"
        color={theme.colors.brandPrimary}
      />
    );
  }
  return hasSearchValue ? (
    <LocationCircleTimes color={theme.colors.grey600} />
  ) : (
    <LocationDot height={88} width={88} color={theme.colors.grey600} />
  );
};

export default StoreFinderIcon;
