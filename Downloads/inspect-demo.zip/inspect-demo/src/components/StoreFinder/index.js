import {useState} from 'react';
import {FlatList} from 'react-native';
import {connect} from 'react-redux';
import StoreFinderHeader from './StoreFinderHeader';
import StoreFinderIndicator from './StoreFinderIndicator';
import StoreRow from './StoreRow';
import {Container} from '@/components';
import {SEARCH_STORE_MIN_LENGTH} from '@/constants';
import {useAlertStatusError} from '@/hooks';
import {startSearchStores} from '@/state/reducer/stores';
import {selectStores, selectStoreStatus} from '@/state/selector/stores';

const renderItem = (store, onSelect) => (
  <StoreRow store={store} onSelect={onSelect} />
);

const StoreFinder = ({stores, status, onClose, onSelect, onSearchStores}) => {
  const [hasSearchValue, setHasSearchValue] = useState(false);
  const handleSearch = value => {
    setHasSearchValue(value.length >= SEARCH_STORE_MIN_LENGTH);
    onSearchStores(value);
  };
  useAlertStatusError(status);
  return (
    <Container>
      <StoreFinderHeader onPressBack={onClose} onSearch={handleSearch} />
      <FlatList
        ListHeaderComponent={
          (!stores.length || status.isFetching) && (
            <StoreFinderIndicator
              status={status}
              hasSearchValue={hasSearchValue}
            />
          )
        }
        data={stores}
        renderItem={({item}) => renderItem(item, onSelect)}
        keyExtractor={item => item.id}
      />
    </Container>
  );
};

export default connect(
  state => ({stores: selectStores(state), status: selectStoreStatus(state)}),
  {onSearchStores: startSearchStores},
)(StoreFinder);
