const getContainerImage = theme => ({
  height: 100,
  width: 100,
  marginBottom: theme.spacing.marginVertical * 2,
  paddingTop: theme.spacing.marginVertical * 0.8,
  alignItems: 'center',
  borderRadius: 50,
  borderColor: theme.colors.grey500,
});

const createStyles = theme => ({
  container: {
    minWidth: 158,
    marginHorizontal: theme.spacing.marginHorizontal,
    marginVertical: theme.spacing.marginVertical,
    paddingHorizontal: theme.spacing.paddingHorizontal,
    paddingVertical: theme.spacing.paddingVertical * 2,
    alignItems: 'center',
    backgroundColor: theme.colors.white,
    borderRadius: 12,
  },
  withBorder: {
    ...getContainerImage(theme),
    borderWidth: 1,
    transform: [{rotate: '30deg'}],
  },
  arc: {
    ...getContainerImage(theme),
    top: -8,
  },
  containerImage: {
    ...getContainerImage(theme),
    top: -8,
    transform: [{rotate: '-30deg'}],
  },
  inProgressContainerImage: {
    top: -10,
  },
  completedContainerImage: {
    top: -10,
    left: 1,
  },
  quarterProgress: {
    top: -9,
    borderTopWidth: 0,
    borderRightWidth: 0,
    borderBottomWidth: 4,
    borderLeftWidth: 0,
    borderColor: theme.colors.yellow300,
  },
  halfProgress: {
    top: -9,
    borderTopWidth: 0,
    borderRightWidth: 0,
    borderBottomWidth: 4,
    borderLeftWidth: 4,
    borderColor: theme.colors.yellow300,
  },
  twoQuartersProgress: {
    top: -9,
    borderTopWidth: 4,
    borderRightWidth: 0,
    borderBottomWidth: 4,
    borderLeftWidth: 4,
    borderColor: theme.colors.yellow300,
  },
  completedProgress: {
    top: -9,
    borderWidth: 4,
    borderColor: theme.colors.green500,
  },
  progress: {
    top: -15,
    marginBottom: -5,
    backgroundColor: theme.colors.grey600,
    paddingVertical: theme.spacing.paddingVertical / 2,
    paddingHorizontal: theme.spacing.paddingHorizontal,
    borderRadius: 8,
    borderWidth: 3,
    borderColor: theme.colors.white,
  },
  activeProgress: {
    backgroundColor: theme.colors.green300,
  },
  inProgress: {
    backgroundColor: theme.colors.yellow200,
  },
  text: {
    color: theme.colors.white,
    fontSize: 14,
    fontWeight: '700',
  },
  activeText: {
    color: theme.colors.green900,
  },
  inProgressText: {
    color: theme.colors.yellow900,
  },
  title: {
    textAlign: 'center',
    fontWeight: 'bold',
    paddingBottom: theme.spacing.marginVertical,
    fontSize: theme.typography.regular.fontSize,
  },
  flaws: {
    position: 'absolute',
    top: 6,
    right: 5,
  },
});

export default createStyles;
