import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import {SvgXml} from 'react-native-svg';
import Button from '../Button';
import FlawsIndicator from '../FlawsIndicator';
import Text from '../Text';
import createStyles from './styles';
import {EditButton} from '@/components';
import {
  useChapterFlawsCount,
  useChapterProgress,
  useEvent,
  useNavigation,
  useThemedStyles,
} from '@/hooks';
import Routes from '@/navigation/routes';

const getQuarters = progress => Math.ceil(progress / 25);

const getProgressArcStyle = (styles, partial, isCompleted) => {
  if (isCompleted) {
    return styles.completedProgress;
  }
  switch (partial) {
    case 0:
      return undefined;
    case 1:
      return styles.quarterProgress;
    case 2:
      return styles.halfProgress;
    default:
      return styles.twoQuartersProgress;
  }
};

const getProgressStyle = (
  baseStyle,
  inProgressStyle,
  completedStyle,
  isInProgress,
  isCompleted,
) => [
  baseStyle,
  isInProgress ? inProgressStyle : undefined,
  isCompleted ? completedStyle : undefined,
];

const InspectionCard = ({chapter, values}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createStyles);
  const {navigate} = useNavigation();
  const progress = useChapterProgress(chapter.sections, values);
  const flaws = useChapterFlawsCount(chapter, values);
  const handlePress = useEvent(() =>
    navigate(Routes.INSPECTION_EDITOR, {chapter: chapter.name}),
  );
  const partial = getQuarters(progress);
  const isCompleted = progress === 100;
  const isInProgress = !isCompleted && partial > 0;
  return (
    <View style={styles.container}>
      <FlawsIndicator flaws={flaws} containerStyle={styles.flaws} />
      <View style={styles.withBorder}>
        <View
          style={[
            styles.arc,
            getProgressArcStyle(styles, partial, isCompleted),
          ]}>
          <View
            style={getProgressStyle(
              styles.containerImage,
              styles.inProgressContainerImage,
              styles.completedContainerImage,
              partial > 2,
              isCompleted,
            )}>
            <SvgXml height={80} width={80} xml={chapter.image} />
            <View
              style={getProgressStyle(
                styles.progress,
                styles.inProgress,
                styles.activeProgress,
                isInProgress,
                isCompleted,
              )}>
              <Text
                style={getProgressStyle(
                  styles.text,
                  styles.inProgressText,
                  styles.activeText,
                  isInProgress,
                  isCompleted,
                )}>
                {`${progress}%`}
              </Text>
            </View>
          </View>
        </View>
      </View>
      <Text style={styles.title}>{t(chapter.label)}</Text>
      {chapter.sections &&
        (isCompleted ? (
          <EditButton title={t('edit')} onPress={handlePress} />
        ) : (
          <Button
            type="outline"
            onPress={handlePress}
            disabled={!chapter.sections}
            title="complete"
          />
        ))}
    </View>
  );
};

export default InspectionCard;
