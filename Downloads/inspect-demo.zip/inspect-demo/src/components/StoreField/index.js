import PropTypes from 'prop-types';
import {Fragment, useState} from 'react';
import {useTranslation} from 'react-i18next';
import {Pressable} from 'react-native';
import createStyles from './styles';
import {Modal, StoreFinder, Text} from '@/components';
import {getFieldError} from '@/forms';
import {useBoolean, useEvent, useThemedStyles} from '@/hooks';
import {LocationDot} from '@/icons';

const StoreField = ({
  defaultValue,
  form,
  field,
  placeholder = 'inspection:storePlaceholder',
  onChange = () => {},
}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createStyles);
  const [valueSelected, setValueSelected] = useState(defaultValue);
  const [visible, setVisible] = useBoolean(false);
  const handleSelect = useEvent(store => {
    setVisible.off();
    setValueSelected(store);
    form.setFieldValue(field.name, store.id);
    onChange(store);
  });
  return (
    <Fragment>
      <Modal visible={visible}>
        <StoreFinder onClose={setVisible.off} onSelect={handleSelect} />
      </Modal>
      <Pressable style={styles.container} onPress={setVisible.on}>
        <LocationDot />
        <Text
          style={valueSelected ? styles.value : styles.placeholder}
          numberOfLines={1}>
          {valueSelected?.name || t(placeholder)}
        </Text>
      </Pressable>
      <Text style={styles.error}>{t(getFieldError(form, field))}</Text>
    </Fragment>
  );
};

StoreField.propTypes = {
  defaultValue: PropTypes.string,
  placeholder: PropTypes.string,
  onChangeStore: PropTypes.func,
};

export default StoreField;
