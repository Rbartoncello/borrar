const createStyles = theme => ({
  container: {
    height: 50,
    paddingHorizontal: theme.spacing.baseUnit,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderRadius: 12,
    borderColor: theme.colors.grey600,
  },
  placeholder: {
    flex: 1,
    marginHorizontal: theme.spacing.baseUnit - 4,
    color: theme.colors.grey700,
  },
  value: {
    flex: 1,
    marginHorizontal: theme.spacing.baseUnit - 4,
    color: theme.colors.grey1000,
  },
  error: {color: theme.colors.red800},
});

export default createStyles;
