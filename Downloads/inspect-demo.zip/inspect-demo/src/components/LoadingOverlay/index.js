import {Overlay, useTheme} from '@rneui/themed';
import {ActivityIndicator} from 'react-native';

const LoadingOverlay = () => {
  const {theme} = useTheme();
  return (
    <Overlay isVisible>
      <ActivityIndicator
        animating
        size="large"
        color={theme.colors.brandPrimary}
      />
    </Overlay>
  );
};

export default LoadingOverlay;
