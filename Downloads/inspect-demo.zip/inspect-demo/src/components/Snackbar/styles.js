export const createStyles = theme => ({
  container: {
    position: 'absolute',
    right: theme.spacing.baseUnit,
    bottom: theme.spacing.baseUnit - 6,
    left: theme.spacing.baseUnit,
    paddingLeft: theme.spacing.baseUnit,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.grey900,
    borderRadius: 8,
    zIndex: 1000,
  },
  content: {flex: 1, flexDirection: 'row'},
  icon: {marginRight: theme.spacing.baseUnit - 4},
  message: {color: theme.colors.white},
});
