import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import {connect} from 'react-redux';
import Button from '../Button';
import Text from '../Text';
import {createStyles} from '@/components/Snackbar/styles';
import {useThemedStyles} from '@/hooks';
import {CircleCheckStroke} from '@/icons';
import {cleanSnackbar} from '@/state/reducer/ui';
import {selectSnackbar} from '@/state/selector/ui';

const Snackbar = ({message, onDismiss}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createStyles);
  return (
    message && (
      <View style={styles.container}>
        <View style={styles.content}>
          <CircleCheckStroke height={20} width={20} style={styles.icon} />
          <Text numberOfLines={2} style={styles.message}>
            {t(message)}
          </Text>
        </View>
        <Button type="clear" title="hide" onPress={() => onDismiss()} />
      </View>
    )
  );
};
export default connect(state => ({message: selectSnackbar(state)}), {
  onDismiss: cleanSnackbar,
})(Snackbar);
