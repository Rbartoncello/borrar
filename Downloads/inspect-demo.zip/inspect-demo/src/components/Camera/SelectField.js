import {useMemo, Fragment} from 'react';
import {useTranslation} from 'react-i18next';
import {Pressable} from 'react-native';
import createStyles from './styles';
import {Text} from '@/components';
import getFieldError from '@/forms/fields/getFieldError';
import {useThemedStyles, useEvent} from '@/hooks';

const SelectField = ({field, form, options}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createStyles);
  const handleSelect = useEvent(option =>
    form.setFieldValue(field.name, option.value),
  );
  const errorMessage = useMemo(() => getFieldError(form, field), [field, form]);
  return (
    <Fragment>
      {options.map(option => (
        <Pressable
          style={
            field.value === option.value
              ? styles.fieldSelectedContainer
              : styles.fieldContainer
          }
          key={option.value}
          onPress={() => handleSelect(option)}>
          <Text
            numberOfLines={1}
            style={
              field.value === option.value
                ? styles.labelSelectedField
                : styles.labelField
            }>
            {t(option.label)}
          </Text>
        </Pressable>
      ))}
      <Text size="sm" style={styles.errorSelect}>
        {t(errorMessage)}
      </Text>
    </Fragment>
  );
};

export default SelectField;
