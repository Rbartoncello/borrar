import {Field, Formik} from 'formik';
import {useMemo} from 'react';
import {useTranslation} from 'react-i18next';
import {View, ScrollView} from 'react-native';
import SelectField from './SelectField';
import createStyles from './styles';
import {Container, Button, Modal, Text} from '@/components';
import ComponentsRegistry from '@/forms/DynamicForm/componentsRegistry';
import {buildFormSchema} from '@/forms/validations';
import {useThemedStyles} from '@/hooks';
import {Times} from '@/icons';

export const CompleteInfoModal = ({
  valueLoaded,
  visible,
  onClose,
  currentSection,
  onSubmit,
}) => (
  <Modal
    transparent
    visible={visible}
    onRequestClose={onClose}
    onDismiss={onClose}
    presentationStyle="overFullScreen">
    <CompleteInfo
      valueLoaded={valueLoaded}
      onClose={onClose}
      currentSection={currentSection}
      onSubmit={onSubmit}
    />
  </Modal>
);

const components = [['select', SelectField]];

const CompleteInfo = ({currentSection, valueLoaded, onClose, onSubmit}) => {
  const [styles, theme] = useThemedStyles(createStyles);
  const {t} = useTranslation();
  const handleSubmit = value => onSubmit(value);
  const componentsKey = currentSection.type.split('With')[1].toLowerCase();
  const componentsRegistry = useMemo(
    () => new ComponentsRegistry(components),
    [],
  );
  const validationSchema = useMemo(
    () =>
      buildFormSchema({
        fields: [
          {
            ...currentSection,
            type: componentsKey,
            name: currentSection.name[1],
          },
        ],
      }),
    [componentsKey, currentSection],
  );
  return (
    <Container style={styles.transparentContainer}>
      <View style={styles.containerInfo}>
        <View style={styles.header}>
          <View style={styles.titleHeaderContainer}>
            <Text numberOfLines={1} style={styles.title} bold>
              {t(currentSection.label)}
            </Text>
          </View>
          <Button type="clear" onPress={onClose}>
            <Times color={theme.colors.white} />
          </Button>
        </View>
        <ScrollView>
          <Formik
            validationSchema={validationSchema}
            initialValues={{...valueLoaded?.values}}
            onSubmit={handleSubmit}>
            {props => (
              <View style={styles.formikContainer}>
                <Field
                  name={currentSection.name[1]}
                  config={{
                    ...currentSection,
                    placeholder: '',
                    name: currentSection.name[1],
                    inputContainerStyle: {
                      backgroundColor: theme.colors.white,
                      marginTop: theme.spacing.baseUnit,
                    },
                    label: undefined,
                  }}
                  component={componentsRegistry.get(componentsKey)}
                  options={currentSection.options}
                  {...props}
                />
                <Button
                  disabled={props.isSubmitting || !props.isValid}
                  onPress={props.submitForm}
                  type="clear"
                  title={t('accept')}
                />
              </View>
            )}
          </Formik>
        </ScrollView>
      </View>
    </Container>
  );
};

export default CompleteInfo;
