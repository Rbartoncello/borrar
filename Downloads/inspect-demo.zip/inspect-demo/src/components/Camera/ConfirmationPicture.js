import {View, Image} from 'react-native';
import {CompleteInfoModal} from './CompleteInfo';
import createStyles from './styles';
import {Container, Button, Modal} from '@/components';
import {useThemedStyles, useSourceUri, useEvent, useBoolean} from '@/hooks';
import {CircleCheckStroke, Times} from '@/icons';

export const ConfirmationPictureModal = ({
  valueLoaded,
  picture,
  visible,
  onClose,
  onConfirm,
  currentSection,
}) => (
  <Modal
    visible={visible}
    presentationStyle="fullScreen"
    onRequestClose={onClose}
    onDismiss={onClose}>
    <ConfirmationPicture
      picture={picture}
      onClose={onClose}
      valueLoaded={valueLoaded}
      onConfirm={onConfirm}
      currentSection={currentSection}
    />
  </Modal>
);

const ConfirmationPicture = ({
  picture,
  currentSection,
  valueLoaded,
  onClose,
  onConfirm,
}) => {
  const [styles, theme] = useThemedStyles(createStyles);
  const [visibleModal, setVisibleModal] = useBoolean(false);
  const source = useSourceUri(`file:${picture.path}`);
  const handleAccept = useEvent(() => {
    if (currentSection.type === 'photo') {
      onConfirm();
    } else {
      setVisibleModal.on();
    }
  });
  const handleSubmit = useEvent(values => {
    setVisibleModal.off();
    onConfirm(values);
  });
  return (
    <Container style={styles.container}>
      <CompleteInfoModal
        valueLoaded={valueLoaded}
        visible={visibleModal}
        currentSection={currentSection}
        onClose={setVisibleModal.off}
        onSubmit={handleSubmit}
      />
      <View style={styles.body}>
        <View style={styles.leftSide} />
        <View style={styles.centerSide}>
          <Image style={styles.image} source={source} resizeMode="contain" />
        </View>
        <View style={styles.rightSide}>
          <Button type="clear" onPress={handleAccept}>
            <CircleCheckStroke height={80} width={80} />
          </Button>
          <Button type="clear" onPress={onClose}>
            <Times color={theme.colors.white} height={40} width={40} />
          </Button>
        </View>
      </View>
    </Container>
  );
};

export default ConfirmationPicture;
