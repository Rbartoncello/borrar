import CameraView from './CameraView';
import Modal from '@/components/Modal';

const Camera = ({visible, photoFields, onClose}) =>
  visible && (
    <Modal visible onRequestClose={onClose} onDismiss={onClose}>
      <CameraView photoFields={photoFields} onClose={onClose} />
    </Modal>
  );

export default Camera;
