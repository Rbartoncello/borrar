import {useEffect, useState} from 'react';
import {Camera, useCameraDevices} from 'react-native-vision-camera';
import {useEvent} from '@/hooks';

const useCameraManager = () => {
  const devices = useCameraDevices();
  const [status, setStatus] = useState();
  useEffect(() => {
    ckeckPermission();
  }, [ckeckPermission]);
  const ckeckPermission = useEvent(async () => {
    const cameraPermission = await Camera.getCameraPermissionStatus();
    setStatus(cameraPermission);
    if (cameraPermission !== 'authorized') {
      requestPermission();
    }
  });
  const requestPermission = useEvent(async () => {
    const newCameraPermission = await Camera.requestCameraPermission();
    setStatus(newCameraPermission);
  });
  return {status, device: devices.back};
};
export default useCameraManager;
