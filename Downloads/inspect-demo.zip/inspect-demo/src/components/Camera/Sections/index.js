import {useEffect, useState, useRef} from 'react';
import {FlatList, View} from 'react-native';
import Row from './Row';
import {createStyles} from './styles';
import {useThemedStyles, useEvent} from '@/hooks';

const separator = styles => <View style={styles.separator} />;
const isComplete = (values, item) => {
  const value = values.find(v => v.label === item.label);
  if (item.approvedOptions && value) {
    return item.approvedOptions.includes(
      value.values[Object.keys(value.values)[1]],
    );
  }
  return value;
};

const renderRow =
  (onSelect, key, values) =>
  ({item}) =>
    (
      <Row
        item={item}
        isComplete={isComplete(values, item)}
        onSelect={onSelect}
        isSelect={item.label === key?.label}
      />
    );

const Sections = ({fields, value, values, onSelect}) => {
  const ref = useRef();
  const [styles] = useThemedStyles(createStyles);
  const [currentSelected, setCurrentSelected] = useState();
  const handleSelected = useEvent(item => {
    setCurrentSelected(item);
    onSelect(item);
  });
  useEffect(() => {
    setCurrentSelected(value);
    ref.current?.scrollToIndex({
      index: fields.findIndex(i => i.name === value.name),
      animated: true,
    });
  }, [fields, value]);
  return (
    <FlatList
      ref={ref}
      style={styles.list}
      ItemSeparatorComponent={() => separator(styles)}
      horizontal
      data={fields}
      renderItem={renderRow(handleSelected, currentSelected, values)}
      keyExtractor={item => item.name}
    />
  );
};

export default Sections;
