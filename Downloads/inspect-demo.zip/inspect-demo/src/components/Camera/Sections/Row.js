import {useTranslation} from 'react-i18next';
import {Pressable} from 'react-native';
import {createRowStyles} from './styles';
import {Text} from '@/components';
import {useThemedStyles, useEvent} from '@/hooks';
import {CircleExclamationStroke, CircleCheckStroke} from '@/icons';

const renderIcon = isComplete => {
  if (isComplete !== undefined) {
    if (isComplete) {
      return <CircleCheckStroke />;
    } else {
      return <CircleExclamationStroke />;
    }
  }
};

const Row = ({item, onSelect, isComplete, isSelect}) => {
  const [styles] = useThemedStyles(createRowStyles);
  const {t} = useTranslation();
  const handleSelect = useEvent(() => onSelect(item));
  return (
    <Pressable
      style={isSelect ? styles.containerSelected : styles.container}
      onPress={handleSelect}>
      <Text bold style={isSelect ? styles.labelSelected : styles.label}>
        {t(item.label)}
      </Text>
      {renderIcon(isComplete)}
    </Pressable>
  );
};

export default Row;
