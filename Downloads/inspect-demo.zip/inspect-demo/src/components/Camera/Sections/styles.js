export const createStyles = theme => ({
  list: {
    position: 'absolute',
    marginTop: theme.spacing.baseUnit + 4,
    marginHorizontal: theme.spacing.baseUnit - 4,
  },
  separator: {width: theme.spacing.baseUnit - 4},
});

export const createRowStyles = theme => ({
  container: {
    borderRadius: 64,
    backgroundColor: theme.colors.grey1000,
    borderWidth: 1,
    borderColor: theme.colors.grey1000,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    paddingRight: 8,
  },
  containerSelected: {
    borderRadius: 64,
    backgroundColor: theme.colors.white,
    borderWidth: 1,
    borderColor: theme.colors.grey800,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    paddingRight: 8,
  },
  label: {
    color: theme.colors.white,
    paddingHorizontal: theme.spacing.baseUnit + 4,
    paddingVertical: 6,
  },
  labelSelected: {
    color: theme.colors.grey1000,
    paddingHorizontal: theme.spacing.baseUnit + 4,
    paddingVertical: 6,
  },
});

export default createStyles;
