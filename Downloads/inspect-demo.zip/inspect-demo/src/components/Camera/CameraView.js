import {useEffect, useRef, useState, useMemo} from 'react';
import {useTranslation} from 'react-i18next';
import {Image, ActivityIndicator, View, Pressable} from 'react-native';
import Orientation from 'react-native-orientation-locker';
import {Camera as CameraVision} from 'react-native-vision-camera';
import {ConfirmationPictureModal} from './ConfirmationPicture';
import Sections from './Sections';
import createStyles from './styles';
import useCameraManager from './useCameraManager';
import {Container, Text, Button} from '@/components';
import {useThemedStyles, useBoolean, useEvent, useSourceUri} from '@/hooks';
import {Times} from '@/icons';

const getValue = values =>
  values.map(v => v.values).reduce((accum, field) => ({...accum, ...field}));

const CameraView = ({photoFields, onClose}) => {
  const camera = useRef();
  const {t} = useTranslation();
  const [currentSelected, setCurrentSelected] = useState(photoFields[0]);
  const [styles, theme] = useThemedStyles(createStyles);
  const {device, status} = useCameraManager();
  const [currentPicture, setCurrentPicture] = useState();
  const [showModalConfirm, setShowModalConfirm] = useBoolean(false);
  const [values, setValues] = useState([]);

  const valueLoaded = useMemo(
    () => values.find(v => v.label === currentSelected?.label),
    [currentSelected, values],
  );
  const pictureLoaded = useSourceUri(
    Array.isArray(currentSelected?.name)
      ? valueLoaded?.values?.[currentSelected.name[0]]
      : valueLoaded?.values?.[currentSelected.name],
  );

  useEffect(() => {
    Orientation.lockToLandscape();
    return () => {
      Orientation.lockToPortrait();
    };
  }, []);

  useEffect(() => {
    if (values.length === photoFields.length) {
      const valuesToSend = getValue(values);
      onClose(valuesToSend, true);
    }
  }, [photoFields, values, onClose]);

  const takePhoto = async () => {
    const photo = await camera.current.takePhoto({flash: 'off'});
    setCurrentPicture(photo);
    setShowModalConfirm.on();
  };

  const getValues = imperfection =>
    imperfection
      ? {
          [`${currentSelected.name[0]}`]: `file:${currentPicture.path}`,
          ...imperfection,
        }
      : {
          [`${currentSelected.name}`]: `file:${currentPicture.path}`,
        };

  const handleConfirm = useEvent(imperfection => {
    const ifExistsValue = values.find(v => v.label === currentSelected.label);
    if (ifExistsValue) {
      ifExistsValue.values = getValues(imperfection);
    } else {
      values.push({
        label: currentSelected.label,
        values: getValues(imperfection),
      });
    }
    setValues([...values]);
    if (values.length !== photoFields.length) {
      const currentIndex = photoFields.findIndex(
        i => i.name === currentSelected.name,
      );
      if (photoFields.length !== currentIndex + 1) {
        setCurrentSelected(photoFields[currentIndex + 1]);
      }
    }
    setShowModalConfirm.off();
  });

  if (device == null) {
    return <ActivityIndicator />;
  }
  return (
    <Container style={styles.container}>
      <ConfirmationPictureModal
        valueLoaded={valueLoaded}
        visible={showModalConfirm}
        picture={currentPicture}
        onClose={setShowModalConfirm.off}
        onConfirm={handleConfirm}
        currentSection={currentSelected}
      />
      {status !== 'authorized' && (
        <Text style={styles.noAccess}>{t('withOutCameraAcess')}</Text>
      )}
      {device && status === 'authorized' && (
        <View style={styles.body}>
          <View style={styles.leftSide}>
            <Button
              type="clear"
              onPress={() =>
                onClose(values.length > 0 ? getValue(values) : undefined, false)
              }
              icon={<Times color={theme.colors.white} />}
            />
          </View>
          <View style={styles.centerSide}>
            <CameraVision
              style={styles.camera}
              ref={camera}
              device={device}
              photo
              isActive
            />
            <Sections
              value={currentSelected}
              fields={photoFields}
              onSelect={setCurrentSelected}
              values={values}
            />
          </View>
          <View style={styles.rightSide}>
            <Pressable
              disabled={!currentSelected}
              onPress={takePhoto}
              style={({pressed}) => [
                styles.pressable,
                {opacity: pressed ? 0.5 : 1},
              ]}>
              <View style={styles.middleCircle} />
            </Pressable>
            <Image
              style={styles.imageLoaded}
              resizeMode="center"
              source={pictureLoaded}
            />
          </View>
        </View>
      )}
    </Container>
  );
};

export default CameraView;
