import {View} from 'react-native';
import styles from './styles';

const Container = ({style, children, ...props}) => (
  <View style={[styles.container, style]} {...props}>
    {children}
  </View>
);

export default Container;
