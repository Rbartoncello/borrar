import {useTheme} from '@rneui/themed';
import {FlatList, SectionList, RefreshControl} from 'react-native';

const renderRefreshControl = (onRefresh, refreshing, color) => (
  <RefreshControl
    onRefresh={onRefresh}
    refreshing={refreshing}
    tintColor={color}
    colors={[color]}
  />
);

const List = ({
  onRefresh,
  refreshing = false,
  isSectionList = false,
  ...props
}) => {
  const {theme} = useTheme();
  return isSectionList ? (
    <SectionList
      {...props}
      refreshControl={renderRefreshControl(
        onRefresh,
        refreshing,
        theme.colors.brandPrimary,
      )}
    />
  ) : (
    <FlatList
      {...props}
      refreshControl={renderRefreshControl(
        onRefresh,
        refreshing,
        theme.colors.brandPrimary,
      )}
    />
  );
};

export default List;
