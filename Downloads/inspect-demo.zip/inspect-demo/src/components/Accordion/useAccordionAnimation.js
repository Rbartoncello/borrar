import {useRef, useMemo} from 'react';
import {Animated} from 'react-native';
import {useEvent} from '@/hooks';

const useAccordionAnimation = (
  heightFixedSection,
  heightCollapsibleSection,
  animationDuration,
) => {
  const rotationAnim = useRef(new Animated.Value(0)).current;
  const heightAnim = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const rotation = useMemo(
    () =>
      rotationAnim.interpolate({
        inputRange: [0, 1],
        outputRange: ['0deg', '180deg'],
      }),
    [rotationAnim],
  );
  const heightRange = useMemo(
    () =>
      heightAnim.interpolate({
        inputRange: [0, 1],
        outputRange: [
          heightFixedSection,
          heightCollapsibleSection + heightFixedSection,
        ],
      }),
    [heightAnim, heightCollapsibleSection, heightFixedSection],
  );

  const animateHeight = useEvent(toValue =>
    Animated.timing(heightAnim, {
      toValue,
      animationDuration,
      useNativeDriver: false,
    }).start(),
  );

  const animateRotation = useEvent(toValue =>
    Animated.timing(rotationAnim, {
      toValue,
      duration: animationDuration / 2,
      useNativeDriver: true,
    }).start(),
  );

  const animateFade = useEvent(toValue =>
    Animated.timing(fadeAnim, {
      toValue,
      duration: animationDuration / 2,
      useNativeDriver: false,
    }).start(),
  );

  const expand = useEvent(() => {
    animateHeight(1);
    animateRotation(1);
    setTimeout(() => {
      animateFade(1);
    }, animationDuration);
  });

  const collapse = useEvent(() => {
    animateHeight(0);
    animateRotation(0);
    animateFade(0);
  });

  return {
    heightAnim,
    fadeAnim,
    rotation,
    heightRange,
    expand,
    collapse,
  };
};

export default useAccordionAnimation;
