import PropTypes from 'prop-types';
import {useState} from 'react';
import {Animated, Pressable, View} from 'react-native';
import createAccordionStyles from './styles';
import useAccordionAnimation from './useAccordionAnimation';
import {useEvent, useThemedStyles} from '@/hooks';
import {ChevronDown} from '@/icons';

const Accordion = ({
  animationDuration = 400,
  header,
  footer = false,
  marginHorizontal,
  marginVertical,
  children,
  icon,
}) => {
  const [styles] = useThemedStyles(createAccordionStyles);
  const [heightHeaderSection, setHeightHeaderSection] = useState(0);
  const [heightContentSection, setCollapsibleSection] = useState(0);
  const {heightAnim, fadeAnim, rotation, heightRange, expand, collapse} =
    useAccordionAnimation(
      heightHeaderSection,
      heightContentSection,
      animationDuration,
    );
  const handleLayoutHeader = useEvent(event =>
    setHeightHeaderSection(event.nativeEvent.layout.height),
  );
  const handleLayoutContent = useEvent(event =>
    setCollapsibleSection(event.nativeEvent.layout.height),
  );
  const handlePressHeader = useEvent(() =>
    heightAnim._value === 0 ? expand() : collapse(),
  );
  return (
    <View
      style={[
        styles.container,
        {
          marginHorizontal: marginHorizontal,
          marginVertical: marginVertical,
        },
      ]}>
      <Animated.View
        style={{
          height: heightRange,
        }}>
        <Pressable onPress={handlePressHeader}>
          <View style={styles.header} onLayout={handleLayoutHeader}>
            <View style={styles.flex}>{header}</View>
            <Animated.View
              style={[styles.icon, {transform: [{rotate: rotation}]}]}>
              {icon || <ChevronDown />}
            </Animated.View>
          </View>
        </Pressable>
        <Animated.View style={{opacity: fadeAnim}}>
          <View onLayout={handleLayoutContent}>{children}</View>
        </Animated.View>
      </Animated.View>
      {footer && <View style={styles.flex}>{footer}</View>}
    </View>
  );
};

Accordion.propTypes = {
  animationDuration: PropTypes.number,
  header: PropTypes.element,
  footer: PropTypes.oneOfType([PropTypes.element, PropTypes.bool]),
  collapsibleSection: PropTypes.arrayOf(PropTypes.element),
  icon: PropTypes.element,
  marginHorizontal: PropTypes.number,
  marginVertical: PropTypes.number,
};

export default Accordion;
