const createAccordionStyles = theme => ({
  container: {
    backgroundColor: theme.colors.white,
    borderRadius: 8,
    minHeight: 70,
  },
  icon: {marginHorizontal: theme.spacing.paddingHorizontal},
  header: {flexDirection: 'row', alignItems: 'center', minHeight: 70},
  flex: {flex: 1},
});

export default createAccordionStyles;
