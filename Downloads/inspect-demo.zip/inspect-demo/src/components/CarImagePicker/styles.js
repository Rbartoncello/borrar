const createStyles = theme => ({
  container: {
    width: '48%',
    minHeight: 222,
    marginVertical: theme.spacing.marginVertical,
    paddingHorizontal: theme.spacing.paddingHorizontal,
    borderRadius: 12,
    backgroundColor: theme.colors.white,
  },
  label: {
    paddingVertical: theme.spacing.paddingVertical,
    textAlign: 'center',
  },
  picker: {
    paddingVertical: theme.spacing.paddingVertical,
    alignSelf: 'center',
  },
  select: {paddingBottom: theme.spacing.paddingVertical},
});

export default createStyles;
