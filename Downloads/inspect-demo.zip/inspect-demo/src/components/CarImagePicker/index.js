import {useState, useEffect} from 'react';
import {useTranslation} from 'react-i18next';
import {TouchableOpacity, View} from 'react-native';
import CheckIndicator from '../CheckIndicator';
import Image from '../Image';
import Text from '../Text';
import createStyles from './styles';
import {useImagePicker, useThemedStyles} from '@/hooks';

const CarImagePicker = ({
  label,
  value = null,
  status,
  placeholder,
  onChange,
  children,
  hidden = false,
}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createStyles);
  const [image, setImage] = useState();
  const handlePress = useImagePicker(path => {
    setImage(path);
    onChange({hidden, value: path});
  });
  useEffect(() => {
    setImage(value);
  }, [value]);
  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={handlePress} style={styles.picker}>
        {!!image && <CheckIndicator />}
        <Image {...{status, image, placeholder}} />
      </TouchableOpacity>
      <Text bold style={styles.label}>
        {t(label)}
      </Text>
      {children}
    </View>
  );
};

export default CarImagePicker;
