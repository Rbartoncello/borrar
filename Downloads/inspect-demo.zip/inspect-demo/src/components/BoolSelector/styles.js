const createStyles = theme => ({
  container: {
    width: '100%',
    marginBottom: theme.spacing.marginVertical * 2,
    flexDirection: 'row',
  },
  containerTitle: {flexDirection: 'row', alignItems: 'center'},
  buttonLeftContainer: {
    height: 56,
    flex: 1,
    marginRight: theme.spacing.marginVertical,
    borderRadius: 20,
  },
  buttonRightContainer: {
    flex: 1,
    marginLeft: theme.spacing.marginVertical,
    borderRadius: 20,
  },
  button: {
    height: 56,
    paddingVertical: theme.spacing.paddingVertical * 1.3,
    backgroundColor: theme.colors.white,
    borderColor: theme.colors.grey500,
    borderWidth: 1,
    borderStyle: 'solid',
    borderRadius: 64,
  },
  title: {
    marginRight: theme.spacing.marginHorizontal * 1.2,
    color: theme.colors.blue800,
  },
  activeButton: {
    height: 56,
    paddingVertical: theme.spacing.paddingVertical * 1.3,
    backgroundColor: theme.colors.brandPrimary,
    borderRadius: 64,
  },
  activeTitle: {
    marginRight: theme.spacing.marginHorizontal * 1.2,
    color: theme.colors.white,
  },
});

export default createStyles;
