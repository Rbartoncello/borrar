import {Button} from '@rneui/base';
import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import Text from '../Text';
import createStyles from './styles';
import {useEvent, useThemedStyles} from '@/hooks';
import {Check, Pencil} from '@/icons';

const BoolSelector = ({value, onChange, label, caption}) => {
  const {t} = useTranslation();
  const [styles, theme] = useThemedStyles(createStyles);
  const handlePressTrue = useEvent(() => onChange(true));
  const handlePressFalse = useEvent(() => onChange(false));
  return (
    <View style={styles.container}>
      <Button
        containerStyle={styles.buttonLeftContainer}
        buttonStyle={value === true ? styles.activeButton : styles.button}
        onPress={handlePressTrue}>
        <View style={styles.containerTitle}>
          <Text bold style={value === true ? styles.activeTitle : styles.title}>
            {t(label || 'observed')}
          </Text>
          <Pencil
            color={value === true ? theme.colors.white : theme.colors.blue800}
          />
        </View>
      </Button>
      <Button
        containerStyle={styles.buttonRightContainer}
        buttonStyle={value === false ? styles.activeButton : styles.button}
        onPress={handlePressFalse}>
        <View style={styles.containerTitle}>
          <Text
            bold
            style={value === false ? styles.activeTitle : styles.title}>
            {t(caption || 'approved')}
          </Text>
          <Check
            width={25}
            height={26}
            color={value === false ? theme.colors.white : theme.colors.blue800}
          />
        </View>
      </Button>
    </View>
  );
};

export default BoolSelector;
