import {useRef, useState} from 'react';
import {useTranslation} from 'react-i18next';
import {Pressable, View} from 'react-native';
import CheckIndicator from '../CheckIndicator';
import ConfirmDialog from '../ConfirmDialog';
import Image from '../Image';
import Label from '../Label';
import Text from '../Text';
import createStyles from './styles';
import {useBoolean, useEvent, useImagePicker, useThemedStyles} from '@/hooks';
import {TrashCan} from '@/icons';

const ImagesPicker = ({
  limit = 4,
  label,
  caption,
  onChange,
  defaultValue = [],
  hidden = false,
}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createStyles);
  const editingImage = useRef(-1);
  const deletingImage = useRef(-1);
  const [images, setImages] = useState(defaultValue);
  const [showModal, setShowModal] = useBoolean(false);
  const handleChange = imagePaths => {
    setImages(imagePaths);
    onChange({hidden, values: imagePaths});
  };
  const openPicker = useImagePicker(path => {
    if (editingImage.current === -1) {
      handleChange([...(Array.isArray(images) ? images : images.values), path]);
      return;
    }
    const imagePaths = [...images];
    imagePaths[editingImage.current] = path;
    handleChange(imagePaths);
  });
  const handlePressAdd = useEvent(() => {
    editingImage.current = -1;
    openPicker();
  });
  const handleEdit = useEvent(index => {
    editingImage.current = index;
    openPicker();
  });
  const handlePressRemove = useEvent(index => {
    deletingImage.current = index;
    setShowModal.on();
  });
  const handleConfirmRemove = useEvent(() => {
    const imagePaths = Array.isArray(images) ? [...images] : [...images.values];
    imagePaths.splice(deletingImage.current, 1);
    handleChange(imagePaths);
    setShowModal.off();
  });
  const imgs = Array.isArray(images) ? images : images.values;
  return (
    <View style={styles.container}>
      {showModal && (
        <ConfirmDialog
          title="questionnaire:images"
          onAccept={handleConfirmRemove}
          onCancel={setShowModal.off}>
          <Text>{t('deleteImageConfirm')}</Text>
        </ConfirmDialog>
      )}
      <Label label={label} caption={caption} />
      {imgs.map((image, index) => (
        <Pressable
          key={image}
          onPress={() => handleEdit(index)}
          style={[styles.picker]}>
          {!!image && <CheckIndicator />}
          <Image variant="clear" textIcon="Add photo" image={image} hideIcon />
          <Pressable
            style={styles.trash}
            onPress={() => handlePressRemove(index)}>
            <TrashCan />
          </Pressable>
        </Pressable>
      ))}
      {imgs.length < limit && (
        <Pressable onPress={handlePressAdd} style={[styles.picker]}>
          <Image
            variant="clear"
            textIcon={images.length === 0 ? 'takePhoto' : 'addPhoto'}
          />
        </Pressable>
      )}
      {imgs.length === 0 && (
        <View style={[styles.picker, styles.disabled]}>
          <Image variant="clear" textIcon="addPhoto" />
        </View>
      )}
    </View>
  );
};

export default ImagesPicker;
