const createStyles = theme => ({
  container: {
    width: '100%',
    marginBottom: theme.spacing.marginVertical,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-evenly',
    marginVertical: theme.spacing.marginVertical / 2,
    backgroundColor: theme.colors.white,
    borderRadius: 15,
  },
  text: {
    paddingVertical: theme.spacing.paddingVertical,
    textAlign: 'center',
  },
  picker: {
    paddingVertical: theme.spacing.paddingVertical,
  },
  select: {paddingBottom: theme.spacing.paddingVertical},
  disabled: {opacity: 0.3},
  trash: {
    position: 'absolute',
    bottom: 4,
    right: -2,
    height: 35,
    width: 35,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 50,
    backgroundColor: theme.colors.white,
  },
});

export default createStyles;
