import {Platform, KeyboardAvoidingView} from 'react-native';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import styles from './styles';

const behavior = Platform.select({
  ios: () => 'padding',
  default: () => undefined,
})();

const KeyboardView = ({children}) => {
  const insets = useSafeAreaInsets();
  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={behavior}
      keyboardVerticalOffset={insets.bottom}>
      {children}
    </KeyboardAvoidingView>
  );
};

export default KeyboardView;
