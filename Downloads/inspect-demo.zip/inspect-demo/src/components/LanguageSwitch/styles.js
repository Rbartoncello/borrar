export const createStyles = theme => ({
  pt: {
    position: 'absolute',
    left: theme.spacing.marginHorizontal * 3,
    top: 13,
    flexDirection: 'row',
    alignItems: 'center',
  },
  es: {
    position: 'absolute',
    top: 13,
    right: theme.spacing.marginHorizontal * 3,
    flexDirection: 'row',
    alignItems: 'center',
  },
  text: {
    paddingLeft: theme.spacing.paddingHorizontal,
    color: theme.colors.blue800,
  },
});

export const createContainerStyles = width => theme => ({
  container: {
    marginTop: theme.spacing.marginVertical * 2,
    marginBottom: theme.spacing.marginVertical,
    paddingHorizontal: theme.spacing.paddingHorizontal * 2,
  },
  background: {
    position: 'relative',
    height: 48,
    width: width + 8,
    flexDirection: 'row',
    padding: 4,
    alignItems: 'center',
    alignSelf: 'center',
    backgroundColor: theme.colors.grey300,
    borderRadius: 50,
  },
  pivot: {
    height: 40,
    width: 160,
    backgroundColor: theme.colors.white,
    borderRadius: 50,
  },
});
