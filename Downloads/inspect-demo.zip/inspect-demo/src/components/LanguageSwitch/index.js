import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import SwitchContainer from './SwitchContainer';
import {createStyles} from './styles';
import {Text} from '@/components';
import {LANGUAGES} from '@/constants';
import {useThemedStyles} from '@/hooks';
import {Argentinian, Brazil} from '@/icons';

const LanguageSwitch = () => {
  const {i18n} = useTranslation();
  const [styles] = useThemedStyles(createStyles);
  const handleChange = isRight =>
    i18n.changeLanguage(isRight ? LANGUAGES.ES : LANGUAGES.PT);
  return (
    <SwitchContainer
      isRight={i18n.language === LANGUAGES.ES}
      onChange={handleChange}>
      <View style={styles.pt}>
        <Brazil />
        <Text style={styles.text}>Português</Text>
      </View>
      <View style={styles.es}>
        <Argentinian />
        <Text style={styles.text}>Español</Text>
      </View>
    </SwitchContainer>
  );
};

export default LanguageSwitch;
