import {useEffect, useRef} from 'react';
import {Animated, Dimensions, PanResponder, View} from 'react-native';
import {createContainerStyles} from './styles';
import {useEvent, useThemedStyles} from '@/hooks';

const MAX_WIDTH = 350;
const PIVOT_WIDTH = 160;
const width = Math.min(Dimensions.get('window').width, MAX_WIDTH);
const PIVOT_RIGHT_POSITION = width - PIVOT_WIDTH;
const PIVOT_LEFT_POSITION = 0;
const TOGGLE_THRESHOLD = (width - PIVOT_WIDTH) / 2;

const SwitchContainer = ({isRight, children, onChange}) => {
  const [styles] = useThemedStyles(createContainerStyles(width));
  const switchAnim = useRef(new Animated.ValueXY({x: 0, y: 0}));
  const pivotOffset = isRight ? PIVOT_RIGHT_POSITION : PIVOT_LEFT_POSITION;
  const swipePivot = x =>
    Animated.timing(switchAnim.current, {
      toValue: {x, y: 0},
      duration: 200,
      useNativeDriver: true,
    }).start(() => {
      switchAnim.current.setValue({x, y: 0});
    });

  const handlePress = e => {
    const isPivotToRight = pivotOffset !== 0;
    const isRightPress = !isPivotToRight && e.nativeEvent.pageX > PIVOT_WIDTH;
    const isLeftPress =
      isPivotToRight && e.nativeEvent.pageX < width - PIVOT_WIDTH;
    if (isRightPress || isLeftPress) {
      // switch pressed outside pivot area, trigger toggle.
      swipePivot(isPivotToRight ? PIVOT_LEFT_POSITION : PIVOT_RIGHT_POSITION);
      onChange(!isPivotToRight);
    }
  };

  const handlePanResponderGrant = () => {
    const x = switchAnim.current.x._value < 0 ? 0 : switchAnim.current.x._value;
    switchAnim.current.setOffset({x, y: 0});
    switchAnim.current.setValue({x: 0, y: 0});
  };

  const handlePanResponderMove = useEvent((e, gesture) =>
    Animated.event([null, {dx: switchAnim.current.x}], {
      useNativeDriver: false,
    })(e, gesture),
  );

  const handleSwipe = gesture => {
    const isPivotToRight = pivotOffset !== 0;
    if (!isPivotToRight && gesture.dx > TOGGLE_THRESHOLD) {
      swipePivot(PIVOT_RIGHT_POSITION);
      onChange(true);
    } else if (
      isPivotToRight &&
      gesture.dx < TOGGLE_THRESHOLD - PIVOT_RIGHT_POSITION
    ) {
      swipePivot(PIVOT_LEFT_POSITION);
      onChange(false);
    } else {
      swipePivot(isPivotToRight ? PIVOT_RIGHT_POSITION : PIVOT_LEFT_POSITION);
    }
  };

  const handlePanResponderRelease = useEvent((e, gesture) => {
    switchAnim.current.flattenOffset();
    const isPress = gesture.dx === 0;
    if (isPress) {
      handlePress(e);
    } else {
      handleSwipe(gesture);
    }
  });

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onPanResponderGrant: handlePanResponderGrant,
      onPanResponderMove: handlePanResponderMove,
      onPanResponderRelease: handlePanResponderRelease,
    }),
  );
  useEffect(() => {
    if (pivotOffset > 0) {
      switchAnim.current.setValue({x: pivotOffset, y: 0});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const transformStyle = {
    transform: [
      {
        translateX: switchAnim.current.x.interpolate({
          inputRange: [PIVOT_LEFT_POSITION, PIVOT_RIGHT_POSITION],
          outputRange: [PIVOT_LEFT_POSITION, PIVOT_RIGHT_POSITION],
          extrapolate: 'clamp',
        }),
      },
    ],
  };
  return (
    <View style={styles.container}>
      <View style={styles.background} {...panResponder.current.panHandlers}>
        <Animated.View style={[styles.pivot, transformStyle]} />
        {children}
      </View>
    </View>
  );
};

export default SwitchContainer;
