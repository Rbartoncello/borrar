const createStyles = theme => ({
  container: {
    paddingVertical: theme.spacing.paddingVertical / 2,
  },
  input: {
    paddingHorizontal: theme.spacing.paddingHorizontal / 2,
    textAlignVertical: 'top',
  },
});

export default createStyles;
