import TextInput from '../TextInput';
import createStyles from './styles';
import {useThemedStyles} from '@/hooks';

const TextArea = ({numberOfLines = 4, maxLength = 250, ...props}) => {
  const [styles] = useThemedStyles(createStyles);
  return (
    <TextInput
      multiline
      numberOfLines={numberOfLines}
      maxLength={maxLength}
      inputContainerStyle={styles.container}
      inputStyle={styles.input}
      labelStyle={styles.label}
      {...props}
    />
  );
};

export default TextArea;
