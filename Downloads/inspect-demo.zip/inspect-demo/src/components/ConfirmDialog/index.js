import {Dialog} from '@rneui/themed';
import PropTypes from 'prop-types';
import {useTranslation} from 'react-i18next';

const ConfirmDialog = ({
  title,
  onAccept,
  onCancel,
  cancelText = 'cancel',
  acceptText = 'accept',
  children,
}) => {
  const {t} = useTranslation();
  return (
    <Dialog isVisible onBackdropPress={onCancel}>
      <Dialog.Title title={t(title)} />
      {children}
      <Dialog.Actions>
        <Dialog.Button title={t(acceptText)} onPress={onAccept} />
        {onCancel && <Dialog.Button title={t(cancelText)} onPress={onCancel} />}
      </Dialog.Actions>
    </Dialog>
  );
};

ConfirmDialog.propTypes = {
  title: PropTypes.string.isRequired,
  onAccept: PropTypes.func.isRequired,
  onCancel: PropTypes.func,
  cancelText: PropTypes.string,
  acceptText: PropTypes.string,
  children: PropTypes.node,
};

export default ConfirmDialog;
