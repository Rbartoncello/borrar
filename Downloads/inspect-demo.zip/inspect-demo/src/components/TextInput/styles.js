const createStyles = theme => ({
  focusedInput: {
    borderColor: theme.colors.brandPrimary,
  },
  label: {
    fontSize: theme.typography.small.fontSize,
    color: theme.colors.grey800,
    fontWeight: '500',
  },
});

export default createStyles;
