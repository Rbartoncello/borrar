import {Input} from '@rneui/themed';
import {useTranslation} from 'react-i18next';
import createStyles from './styles';
import {useBoolean, useEvent, useThemedStyles} from '@/hooks';

const labelProps = {numberOfLines: 1};

const TextInput = ({
  name,
  label,
  placeholder = 'textPlaceholder',
  errorMessage,
  inputContainerStyle,
  onChange,
  onFocus,
  onBlur,
  bla,
  ...props
}) => {
  const [isFocused, setIsFocused] = useBoolean(false);
  const [styles, theme] = useThemedStyles(createStyles);
  const {t} = useTranslation();
  const handleFocus = useEvent(() => {
    setIsFocused.on();
    onFocus?.();
  });
  const handleBlur = useEvent(() => {
    setIsFocused.off();
    onBlur?.();
  });
  return (
    <Input
      autoCapitalize="none"
      placeholderTextColor={theme.colors.grey700}
      onChangeText={onChange}
      onFocus={handleFocus}
      onBlur={handleBlur}
      labelStyle={styles.label}
      label={t(label)}
      labelProps={labelProps}
      placeholder={t(placeholder)}
      errorMessage={t(errorMessage)}
      inputContainerStyle={[
        inputContainerStyle,
        isFocused ? styles.focusedInput : undefined,
      ]}
      {...props}
    />
  );
};

export default TextInput;
