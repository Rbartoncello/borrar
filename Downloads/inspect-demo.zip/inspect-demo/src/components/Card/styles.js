const createStyles = theme => ({
  container: {
    marginVertical: theme.spacing.marginVertical,
    marginHorizontal: theme.spacing.marginHorizontal,
    paddingHorizontal: theme.spacing.paddingHorizontal,
    paddingTop: theme.spacing.paddingVertical,
    backgroundColor: theme.colors.white,
    borderRadius: 20,
  },
  title: {
    paddingLeft: theme.spacing.paddingHorizontal,
    paddingBottom: theme.spacing.paddingVertical,
  },
});

export default createStyles;
