import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import Text from '../Text';
import createStyles from './styles';
import {useThemedStyles} from '@/hooks';

const Card = ({title, children, style}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createStyles);
  return (
    <View style={[styles.container, style]}>
      {title && (
        <Text bold size="lg" style={styles.title}>
          {t(title)}
        </Text>
      )}
      {children}
    </View>
  );
};

export default Card;
