const createStyles = values => theme => ({
  container: {
    flexDirection: values.positionValue === 'left' ? 'row' : 'row-reverse',
    alignItems: 'center',
  },
  label: {
    color: values.value >= 100 ? theme.colors.green900 : theme.colors.grey600,
    fontSize: theme.typography.small.fontSize,
  },
  bar: {
    height: 6,
    flex: 1,
    marginHorizontal: 10,
    borderRadius: 4,
    backgroundColor: values.barColor || theme.colors.grey200,
  },
  barIndicator: {
    position: 'absolute',
    top: 0,
    right: `${100 - values.value}%`,
    bottom: 0,
    left: 0,
    height: 6,
    borderRadius: 4,
    backgroundColor:
      values.value >= 100
        ? theme.colors.green900
        : values.barIndicatorColor || theme.colors.grey600,
  },
});

export default createStyles;
