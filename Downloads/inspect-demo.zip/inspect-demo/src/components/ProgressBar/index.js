import PropTypes from 'prop-types';
import {View} from 'react-native';
import createStyles from './styles';
import {Text} from '@/components';
import {useThemedStyles} from '@/hooks';

const ProgressBar = ({
  value,
  positionValue = 'left',
  barColor,
  barIndicatorColor,
}) => {
  const [styles] = useThemedStyles(
    createStyles({value, positionValue, barColor, barIndicatorColor}),
  );
  return (
    <View style={styles.container}>
      {positionValue !== 'none' && (
        <Text style={styles.label}>{`${Math.round(value)}%`}</Text>
      )}
      <View style={styles.bar}>
        <View style={styles.barIndicator} />
      </View>
    </View>
  );
};

ProgressBar.propTypes = {
  value: PropTypes.number.isRequired,
  positionValue: PropTypes.oneOf(['left', 'right', 'none']),
  barColor: PropTypes.string,
  barIndicatorColor: PropTypes.string,
};

export default ProgressBar;
