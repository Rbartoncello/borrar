import PropTypes from 'prop-types';
import {Modal as BaseModal} from 'react-native';

const SUPPORTED_ORIENTATIONS = [
  'landscape',
  'landscape-left',
  'landscape-right',
  'portrait',
  'portrait-upside-down',
];

const Modal = ({
  animationType = 'slide',
  presentationStyle = 'formSheet',
  visible = false,
  transparent = false,
  children,
  ...props
}) => (
  <BaseModal
    transparent={transparent}
    animationType={animationType}
    presentationStyle={presentationStyle}
    supportedOrientations={SUPPORTED_ORIENTATIONS}
    visible={visible}
    {...props}>
    {children}
  </BaseModal>
);

Modal.propTypes = {
  animationType: PropTypes.oneOf(['slide', 'fade', 'none']),
  presentationStyle: PropTypes.oneOf([
    'fullScreen',
    'formSheet',
    'overFullScreen',
    'pageSheet',
  ]),
  visible: PropTypes.bool,
};

export default Modal;
