import {Button} from '@rneui/base';
import {withTheme} from '@rneui/themed';
import PropTypes from 'prop-types';
import {useTranslation} from 'react-i18next';
import {createButtonStyles} from './styles';
import {useEvent, useThemedStyles} from '@/hooks';
import {Check} from '@/icons';

const ChipButton = withTheme(Button, 'ChipButton');

const Chip = ({active, option, onPress}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createButtonStyles);
  const handlePress = useEvent(() => onPress(option));
  return (
    <ChipButton
      title={t(option.label)}
      iconRight
      icon={
        active ? (
          <Check width={22} height={22} style={styles.icon} />
        ) : undefined
      }
      buttonStyle={[active ? styles.active : undefined]}
      titleStyle={[active ? styles.activeTitle : undefined]}
      onPress={handlePress}
    />
  );
};

Chip.propTypes = {
  active: PropTypes.bool,
  option: PropTypes.shape({
    label: PropTypes.string,
  }),
  onPress: PropTypes.func,
};

export default Chip;
