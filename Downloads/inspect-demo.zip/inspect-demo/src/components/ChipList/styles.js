export const createStyles = theme => ({
  container: {width: '100%'},
  content: {flexDirection: 'row', flexWrap: 'wrap'},
  error: {
    color: theme.colors.red800,
    fontSize: 12,
  },
});

export const createButtonStyles = theme => ({
  active: {backgroundColor: theme.colors.brandPrimary},
  activeTitle: {color: theme.colors.white},
  icon: {marginLeft: theme.spacing.marginVertical / 2},
});
