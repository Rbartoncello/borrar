import {Text} from '@rneui/themed';
import PropTypes from 'prop-types';
import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import Label from '../Label';
import Chip from './Chip';
import {createStyles} from './styles';
import {useCheckListItem, useThemedStyles} from '@/hooks';

const ChipList = ({
  options = [],
  value = [],
  label,
  caption,
  onChange,
  errorMessage,
}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createStyles);
  const handlePress = useCheckListItem(value, onChange);
  return (
    options.length > 0 && (
      <View style={styles.container}>
        <Label label={label} caption={caption} />
        <View style={styles.content}>
          {options.map(option => (
            <Chip
              key={option.value}
              active={value?.includes(option.value)}
              option={option}
              onPress={handlePress}
            />
          ))}
        </View>
        <Text style={styles.error}>{t(errorMessage)}</Text>
      </View>
    )
  );
};

ChipList.propTypes = {
  value: PropTypes.arrayOf(PropTypes.string),
  options: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string,
      value: PropTypes.string,
    }),
  ),
  label: PropTypes.string,
  errorMessage: PropTypes.string,
  onChange: PropTypes.func,
};

export default ChipList;
