import {Fragment, useEffect, useMemo} from 'react';
import {Animated, Pressable} from 'react-native';
import {createChapterResultStyles} from './styles';
import {FlawsIndicator} from '@/components';
import {useChapterFlawsCount, useThemedStyles} from '@/hooks';
import {Check} from '@/icons';

const buildAnimationConfig = toValue => ({
  toValue,
  duration: 1500,
  useNativeDriver: true,
});

const ChapterResult = ({chapter, values, onPressIndicator}) => {
  const [styles] = useThemedStyles(createChapterResultStyles(chapter.name));
  const flaws = useChapterFlawsCount(chapter, values);
  const pulse = useMemo(
    () => ({
      opacity: new Animated.Value(1),
      diameter: new Animated.Value(0),
    }),
    [],
  );
  useEffect(() => {
    Animated.loop(
      Animated.parallel([
        Animated.timing(pulse.diameter, buildAnimationConfig(1.5)),
        Animated.timing(pulse.opacity, buildAnimationConfig(0)),
      ]),
    ).start();
  }, [pulse]);
  return flaws ? (
    <Fragment>
      <Animated.View
        key={pulse.id}
        style={[
          styles.container,
          {transform: [{scale: pulse.diameter}], opacity: pulse.opacity},
        ]}
      />
      <Pressable style={styles.indicatorContainer} onPress={onPressIndicator}>
        <FlawsIndicator flaws={flaws} containerStyle={styles.indicator} />
      </Pressable>
    </Fragment>
  ) : (
    <Check style={styles.check} />
  );
};

export default ChapterResult;
