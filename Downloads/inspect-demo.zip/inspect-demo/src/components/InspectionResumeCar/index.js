import {Image, View} from 'react-native';
import ChapterResult from './ChapterResult';
import createStyles from './styles';
import {carTopView} from '@/data';
import {useSourceUri, useThemedStyles} from '@/hooks';

const InspectionResumeCar = ({chapters, inspection, onPressIndicator}) => {
  const [styles] = useThemedStyles(createStyles);
  const source = useSourceUri(carTopView);
  return (
    <View style={styles.container}>
      <Image source={source} style={styles.image} resizeMode="contain" />
      {chapters.map((chapter, index) => (
        <ChapterResult
          key={chapter.name}
          chapter={chapter}
          values={inspection[chapter.name]}
          onPressIndicator={() => onPressIndicator(index)}
        />
      ))}
    </View>
  );
};

export default InspectionResumeCar;
