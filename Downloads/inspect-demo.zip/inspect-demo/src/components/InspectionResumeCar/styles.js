import {Platform} from 'react-native';

const getHorizontalOffset = (position, completed) => {
  switch (position) {
    case 'front':
      return completed ? '5%' : '-5%';
    case 'back':
      return completed ? '85%' : '80%';
    case 'center':
      return completed ? '43%' : '35%';
  }
};

const getVerticalOffset = (position, completed) => {
  switch (position) {
    case 'left':
      return '80%';
    case 'right':
      return completed ? '-10%' : '-20%';
    case 'center':
      return completed ? '40%' : '30%';
  }
};

const createStyles = () => ({
  container: {
    height: 130,
    width: 280,
    marginVertical: 24,
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {height: 130, width: 280},
});

export const createChapterResultStyles = position => theme => {
  const baseContainer = {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
  };
  return {
    check: {
      ...baseContainer,
      height: 24,
      width: 24,
      left: getHorizontalOffset(position, true),
      top: getVerticalOffset(position, true),
      borderRadius: 12,
      backgroundColor: theme.colors.green900,
    },
    container: {
      ...baseContainer,
      height: 50,
      width: 50,
      left: getHorizontalOffset(position, false),
      top: getVerticalOffset(position, false),
      borderRadius: 25,
      backgroundColor: `${theme.colors.blue800}75`,
    },
    indicatorContainer: {
      ...baseContainer,
      height: 50,
      width: 50,
      left: getHorizontalOffset(position, false),
      top: getVerticalOffset(position, false),
    },
    indicator: {
      height: 38,
      width: 38,
      paddingBottom: Platform.select({
        android: () => 4,
        ios: () => 2,
        default: () => 2,
      })(),
      borderRadius: 19,
      backgroundColor: theme.colors.blue800,
      alignItems: 'center',
      justifyContent: 'center',
    },
  };
};

export default createStyles;
