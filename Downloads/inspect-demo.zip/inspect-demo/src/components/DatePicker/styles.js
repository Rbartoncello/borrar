import {StyleSheet} from 'react-native';

export default StyleSheet.create({
  button: {marginBottom: 16},
});
