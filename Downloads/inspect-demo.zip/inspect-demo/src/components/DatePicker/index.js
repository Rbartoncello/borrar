import DateTimePicker from '@react-native-community/datetimepicker';

const DatePicker = ({
  defaultValue,
  maximumDate,
  minimumDate,
  onChange,
  onDismiss,
}) => {
  const handleChange = (e, date) => {
    if (date) {
      onChange(date.toISOString());
    } else {
      onDismiss();
    }
  };
  return (
    <DateTimePicker
      value={defaultValue ? new Date(defaultValue) : maximumDate}
      maximumDate={maximumDate}
      minimumDate={minimumDate}
      mode="date"
      onChange={handleChange}
    />
  );
};

export default DatePicker;
