import DatePickerModal from './DatePickerModal';

const DatePicker = ({
  defaultValue,
  maximumDate,
  minimumDate,
  onChange,
  onDismiss,
}) => {
  const handleChange = date => onChange(date.toISOString());
  return (
    <DatePickerModal
      defaultValue={defaultValue}
      onChange={handleChange}
      onDismiss={onDismiss}
      maximumDate={maximumDate}
      minimumDate={minimumDate}
    />
  );
};

export default DatePicker;
