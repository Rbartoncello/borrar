import DateTimePicker from '@react-native-community/datetimepicker';
import {useState} from 'react';
import styles from './styles';
import {BottomSheet, Button} from '@/components';

const DatePickerModal = ({
  defaultValue,
  maximumDate,
  minimumDate,
  onChange,
  onDismiss,
}) => {
  const [value, setValue] = useState(
    defaultValue ? new Date(defaultValue) : maximumDate,
  );
  const handleChange = (e, date) => {
    if (date) {
      setValue(date);
    }
  };
  return (
    <BottomSheet visible onClose={onDismiss}>
      <DateTimePicker
        value={value}
        maximumDate={maximumDate}
        minimumDate={minimumDate}
        mode="date"
        display="spinner"
        onChange={handleChange}
      />
      <Button
        containerStyle={styles.button}
        title="confirm"
        onPress={() => onChange(value)}
      />
    </BottomSheet>
  );
};

export default DatePickerModal;
