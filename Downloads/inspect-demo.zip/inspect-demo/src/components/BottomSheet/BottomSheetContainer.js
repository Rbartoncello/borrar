import {useEffect, useRef, useState} from 'react';
import {Animated, Modal, PanResponder, Pressable, View} from 'react-native';
import {createContainerStyles} from './styles';
import {useEvent, useThemedStyles} from '@/hooks';

const SUPPORTED_ORIENTATIONS = [
  'landscape',
  'landscape-left',
  'landscape-right',
  'portrait',
  'portrait-upside-down',
];

const BottomSheetContainer = ({visible, onClose, children}) => {
  const [styles] = useThemedStyles(createContainerStyles);
  const [height, setHeight] = useState(200);
  const fadeAnim = useRef(new Animated.ValueXY({x: 0, y: height}));

  const handleLayout = useEvent(e => setHeight(e.nativeEvent.layout.height));
  const handleClose = useEvent(() =>
    Animated.timing(fadeAnim.current, {
      toValue: {x: 0, y: height},
      duration: 200,
      useNativeDriver: true,
    }).start(onClose),
  );
  const handlePanResponderRelease = useEvent((e, gestureState) => {
    const distanceToClose = height * 0.5;
    if (gestureState.dy > distanceToClose || gestureState.vy > 0.5) {
      handleClose();
    } else {
      Animated.spring(fadeAnim.current, {
        toValue: {x: 0, y: 0},
        useNativeDriver: true,
      }).start();
    }
  });

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onPanResponderMove: (e, gestureState) =>
        Animated.event(
          [
            null,
            {
              dy:
                gestureState.dy > 0
                  ? fadeAnim.current.y
                  : new Animated.Value(0),
            },
          ],
          {useNativeDriver: false},
        )(e, gestureState),
      onPanResponderRelease: handlePanResponderRelease,
    }),
  );

  useEffect(() => {
    if (visible) {
      Animated.spring(fadeAnim.current, {
        toValue: {x: 0, y: 0},
        duration: 200,
        useNativeDriver: true,
      }).start();
    }
  }, [visible]);
  return (
    visible && (
      <Modal
        visible
        transparent
        animationType="fade"
        supportedOrientations={SUPPORTED_ORIENTATIONS}
        onRequestClose={handleClose}>
        <View style={styles.container}>
          <Pressable
            style={styles.backdrop}
            activeOpacity={1}
            onPress={handleClose}
          />
          <Animated.View
            {...panResponder.current.panHandlers}
            onLayout={handleLayout}
            style={{transform: fadeAnim.current.getTranslateTransform()}}>
            {children || <View />}
          </Animated.View>
        </View>
      </Modal>
    )
  );
};

export default BottomSheetContainer;
