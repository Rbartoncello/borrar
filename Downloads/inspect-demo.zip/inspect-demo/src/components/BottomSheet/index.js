import {useTranslation} from 'react-i18next';
import {ScrollView, View} from 'react-native';
import BottomSheetContainer from './BottomSheetContainer';
import {createStyles} from './styles';
import {Text} from '@/components';
import {useThemedStyles} from '@/hooks';

const BottomSheet = ({visible, onClose, title, children}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createStyles);
  return (
    <BottomSheetContainer visible={visible} onClose={onClose}>
      <View style={styles.container}>
        <View style={styles.bar} />
        <Text bold style={styles.title}>
          {t(title)}
        </Text>
        <ScrollView style={styles.content}>{children}</ScrollView>
      </View>
    </BottomSheetContainer>
  );
};

export default BottomSheet;
