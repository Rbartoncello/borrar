export const createStyles = theme => ({
  container: {
    position: 'relative',
    top: 20,
    paddingBottom: 20,
    backgroundColor: theme.colors.white,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    shadowColor: theme.colors.black,
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 2,
  },
  content: {
    maxHeight: 400,
    paddingHorizontal: theme.spacing.paddingHorizontal,
    paddingBottom: theme.spacing.paddingVertical,
  },
  bar: {
    width: 76,
    height: 3,
    top: 16,
    borderRadius: 50,
    alignSelf: 'center',
    backgroundColor: theme.colors.grey500,
  },
  title: {
    marginTop: theme.spacing.marginVertical,
    paddingHorizontal: theme.spacing.paddingHorizontal * 1.5,
    paddingVertical: theme.spacing.paddingVertical,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.grey200,
  },
});

export const createContainerStyles = () => ({
  container: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  backdrop: {flex: 1},
});
