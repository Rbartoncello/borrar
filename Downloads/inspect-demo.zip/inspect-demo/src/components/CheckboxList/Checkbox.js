import {CheckBox} from '@rneui/themed';
import PropTypes from 'prop-types';
import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import {createCheckboxStyle} from './styles';
import {useEvent, useThemedStyles} from '@/hooks';
import {Check} from '@/icons';

const Checkbox = ({
  active,
  disabled,
  option,
  onPress,
  isFirst,
  isLast,
  ...props
}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(
    createCheckboxStyle({disabled, isFirst, isLast}),
  );
  const handlePress = useEvent(() => onPress(option));
  return (
    <CheckBox
      checked={active}
      title={t(option.label)}
      disabled={disabled}
      disabledStyle={styles.disabled}
      containerStyle={styles.container}
      checkedIcon={<Check style={styles.checkIcon} />}
      uncheckedIcon={<View style={styles.uncheckIcon} />}
      onPress={handlePress}
      {...props}
    />
  );
};

Checkbox.propTypes = {
  option: PropTypes.shape({
    label: PropTypes.string,
  }).isRequired,
  active: PropTypes.bool.isRequired,
  disabled: PropTypes.bool,
  onPress: PropTypes.func.isRequired,
};

export default Checkbox;
