import PropTypes from 'prop-types';
import {View} from 'react-native';
import Checkbox from './Checkbox';
import {createStyle} from './styles';
import {useCheckListItem, useThemedStyles} from '@/hooks';

const CheckboxList = ({
  options = [],
  value = [],
  onChange,
  disabled = false,
  ...props
}) => {
  const [styles] = useThemedStyles(createStyle);
  const handlePress = useCheckListItem(value, onChange);
  return (
    <View style={styles.container}>
      {options.map((option, index) => (
        <Checkbox
          key={option.value}
          active={value?.includes(option.value)}
          option={option}
          onPress={handlePress}
          disabled={option.disabled || disabled}
          isFirst={index === 0}
          isLast={index === options.length - 1}
          {...props}
        />
      ))}
    </View>
  );
};

CheckboxList.propTypes = {
  wrapperStyle: PropTypes.shape({}),
  value: PropTypes.arrayOf(PropTypes.string),
  options: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string,
      value: PropTypes.string,
    }),
  ),
  label: PropTypes.string,
  errorMessage: PropTypes.string,
  onChange: PropTypes.func,
  disabled: PropTypes.bool,
};

export default CheckboxList;
