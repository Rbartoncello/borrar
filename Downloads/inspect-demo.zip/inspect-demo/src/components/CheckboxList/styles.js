export const createStyle = theme => ({
  container: {
    width: '100%',
    marginHorizontal: -theme.spacing.marginHorizontal,
    marginBottom: theme.spacing.marginHorizontal,
  },
});

export const createCheckboxStyle = values => theme => ({
  container: {
    width: '100%',
    marginHorizontal: 0,
    marginTop: 0,
    marginBottom: 1,
    padding: theme.spacing.paddingHorizontal * 2,
    backgroundColor: theme.colors.white,
    borderTopLeftRadius: values.isFirst ? 12 : 0,
    borderTopRightRadius: values.isFirst ? 12 : 0,
    borderBottomLeftRadius: values.isLast ? 12 : 0,
    borderBottomRightRadius: values.isLast ? 12 : 0,
  },
  checkIcon: {
    backgroundColor: values.disabled
      ? theme.colors.grey300
      : theme.colors.blue800,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: values.disabled ? theme.colors.grey300 : theme.colors.blue800,
  },
  uncheckIcon: {
    height: 21,
    width: 20,
    borderWidth: 2,
    borderColor: values.disabled ? theme.colors.grey300 : theme.colors.blue800,
    borderRadius: 6,
  },
});
