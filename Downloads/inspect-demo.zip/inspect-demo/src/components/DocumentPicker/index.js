import {useState, useEffect} from 'react';
import {useTranslation} from 'react-i18next';
import {TouchableOpacity, View, Image as Img} from 'react-native';
import CheckIndicator from '../CheckIndicator';
import Image from '../Image';
import Text from '../Text';
import createStyles from './styles';
import pdf from '@/assets/images/pdf.png';
import {useThemedStyles} from '@/hooks';
import {Upload} from '@/icons';
import {openDocumentPicker} from '@/util';

const DocumentPicker = ({
  label,
  value = null,
  status,
  disabled,
  placeholder,
  onChange,
  children,
}) => {
  const {t} = useTranslation();
  const pdfLogo = Img.resolveAssetSource(pdf).uri;
  const [styles] = useThemedStyles(createStyles);
  const [file, setFile] = useState();
  const handlePress = () => openDocumentPicker(onChange);
  useEffect(() => {
    setFile(value);
  }, [value]);
  return (
    <View style={styles.container}>
      <TouchableOpacity
        onPress={handlePress}
        style={styles.picker}
        disabled={disabled}>
        {!!file && <CheckIndicator />}
        <Image
          {...{status, placeholder}}
          image={!!value && pdfLogo}
          icon={Upload}
          variant="clear"
          textIcon="upload"
          hideIcon={!!file}
        />
      </TouchableOpacity>
      <Text bold style={styles.label}>
        {t(label)}
      </Text>
      {children}
    </View>
  );
};

export default DocumentPicker;
