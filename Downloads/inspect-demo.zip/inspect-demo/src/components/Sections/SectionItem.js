import PropTypes from 'prop-types';
import {useTranslation} from 'react-i18next';
import createStyles from './styles';
import {Button} from '@/components';
import {useThemedStyles} from '@/hooks';
import {Check} from '@/icons';

const SectionItem = ({label, active, completed, ...props}) => {
  const [styles] = useThemedStyles(createStyles(active));
  const {t} = useTranslation();
  return (
    <Button
      type="outline"
      buttonStyle={styles.buttonStyle}
      titleStyle={styles.buttonTitleStyle}
      containerStyle={styles.containerButtonStyle}
      {...props}>
      {t(label)}
      {completed && <Check style={styles.check} />}
    </Button>
  );
};

SectionItem.propTypes = {
  item: PropTypes.shape({}),
  active: PropTypes.bool,
  completed: PropTypes.bool,
  onSelect: PropTypes.func,
};

export default SectionItem;
