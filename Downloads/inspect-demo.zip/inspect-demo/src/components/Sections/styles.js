const createStyles = active => theme => ({
  containerButtonStyle: {
    marginHorizontal: 4,
    borderRadius: 999,
    borderColor: 'transparent',
  },
  buttonStyle: {
    backgroundColor: active ? theme.colors.white : theme.colors.blue1000,
    borderWidth: 1,
    borderColor: theme.colors.white,
    borderRadius: 999,
  },
  buttonTitleStyle: {
    color: active ? theme.colors.grey1000 : theme.colors.white,
    fontWeight: '400',
    fontSize: theme.typography.small.fontSize,
  },
  check: {
    height: 20,
    width: 20,
    borderRadius: 10,
    backgroundColor: theme.colors.green800,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
  },
});

export default createStyles;
