import PropTypes from 'prop-types';
import {useRef, useEffect} from 'react';
import {FlatList} from 'react-native';
import SectionItem from './SectionItem';

const isComplete = section =>
  Object.keys(section || {}).some(key => key !== 'subsections');

const renderItem =
  (chapter, active, onSelect) =>
  ({item, index}) =>
    (
      <SectionItem
        section={item}
        completed={isComplete(chapter?.[item.name])}
        active={index === active}
        onSelect={() => onSelect(index)}
      />
    );

const Sections = ({chapter, sections, index = 0, onSelect}) => {
  const ref = useRef();
  useEffect(() => {
    setTimeout(() => {
      ref.current?.scrollToIndex({index, animated: true});
    }, 500);
  }, [ref, index]);
  return (
    <FlatList
      ref={ref}
      horizontal
      data={sections}
      renderItem={renderItem(chapter, index, onSelect)}
      keyExtractor={item => item.name}
    />
  );
};

Sections.propTypes = {
  sections: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
  chapter: PropTypes.shape({}),
  index: PropTypes.number,
  onSelect: PropTypes.func.isRequired,
};

export default Sections;
