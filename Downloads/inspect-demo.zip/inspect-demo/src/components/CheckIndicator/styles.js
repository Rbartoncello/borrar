const createStyles = theme => ({
  container: {
    position: 'absolute',
    left: -2,
    top: 8,
    padding: theme.spacing.paddingHorizontal / 3,
    backgroundColor: theme.colors.white,
    borderRadius: theme.spacing.baseUnit * 1.5,
    zIndex: 2,
  },
  icon: {
    height: theme.spacing.baseUnit * 1.25,
    width: theme.spacing.baseUnit * 1.25,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: theme.colors.green800,
    borderRadius: 10,
  },
});

export default createStyles;
