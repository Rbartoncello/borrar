import {View} from 'react-native';
import createStyles from './styles';
import {useThemedStyles} from '@/hooks';
import {Check} from '@/icons';

const CheckIndicator = () => {
  const [styles] = useThemedStyles(createStyles);
  return (
    <View style={styles.container}>
      <Check style={styles.icon} />
    </View>
  );
};

export default CheckIndicator;
