import {ListItem} from '@rneui/themed';
import PropTypes from 'prop-types';
import {useTranslation} from 'react-i18next';
import {BottomSheet} from '@/components';

const Menu = ({options = [], onClose, ...props}) => {
  const {t} = useTranslation();
  const handlePress = onPress => {
    onClose?.();
    onPress();
  };
  return (
    <BottomSheet onClose={onClose} {...props}>
      {options.map(option => (
        <ListItem
          key={option.label}
          onPress={() => handlePress(option.onPress)}>
          {option.icon}
          <ListItem.Content>
            <ListItem.Title>{t(option.label)}</ListItem.Title>
          </ListItem.Content>
        </ListItem>
      ))}
    </BottomSheet>
  );
};

Menu.propTypes = {
  onClose: PropTypes.func,
  options: PropTypes.arrayOf(
    PropTypes.shape({
      icon: PropTypes.element,
      label: PropTypes.string.isRequired,
      onPress: PropTypes.func.isRequired,
    }),
  ),
};

export default Menu;
