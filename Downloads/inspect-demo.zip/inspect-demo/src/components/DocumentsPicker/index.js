import {useState} from 'react';
import {useTranslation} from 'react-i18next';
import {TouchableOpacity, View} from 'react-native';
import Menu from '../Menu';
import Text from '../Text';
import FileRow from './FileRow';
import createStyles from './styles';
import {useBoolean, useThemedStyles} from '@/hooks';
import {Upload, TrashCan} from '@/icons';
import {openDocumentPicker} from '@/util';

const DocumentsPicker = ({value = [], disabled, onChange}) => {
  const {t} = useTranslation();
  const [styles, theme] = useThemedStyles(createStyles);
  const [showMenu, setShowMenu] = useBoolean();
  const [selectedIndex, setSelectedIndex] = useState();
  const removeFile = () => {
    const files = [...value];
    files[selectedIndex] = undefined;
    onChange(files.filter(Boolean));
  };
  const options = [
    {
      icon: <TrashCan />,
      label: 'delete',
      onPress: removeFile,
    },
  ];
  const handlePress = () =>
    openDocumentPicker((document, name) =>
      onChange(value.concat({document, name})),
    );
  const handleShowMenu = index => {
    setSelectedIndex(index);
    setShowMenu.on();
  };
  return (
    <View style={styles.container}>
      <Menu visible={showMenu} onClose={setShowMenu.off} options={options} />
      {value.map((file, index) => (
        <FileRow
          key={index}
          filename={file.name || `${t('file')}-${index + 1}`}
          onPress={() => handleShowMenu(index)}
        />
      ))}
      <TouchableOpacity
        onPress={handlePress}
        style={styles.picker}
        disabled={disabled}>
        <View style={styles.row}>
          <Upload color={theme.colors.brandPrimary} height={20} width={20} />
          <Text style={styles.text}>{t('upload')}</Text>
        </View>
      </TouchableOpacity>
    </View>
  );
};

export default DocumentsPicker;
