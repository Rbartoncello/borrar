const createStyles = theme => ({
  container: {
    width: '100%',
    borderRadius: 12,
    padding: theme.spacing.paddingVertical,
    marginBottom: theme.spacing.marginVertical * 1.5,
    backgroundColor: theme.colors.white,
  },
  row: {
    flexDirection: 'row',
  },
  picker: {
    padding: theme.spacing.paddingVertical * 1.2,
    width: '100%',
  },
  text: {
    fontWeight: 'bold',
    marginLeft: theme.spacing.marginHorizontal,
    color: theme.colors.brandPrimary,
  },
});

export default createStyles;
