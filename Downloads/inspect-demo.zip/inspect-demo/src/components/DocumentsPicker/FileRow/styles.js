const createStyles = theme => ({
  file: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: theme.spacing.marginVertical / 2,
    paddingBottom: theme.spacing.marginVertical / 2,
    borderBottomWidth: 1,
    borderColor: theme.colors.grey400,
  },
  text: {
    flex: 1,
  },
  fileIcon: {
    marginVertical: theme.spacing.marginVertical,
    marginRight: theme.spacing.marginHorizontal * 1.5,
  },
});

export default createStyles;
