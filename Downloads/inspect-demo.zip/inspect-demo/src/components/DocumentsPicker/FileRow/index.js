import {Pressable, View} from 'react-native';
import Text from '../../Text';
import createStyles from './styles';
import {useThemedStyles} from '@/hooks';
import {EllipsisVertical, File} from '@/icons';

const FileRow = ({filename, onPress}) => {
  const [styles] = useThemedStyles(createStyles);
  return (
    <View style={styles.file}>
      <View style={styles.fileIcon}>
        <File />
      </View>
      <Text style={styles.text} bold>
        {filename}
      </Text>
      <Pressable onPress={onPress}>
        <EllipsisVertical />
      </Pressable>
    </View>
  );
};

export default FileRow;
