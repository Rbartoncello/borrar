import SubsectionRow from './Rows/SubsectionRow';

const SubsectionList = ({
  subsections = [],
  values = {},
  disabled,
  onAdd,
  onEdit,
  onRemove,
}) =>
  subsections.map((subsection, index) => (
    <SubsectionRow
      key={subsection.name}
      subsection={subsection}
      values={values[subsection.name]}
      disabled={disabled}
      isFirst={index === 0}
      isLast={subsections.length === index + 1}
      onAdd={onAdd}
      onEdit={onEdit}
      onRemove={onRemove}
    />
  ));

export default SubsectionList;
