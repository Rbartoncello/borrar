import PropTypes from 'prop-types';
import {Fragment} from 'react';
import {useTranslation} from 'react-i18next';
import {Pressable, View} from 'react-native';
import Button from '../../Button';
import Text from '../../Text';
import {createIterableSubsectionStyles} from './styles';
import {formatStatus} from './util';
import {
  useEvent,
  useHasIterableSubsectionOptionsAvailable,
  useThemedStyles,
} from '@/hooks';
import {EllipsisVertical} from '@/icons';

const IterableRow = ({
  subsection,
  values,
  isFirst,
  isLast,
  onAdd,
  onShowMenu,
}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(
    createIterableSubsectionStyles({isFirst, isLast}),
  );
  const hasOptionsAvailable = useHasIterableSubsectionOptionsAvailable(
    subsection,
    values,
  );
  const handleAdd = useEvent(() => onAdd(subsection));
  return (
    <Fragment>
      {values.map((value, index) => (
        <Fragment key={value[subsection.iteratee]}>
          <View style={styles.section}>
            <View style={[styles.simpleRow, styles.flex, styles.sectionHeader]}>
              <View style={styles.titleSection}>
                <View style={styles.bullet} />
                <Text size="sm" bold>
                  {t(value[subsection.iteratee])}
                </Text>
              </View>
              <Pressable onPress={() => onShowMenu(index)}>
                <EllipsisVertical />
              </Pressable>
            </View>
          </View>
          <View style={[styles.section, styles.flawSection]}>
            <Text size="sm" style={styles.flawLabel}>
              {formatStatus(t, subsection, value)}
            </Text>
          </View>
        </Fragment>
      ))}
      {hasOptionsAvailable && (
        <View style={styles.buttonPieceContainer}>
          <Button
            onPress={handleAdd}
            type="clear"
            titleStyle={styles.buttonPiece}>
            {t('inspection:addPiece')}
          </Button>
        </View>
      )}
    </Fragment>
  );
};

IterableRow.propTypes = {
  subsection: PropTypes.shape({}),
  values: PropTypes.arrayOf(PropTypes.shape({})),
  onAdd: PropTypes.func,
  onShowMenu: PropTypes.func,
  isFirst: PropTypes.bool,
  isLast: PropTypes.bool,
};

export default IterableRow;
