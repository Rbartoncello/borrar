import {useTheme} from '@rneui/themed';
import {Fragment, useState} from 'react';
import Menu from '../../Menu';
import DefaultRow from './DefaultRow';
import FlawedSubsectionRow from './FlawedSubsectionRow';
import {useBoolean} from '@/hooks';
import {ArrowRightToClipboard, TrashCan} from '@/icons';

const SubsectionRow = ({
  subsection,
  disabled,
  isFirst,
  isLast,
  onAdd,
  onEdit,
  onRemove,
  values,
}) => {
  const {theme} = useTheme();
  const [showMenu, setShowMenu] = useBoolean();
  const [selectedIndex, setSelectedIndex] = useState();
  const options = [
    {
      icon: <ArrowRightToClipboard color={theme.colors.black} />,
      label: 'edit',
      onPress: () => onEdit({subsection, index: selectedIndex}),
    },
    {
      icon: <TrashCan />,
      label: 'delete',
      onPress: () => onRemove({subsection, index: selectedIndex}),
    },
  ];
  const handleShowMenu = index => {
    setSelectedIndex(index);
    setShowMenu.on();
  };
  const hasFlaws = !!Object.keys(values || {}).length;
  return (
    <Fragment>
      {showMenu && <Menu visible onClose={setShowMenu.off} options={options} />}
      {hasFlaws ? (
        <FlawedSubsectionRow
          subsection={subsection}
          values={values}
          isFirst={isFirst}
          isLast={isLast}
          onShowMenu={handleShowMenu}
          onAdd={subsection.iteratee ? onAdd : undefined}
        />
      ) : (
        <DefaultRow {...{subsection, disabled, isFirst, isLast, onEdit}} />
      )}
    </Fragment>
  );
};

export default SubsectionRow;
