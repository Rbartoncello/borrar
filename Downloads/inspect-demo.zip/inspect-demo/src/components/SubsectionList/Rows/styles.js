export const createDefaultRowStyles = values => theme => ({
  border: {
    flexDirection: 'row',
    backgroundColor: theme.colors.white,
    borderTopLeftRadius: values.isFirst ? 12 : 0,
    borderTopRightRadius: values.isFirst ? 12 : 0,
    borderBottomLeftRadius: values.isLast ? 12 : 0,
    borderBottomRightRadius: values.isLast ? 12 : 0,
  },
  flex: {flex: 1},
  row: {
    flexDirection: 'row',
    marginBottom: 1,
    padding: theme.spacing.paddingHorizontal * 2,
    alignItems: 'center',
  },
});

export const createSimpleSubsectionStyles = values => theme => ({
  ...createDefaultRowStyles(values)(theme),
  column: {
    flexDirection: 'column',
    paddingHorizontal: theme.spacing.paddingHorizontal * 2,
    paddingBottom: theme.spacing.paddingVertical * 2,
  },
  simpleRow: {flexDirection: 'row'},
  bar: {
    backgroundColor: theme.colors.brandPrimary,
    borderRadius: 64,
    width: 3,
    marginHorizontal: 4,
    marginVertical: theme.spacing.marginVertical,
  },
  flawLabel: {color: theme.colors.grey800},
  sectionHeader: {marginBottom: 4},
  section: {
    paddingHorizontal: theme.spacing.paddingHorizontal * 2,
  },
  bullet: {
    width: 6,
    height: 6,
    marginRight: 8,
    borderRadius: 3,
    backgroundColor: theme.colors.brandPrimary,
  },
  titleSection: {flex: 1, flexDirection: 'row', alignItems: 'center'},
});

export const createIterableSubsectionStyles = values => theme => ({
  ...createSimpleSubsectionStyles(values)(theme),
  section: {
    paddingHorizontal: theme.spacing.paddingHorizontal * 2,
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {marginRight: 6},
  button: {paddingVertical: 0},
  flawSection: {marginBottom: 28},
  buttonPieceContainer: {alignItems: 'flex-start'},
  buttonPiece: {fontWeight: 'bold'},
});
