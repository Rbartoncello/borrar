import PropTypes from 'prop-types';
import {useTranslation} from 'react-i18next';
import {Pressable, View} from 'react-native';
import Text from '../../Text';
import {createSimpleSubsectionStyles} from './styles';
import {formatStatus} from './util';
import {useThemedStyles} from '@/hooks';
import {EllipsisVertical} from '@/icons';

const SimpleRow = ({subsection, values, isFirst, isLast, onShowMenu}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(
    createSimpleSubsectionStyles({isFirst, isLast}),
  );
  return (
    <View style={styles.simpleRow}>
      <View style={[styles.column, styles.flex]}>
        <View style={styles.titleSection}>
          <View style={styles.bullet} />
          <Text size="sm" style={styles.flawLabel}>
            {formatStatus(t, subsection, values)}
          </Text>
        </View>
      </View>
      <View style={styles.section}>
        <View style={[styles.flex, styles.sectionHeader]}>
          <Pressable onPress={() => onShowMenu()}>
            <EllipsisVertical />
          </Pressable>
        </View>
      </View>
    </View>
  );
};

SimpleRow.propTypes = {
  subsection: PropTypes.shape({}),
  values: PropTypes.shape({}),
  onShowMenu: PropTypes.func,
  isFirst: PropTypes.bool,
  isLast: PropTypes.bool,
};

export default SimpleRow;
