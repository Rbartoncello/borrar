import PropTypes from 'prop-types';
import {useTranslation} from 'react-i18next';
import {Pressable, View} from 'react-native';
import Text from '../../Text';
import {createDefaultRowStyles} from './styles';
import {useEvent, useThemedStyles} from '@/hooks';
import {ChevronRight} from '@/icons';

const DefaultRow = ({subsection, disabled, isFirst, isLast, onEdit}) => {
  const {t} = useTranslation();
  const [styles, theme] = useThemedStyles(
    createDefaultRowStyles({isFirst, isLast}),
  );
  const handlePress = useEvent(() => onEdit(subsection));
  return (
    <View style={styles.border}>
      <Pressable
        style={[styles.row, styles.flex]}
        onPress={!disabled ? handlePress : undefined}>
        <Text style={styles.flex} bold>
          {t(subsection.option)}
        </Text>
        <ChevronRight color={disabled ? theme.colors.grey500 : undefined} />
      </Pressable>
    </View>
  );
};

DefaultRow.propTypes = {
  subsection: PropTypes.shape({}),
  onEdit: PropTypes.func,
  isFirst: PropTypes.bool,
  isLast: PropTypes.bool,
};

export default DefaultRow;
