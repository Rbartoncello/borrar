import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import FlawsIndicator from '../../FlawsIndicator';
import Text from '../../Text';
import IterableRow from './IterableRow';
import SimpleRow from './SimpleRow';
import {createSimpleSubsectionStyles} from './styles';
import {useThemedStyles} from '@/hooks';

const FlawedSubsectionRow = ({
  subsection,
  values,
  isFirst,
  isLast,
  onAdd,
  onShowMenu,
}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(
    createSimpleSubsectionStyles({isFirst, isLast}),
  );
  return (
    <View style={styles.border}>
      <View style={styles.bar} />
      <View style={styles.flex}>
        <View style={styles.row}>
          <Text style={styles.flex} bold>
            {t(subsection.option)}
          </Text>
          <FlawsIndicator flaws={values?.length || 1} />
        </View>
        {subsection.iteratee ? (
          <IterableRow
            subsection={subsection}
            values={values}
            isFirst={isFirst}
            isLast={isLast}
            onAdd={onAdd}
            onShowMenu={onShowMenu}
          />
        ) : (
          <SimpleRow
            subsection={subsection}
            values={values}
            isFirst={isFirst}
            isLast={isLast}
            onShowMenu={onShowMenu}
          />
        )}
      </View>
    </View>
  );
};

export default FlawedSubsectionRow;
