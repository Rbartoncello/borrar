const getStatusField = subsection =>
  subsection.fields.find(field => field.type === 'chip');

export const formatStatus = (t, subsection, values) => {
  const statusField = getStatusField(subsection);
  return values[statusField.name].map(t).join(', ');
};
