import {Button as BaseButton} from '@rneui/base';
import {Button as SolidButton, withTheme} from '@rneui/themed';
import {useTranslation} from 'react-i18next';

const ClearButton = withTheme(BaseButton, 'ClearButton');
const OutlineButton = withTheme(BaseButton, 'OutlineButton');

const getButtonComponent = type => {
  switch (type) {
    case 'clear':
      return ClearButton;
    case 'outline':
      return OutlineButton;
    default:
      return SolidButton;
  }
};

const Button = ({type, title, ...props}) => {
  const Component = getButtonComponent(type);
  const {t} = useTranslation();
  return <Component title={t(title)} {...props} />;
};

export default Button;
