export const createStyles = theme => ({
  container: {
    marginBottom: theme.spacing.paddingHorizontal,
  },
  labelStyle: {
    paddingBottom: 5,
    color: theme.colors.grey800,
  },
  input: {
    height: 50,
    borderWidth: 2,
    borderBottomWidth: 2,
    borderRadius: 15,
    borderColor: theme.colors.grey400,
    paddingHorizontal: theme.spacing.paddingHorizontal,
    alignItems: 'center',
    flexDirection: 'row',
  },
  placeholder: {
    color: theme.colors.grey700,
    marginLeft: 8,
  },
  value: {
    color: theme.colors.grey1000,
    marginLeft: 8,
  },
  error: {color: theme.colors.red800},
});

export const createCalendarButtonStyles = theme => ({
  icon: {marginTop: theme.spacing.marginVertical * 2.4},
});
