import {useTranslation} from 'react-i18next';
import {Pressable, View} from 'react-native';
import DatePicker from '../DatePicker';
import Text from '../Text';
import {createStyles} from './styles';
import {useBoolean, useThemedStyles} from '@/hooks';
import {Calendar} from '@/icons';
import {DateUtilService} from '@/services';

const dateUtil = new DateUtilService();

const DateInput = ({
  errorMessage,
  field,
  form,
  label,
  maximumDate,
  minimumDate,
  onChange = () => {},
  placeholder = 'datePlaceholder',
  value,
  textStyles,
  labelStyles,
  iconColor,
  inputContainerStyle,
}) => {
  const {t} = useTranslation();
  const [styles] = useThemedStyles(createStyles);
  const [showPicker, setShowPicker] = useBoolean();
  const handleChange = date => {
    setShowPicker.off();
    form?.setFieldValue(field.name, value || new Date());
    onChange(date);
  };
  return (
    <View style={styles.container}>
      {showPicker && (
        <DatePicker
          defaultValue={value ? new Date(value) : maximumDate || new Date()}
          maximumDate={maximumDate}
          minimumDate={minimumDate}
          onChange={handleChange}
          onDismiss={setShowPicker.off}
        />
      )}
      {label && (
        <Text bold style={[styles.labelStyle, labelStyles]}>
          {label}
        </Text>
      )}
      <Pressable
        style={[styles.input, inputContainerStyle]}
        onPress={setShowPicker.on}>
        <Calendar color={iconColor} />
        <Text style={[value ? styles.value : styles.placeholder, textStyles]}>
          {value ? dateUtil.formatDate(value) : t(placeholder)}
        </Text>
      </Pressable>
      {errorMessage && <Text style={styles.error}>{t(errorMessage)}</Text>}
    </View>
  );
};

export default DateInput;
