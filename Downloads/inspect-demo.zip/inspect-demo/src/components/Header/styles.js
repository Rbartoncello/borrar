const createStyles = theme => ({
  container: {
    overflow: 'hidden',
    backgroundColor: theme.colors.blue1000,
  },
  row: {flexDirection: 'row'},
  rowWithoutBack: {
    paddingHorizontal: theme.spacing.paddingHorizontal * 2,
  },
  column: {
    flex: 1,
    marginVertical: theme.spacing.marginVertical,
    marginRight: theme.spacing.paddingHorizontal * 2,
  },
  button: {marginVertical: theme.spacing.marginVertical * 0.5},
  title: {
    paddingBottom: theme.spacing.marginVertical / 2,
    color: theme.colors.white,
  },
  menuIcon: {top: 18},
  caption: {
    color: theme.colors.blue500,
    fontSize: 16,
  },
});

export default createStyles;
