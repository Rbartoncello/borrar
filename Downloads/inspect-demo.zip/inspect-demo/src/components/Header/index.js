import {useTranslation} from 'react-i18next';
import {View, ImageBackground, Pressable} from 'react-native';
import {connect} from 'react-redux';
import createStyles from './styles';
import headerImage from '@/assets/images/header.png';
import {Text, Button, Menu} from '@/components';
import {useBoolean, useEvent, useNavigation, useThemedStyles} from '@/hooks';
import {ArrowLeft, ArrowRightFromSquare, Bars, CarPlus} from '@/icons';
import {
  createFullInspection,
  reopenInspections,
} from '@/state/reducer/inspection';
import {logout} from '@/state/reducer/session';

const Header = ({
  title,
  caption,
  enableMenu,
  hideBack,
  children,
  onBack,
  onLogout,
  onReopenInspections,
  onCreateInspection,
}) => {
  const [styles, theme] = useThemedStyles(createStyles);
  const {t} = useTranslation();
  const {goBack} = useNavigation();
  const [showMenu, setShowMenu] = useBoolean();
  const handlePress = useEvent(() => (onBack ? onBack() : goBack()));
  const options = [
    {
      icon: <ArrowRightFromSquare color={theme.colors.black} height={20} />,
      label: 'logout',
      onPress: onLogout,
    },
  ];
  if (__DEV__) {
    options.push({
      icon: <Bars color={theme.colors.black} />,
      label: 'Reopen inspections',
      onPress: onReopenInspections,
    });
    options.push({
      icon: <CarPlus color={theme.colors.black} height={20} />,
      label: 'Add completed inspection',
      onPress: onCreateInspection,
    });
  }
  return (
    <View style={styles.container}>
      {showMenu && <Menu visible onClose={setShowMenu.off} options={options} />}
      <ImageBackground source={headerImage} resizeMode="cover">
        <View
          style={[styles.row, hideBack ? styles.rowWithoutBack : undefined]}>
          {!hideBack && (
            <Button
              type="clear"
              onPress={handlePress}
              icon={<ArrowLeft />}
              containerStyle={styles.button}
            />
          )}
          <View style={styles.column}>
            <Text h4 numberOfLines={2} style={styles.title}>
              {t(title)}
            </Text>
            {caption && (
              <Text numberOfLines={1} style={styles.caption}>
                {t(caption)}
              </Text>
            )}
          </View>
          {enableMenu && (
            <Pressable style={styles.menuIcon} onPress={setShowMenu.on}>
              <Bars />
            </Pressable>
          )}
        </View>
        {children}
      </ImageBackground>
    </View>
  );
};

export default connect(null, {
  onLogout: logout,
  onReopenInspections: reopenInspections,
  onCreateInspection: createFullInspection,
})(Header);
