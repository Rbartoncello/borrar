# Karvi inspect app

## Installation

Install the dependencies and start the react-native server:

```sh
npm ci
npm start
```
